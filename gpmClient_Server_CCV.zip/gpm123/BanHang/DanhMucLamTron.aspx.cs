﻿using BanHang.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace BanHang
{
    public partial class DanhMucLamTron : System.Web.UI.Page
    {
        dtDanhMucLamTron data = new dtDanhMucLamTron();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (dtSetting.LayTrangThaiMenu_ChucNang(Session["IDNhom"].ToString(), 5) == 1)
                gridDanhMucLamTron.Columns["iconaction"].Visible = false;

            if (dtSetting.LayTrangThaiMenu(Session["IDNhom"].ToString(), 5) == 1)
            {
                LoadGrid();
            }
            else
            {
                Response.Redirect("Default.aspx");
            }
        }

        private void LoadGrid()
        {
           data = new dtDanhMucLamTron();
           gridDanhMucLamTron.DataSource = data.LayDanhSachDanhMucLamTron();
           gridDanhMucLamTron.DataBind();
        }

        protected void gridDanhMucLamTron_RowInserting(object sender, DevExpress.Web.Data.ASPxDataInsertingEventArgs e)
        {
            string TenLamTron = e.NewValues["Ten"].ToString();
            DateTime NgayCapNhat = DateTime.Today.Date;
            data = new dtDanhMucLamTron();
            data.ThemDanhMucLamTron(TenLamTron, NgayCapNhat);
            e.Cancel = true;
            gridDanhMucLamTron.CancelEdit();
            LoadGrid();

            ActionServer.CapNhatServer();
            dtLichSuTruyCap.ThemLichSu(Session["IDNhanVien"].ToString(), Session["IDNhom"].ToString(), "Danh mục làm tròn:" + TenLamTron, dtSetting.LayIDKho(), "Danh Mục", "Thêm");
        }

        protected void gridDanhMucLamTron_RowUpdating(object sender, DevExpress.Web.Data.ASPxDataUpdatingEventArgs e)
        {
            string ID = e.Keys["ID"].ToString();
            string TenLamTron = e.NewValues["Ten"].ToString();
            DateTime NgayCapNhat = DateTime.Today.Date;
            data.SuaDanhMucLamTron(Int32.Parse(ID), TenLamTron, NgayCapNhat);
            e.Cancel = true;
            gridDanhMucLamTron.CancelEdit();
            LoadGrid();

            ActionServer.CapNhatServer();
            dtLichSuTruyCap.ThemLichSu(Session["IDNhanVien"].ToString(), Session["IDNhom"].ToString(), "Danh mục làm tròn:" + TenLamTron, dtSetting.LayIDKho(), "Danh Mục", "Cập Nhật");
        }

        protected void gridDanhMucLamTron_RowDeleting(object sender, DevExpress.Web.Data.ASPxDataDeletingEventArgs e)
        {
            string ID = e.Keys[0].ToString();
            data = new dtDanhMucLamTron();
            data.XoaDanhMucLamTron(Int32.Parse(ID));
            e.Cancel = true;
            gridDanhMucLamTron.CancelEdit();
            LoadGrid();

            ActionServer.CapNhatServer();
            dtLichSuTruyCap.ThemLichSu(Session["IDNhanVien"].ToString(), Session["IDNhom"].ToString(), "Danh mục làm tròn:" + ID, dtSetting.LayIDKho(), "Danh Mục", "Xóa");
        }
    }
}