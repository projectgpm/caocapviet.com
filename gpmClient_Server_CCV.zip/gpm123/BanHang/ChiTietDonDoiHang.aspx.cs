﻿using BanHang.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace BanHang
{
    public partial class ChiTietDonDoiHang : System.Web.UI.Page
    {
        dtPhieuDoiHang data = new dtPhieuDoiHang();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["KTDangNhap"] == "GPM")
            {
                string IDDonDoiHang = Request.QueryString["IDDonDoiHang"];
                if (IDDonDoiHang != null)
                {

                    LoadGrid(Int32.Parse(IDDonDoiHang.ToString()));
                }
            }
            else
            {
                Response.Redirect("DangNhap.aspx"); 
            }
        }

        private void LoadGrid(int IDDonDoiHang)
        {
            data = new dtPhieuDoiHang();
            gridChiTietDonDoiHang.DataSource = data.DanhSachChiTietDonDoiHang_ID(IDDonDoiHang);
            gridChiTietDonDoiHang.DataBind();
        }

        protected void gridChiTietDonDoiHang_RowUpdating(object sender, DevExpress.Web.Data.ASPxDataUpdatingEventArgs e)
        {

        }
    }
}