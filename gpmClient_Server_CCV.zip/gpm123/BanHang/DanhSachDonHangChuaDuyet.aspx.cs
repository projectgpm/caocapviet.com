﻿using BanHang.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace BanHang
{
    public partial class DanhSachDonHangChuaDuyet : System.Web.UI.Page
    {
        dtDonHangChuaDuyet data = new dtDonHangChuaDuyet();

        protected void Page_Load(object sender, EventArgs e)
        {
            if (dtSetting.LayTrangThaiMenu(Session["IDNhom"].ToString(), 24) == 1)
            {
                LoadGrid();
            }
            else
            {
                Response.Redirect("Default.aspx");
            }
        }

        private void LoadGrid()
        {
            data = new dtDonHangChuaDuyet();
            gridDanhSachDonHangChuaDuyet.DataSource = data.LayDanhSach();
            gridDanhSachDonHangChuaDuyet.DataBind();
        }

        protected void gridDanhSachDonHangChuaDuyet_RowDeleting(object sender, DevExpress.Web.Data.ASPxDataDeletingEventArgs e)
        {
            //int ID = Int32.Parse(e.Keys[0].ToString());
            //data = new dtDonHangChuaDuyet();
            //data.XoaDonHang(ID);
            //e.Cancel = true;
            //gridDanhSachDonHangChuaDuyet.CancelEdit();
            //LoadGrid();
        }
    }
}