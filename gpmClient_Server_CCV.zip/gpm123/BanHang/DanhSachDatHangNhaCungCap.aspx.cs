﻿using BanHang.Data;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace BanHang
{
    public partial class DanhSachDatHangNhaCungCap : System.Web.UI.Page
    {
        dtDuyetHangNhaCungCap data = new dtDuyetHangNhaCungCap();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["KTDangNhap"] != "GPM")
            {
                Response.Redirect("DangNhap.aspx");
            }
            else
            {
                //if (dtSetting.LayTrangThaiMenu_ChucNang(Session["IDNhom"].ToString(), 22) == 1)
                gridDanhSachDonHang.Columns["iconaction"].Visible = false;

                if (dtSetting.LayTrangThaiMenu(Session["IDNhom"].ToString(), 15) == 1)
                {
                    LoadGrid();
                }
                else
                {
                    Response.Redirect("Default.aspx");
                }
            }
        }

        private void LoadGrid()
        {
            data = new dtDuyetHangNhaCungCap();
            gridDanhSachDonHang.DataSource = data.LayDanhSachDatHangNhaCungCap();
            gridDanhSachDonHang.DataBind();
        }

        protected void gridDanhSachDonHang_CustomButtonCallback(object sender, DevExpress.Web.ASPxGridViewCustomButtonCallbackEventArgs e)
        {
            if (e.ButtonID == "DuyetDonHang")
            {
                int ID = Int32.Parse(gridDanhSachDonHang.GetRowValues(VisibleIndexHere, gridDanhSachDonHang.KeyFieldName).ToString());
                data = new dtDuyetHangNhaCungCap();
                DataTable dta = data.LayDanhSachChiTietDonDatHang(ID);
                if (dta.Rows.Count != 0)
                {
                    foreach(DataRow dr in dta.Rows)
                    {
                        int IDHangHoa = Int32.Parse(dr["IDHangHoa"].ToString());
                        int SoLuong = Int32.Parse(dr["SoLuong"].ToString());
                        dtLichSuKho.ThemLichSu(IDHangHoa, Int32.Parse(Session["IDNhanVien"].ToString()), SoLuong, "Duyệt đơn hàng Nhà Cung Cấp: " + ID);
                        dtCapNhatTonKho dt = new dtCapNhatTonKho();
                        dt.CongTonKho_IDHangHoa(IDHangHoa, SoLuong, dtSetting.LayIDKho());// cộng tồn kho 
                    }
                    data.DuyetDonHangNhaCungCap(ID);
                    dtLichSuTruyCap.ThemLichSu(Session["IDNhanVien"].ToString(), Session["IDNhom"].ToString(), "Duyệt Hàng Nhà Cung Cấp:" + ID, dtSetting.LayIDKho(), "Nhập Xuất Tồn", "Duyệt hàng"); 
                    LoadGrid();
                }
            }
        }

        public int VisibleIndexHere { get; set; }

        protected void btnInPhieu_Click(object sender, EventArgs e)
        {
            if (cmbIDDonHang.Text != "")
            {
                string SoDoHang = cmbIDDonHang.Value.ToString();
                popupIn.ContentUrl = "~/InDonDatHang.aspx?SoDoHang=" + SoDoHang;
                popupIn.ShowOnPageLoad = true;
            }
            else
            {
                Response.Write("<script language='JavaScript'> alert('Vui lòng chọn đơn đặt hàng cần In.'); </script>");
            }
        }
    }
}