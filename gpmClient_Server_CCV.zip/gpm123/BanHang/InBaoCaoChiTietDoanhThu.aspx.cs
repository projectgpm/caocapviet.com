﻿using BanHang.Data;
using BanHang.Report;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace BanHang
{
    public partial class InBaoCaoChiTietDoanhThu : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            int IDKhoHang = Int32.Parse(Request.QueryString["khohang"]);
            string strKho = "Tất cả kho";

            dtThongTinCuaHangKho dt = new dtThongTinCuaHangKho();
            DataTable da = dt.LayDanhSach_ID_2(dtSetting.LayIDKho());
            DataRow dr = da.Rows[0];
            string strCty = dr["TenCuaHang"].ToString();

            if (IDKhoHang != -1)
            {
                dtThongTinCuaHangKho d = new dtThongTinCuaHangKho();
                da = d.LayDanhSach_ID_2(IDKhoHang);
                if (da.Rows.Count != 0)
                {
                    dr = da.Rows[0];
                    strKho = dr["TenCuaHang"].ToString();
                }
            }

            rpBaoCaoChiTietDoanhThu rp = new rpBaoCaoChiTietDoanhThu();

            rp.Parameters["strKho"].Value = strKho;
            rp.Parameters["strKho"].Visible = false;

            rp.Parameters["IDKho"].Value = IDKhoHang;
            rp.Parameters["IDKho"].Visible = false;

            float BanLe1 = 0; float xuatSi = 0;

            dtBanHangLe dtx = new dtBanHangLe();
            DataTable data1 = dtx.LayThongHoaDon_BaoCao(Request.QueryString["ngaybd"], Request.QueryString["ngaykt"], IDKhoHang + "");
            if (data1.Rows.Count != 0)
            {
                for (int i = 0; i < data1.Rows.Count; i++)
                {
                    DataRow drx = data1.Rows[i];
                    float a = float.Parse(drx["GiaMua"].ToString());
                    float b = float.Parse(drx["GiaBan"].ToString());
                    int c = Int32.Parse(drx["SoLuong"].ToString());
                    BanLe1 = BanLe1 + (b - a) * c;
                }
            }
            dtPhieuXuatSi dtxx = new dtPhieuXuatSi();
            DataTable data2 = dtxx.LayThongTinHangHoa_BaoCao(Request.QueryString["ngaybd"], Request.QueryString["ngaykt"], IDKhoHang + "");
            if (data2.Rows.Count != 0)
            {
                for (int i = 0; i < data2.Rows.Count; i++)
                {
                    DataRow drxx = data2.Rows[i];
                    float ax = float.Parse(drxx["GiaMua"].ToString());
                    float bx = float.Parse(drxx["GiaBan1"].ToString());
                    int cx = Int32.Parse(drxx["SoLuong"].ToString());
                    xuatSi = xuatSi + (bx - ax) * cx;
                }
            }


            rp.Parameters["BanLe1"].Value = BanLe1;
            rp.Parameters["BanLe1"].Visible = false;
            rp.Parameters["xuatSi"].Value = xuatSi;
            rp.Parameters["xuatSi"].Visible = false;

            rp.Parameters["NgayBD"].Value = Request.QueryString["ngaybd"] + " 00:00:00.000";
            rp.Parameters["NgayBD"].Visible = false;
            rp.Parameters["NgayKT"].Value = Request.QueryString["ngaykt"] + " 23:59:59.000";
            rp.Parameters["NgayKT"].Visible = false;
            DateTime d1 = DateTime.Parse(Request.QueryString["ngaybd"]);
            string s = d1.Date.ToString("dd/MM/yyyy");
            DateTime d2 = DateTime.Parse(Request.QueryString["ngaykt"]);
            string s2 = d2.Date.ToString("dd/MM/yyyy");
            rp.Parameters["strNgay"].Value = s + " - " + s2;
            rp.Parameters["strNgay"].Visible = false;
            reportView.Report = rp;
        }
    }
}