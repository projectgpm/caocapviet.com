﻿using BanHang.Data;
using DevExpress.Web;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace BanHang
{
    public partial class PhieuNhapLe : System.Web.UI.Page
    {
        dtPhieuNhapLe data = new dtPhieuNhapLe();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["KTDangNhap"] != "GPM")
            {
                Response.Redirect("DangNhap.aspx");
            }
            else
            {
                if (dtSetting.LayTrangThaiMenu_ChucNang(Session["IDNhom"].ToString(), 13) == 1)
                    Response.Redirect("Default.aspx");
                if (dtSetting.LayTrangThaiMenu(Session["IDNhom"].ToString(), 13) == 1)
                {
                    if (!IsPostBack)
                    {
                        data = new dtPhieuNhapLe();
                        data.XoaPhieuNhapLe_Null();
                        object IDPhieuNhapLe = data.ThemPhieuNhapLe_Temp();
                        IDPhieuNhapLe_Temp.Value = IDPhieuNhapLe.ToString();
                        cmbKho.Enabled = false;
                        cmbKho.Text = dtSetting.LayIDKho() + "";
                    }
                    LoadGrid(Int32.Parse(IDPhieuNhapLe_Temp.Value.ToString()));
                }
                else
                {
                    Response.Redirect("Default.aspx");
                }
            }
            
        }
      
        private void LoadGrid(int IDPhieuNhapLe)
        {
            data = new dtPhieuNhapLe();
            gridDanhSachHangHoa_Temp.DataSource = data.LayDanhSachPhieuNhapLe_Temp(IDPhieuNhapLe);
            gridDanhSachHangHoa_Temp.DataBind();

        }
     
        public void Clear()
        {
            cmbHangHoa.Text = "";
            txtSoLuong.Text = "";
            cmbDonViTinh.Text = "";
            txtGiaNhap.Text = "";
            txtThanhTien.Text = "";
        }
     
        protected void cmbNgayLapPhieu_Init(object sender, EventArgs e)
        {
            cmbNgayLapPhieu.Date = DateTime.Today;
        }

        protected void cmbHangHoa_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cmbHangHoa.Text != "")
            {
                data = new dtPhieuNhapLe();
                DataTable dt = data.LayThongTinHangHoa(Int32.Parse(cmbHangHoa.Value.ToString()));
                if (dt.Rows.Count != 0)
                {
                    DataRow dr = dt.Rows[0];
                    txtSoLuong.Text = "1";
                    txtGiaNhap.Text = "0";
                    cmbDonViTinh.Value = dr["IDDonViTinh"].ToString();
                    txtGiaNhap.Text = dr["GiaMua"].ToString();
                    LoadThanhTien();
                }
            }
        }

        protected void txtSoLuong_NumberChanged(object sender, EventArgs e)
        {
            LoadThanhTien();
        }

        protected void txtGiaNhap_NumberChanged(object sender, EventArgs e)
        {
            LoadThanhTien();
        }

        public void LoadThanhTien()
        {
            if (cmbHangHoa.Text != "" && txtSoLuong.Text != "")
            {
                DataTable dt = data.LayThongTinHangHoa(Int32.Parse(cmbHangHoa.Value.ToString()));
                if (dt.Rows.Count != 0)
                {
                    int SoLuong = Int32.Parse(txtSoLuong.Value.ToString());
                    double GiaNhap = double.Parse(txtGiaNhap.Value.ToString());
                    txtThanhTien.Text = (SoLuong * GiaNhap).ToString();
                }
            }
        }

        protected void btnHuyPhieuNhapLe_Click(object sender, EventArgs e)
        {
            data = new dtPhieuNhapLe();
            int ID = Int32.Parse(IDPhieuNhapLe_Temp.Value.ToString());
            if (ID != null)
            {
                data.XoaPhieuNhapLe_Temp(ID);
                data.XoaPhieuNhapLe_Null();
                data.XoaChiTietPhieuNhapLe_Temp(ID);
                Response.Redirect("DanhSachPhieuNhapLe.aspx");
            }
        }

        protected void btnThem_Click(object sender, EventArgs e)
        {
            if (cmbHangHoa.Value != null && txtSoLuong.Text != "")
            {
                int IDHangHoa = Int32.Parse(cmbHangHoa.Value.ToString());
                int SoLuong = Int32.Parse(txtSoLuong.Value.ToString());
                float GiaNhap = float.Parse(txtGiaNhap.Value.ToString());
                float ThanhTien = float.Parse(txtThanhTien.Value.ToString());
                int IDPhieuNhapLe = Int32.Parse(IDPhieuNhapLe_Temp.Value.ToString());
                int IDDonViTinh = Int32.Parse(cmbDonViTinh.Value.ToString());
                DataTable db = data.KTChiTietPhieuNhapLe_Temp(IDHangHoa);// kiểm tra hàng hóa
                if (db.Rows.Count == 0)
                {
                    data = new dtPhieuNhapLe();
                    data.ThemPhieuNhapLe_Temp(IDPhieuNhapLe, IDHangHoa, IDDonViTinh, SoLuong, GiaNhap, ThanhTien);
                    Clear();
                }
                else
                {
                    data = new dtPhieuNhapLe();
                    data.UpdatePhieuNhapLe_temp(IDPhieuNhapLe, IDHangHoa, IDDonViTinh, SoLuong, GiaNhap, ThanhTien);
                    Clear();
                }
                LoadGrid(IDPhieuNhapLe);
            }
            else
            {
                Response.Write("<script language='JavaScript'> alert('Bạn chưa chọn hàng hóa.'); </script>");
            }
        }

        protected void btnThemPhieuNhapLe_Click(object sender, EventArgs e)
        {
            if (cmbNhaCungCap.Value != null)
            {
                int IDPhieuNhapLe = Int32.Parse(IDPhieuNhapLe_Temp.Value.ToString());
                DataTable db = data.LayDanhSachPhieuNhapLe_Temp(IDPhieuNhapLe);
                if (db.Rows.Count != 0)
                {
                    int IDNhaCungCap = Int32.Parse(cmbNhaCungCap.Value.ToString());
                    DateTime NgayLap = DateTime.Parse(cmbNgayLapPhieu.Text.ToString());
                    string GhiChu = txtGhiChu == null ? "" : txtGhiChu.Text.ToString();

                    float TongTien = 0;

                    foreach (DataRow dr in db.Rows)
                    {
                        float ThanhTien = float.Parse(dr["ThanhTien"].ToString());
                        TongTien = TongTien + ThanhTien;
                    }
                    int IDKho = dtSetting.LayIDKho();
                    data = new dtPhieuNhapLe();

                    data.CapNhatPhieuNhapLe_ID(IDPhieuNhapLe, IDKho, IDNhaCungCap, NgayLap, TongTien, GhiChu);

                    foreach (DataRow dr in db.Rows)
                    {
                        int IDHangHoa = Int32.Parse(dr["IDHangHoa"].ToString());
                       
                        int SoLuong = Int32.Parse(dr["SoLuong"].ToString());
                        float GiaNhap = float.Parse(dr["GiaNhap"].ToString());
                  
                        float ThanhTien = float.Parse(dr["ThanhTien"].ToString());
                        int IDDonViTinh = Int32.Parse(dr["IDDonViTinh"].ToString());
                        data = new dtPhieuNhapLe();
                        data.ThemChiTietPhieuNhapLe(IDPhieuNhapLe, IDHangHoa, SoLuong, GiaNhap, ThanhTien, IDDonViTinh);
                        dtCapNhatTonKho tk = new dtCapNhatTonKho();

                        dtLichSuKho.ThemLichSu(IDHangHoa, Int32.Parse(Session["IDNhanVien"].ToString()), SoLuong * (-1), "Nhập hàng lẻ");

                        dtLichSuKho.ThemLichSuNhap(IDHangHoa, IDNhaCungCap, SoLuong);
                        tk.CongTonKho_IDHangHoa(IDHangHoa, SoLuong,IDKho);
                    }

                    dtLichSuTruyCap.ThemLichSu(Session["IDNhanVien"].ToString(), Session["IDNhom"].ToString(), "Phiếu Nhập Lẻ", dtSetting.LayIDKho(), "Nhập xuất tồn", "Thêm");  
                    data = new dtPhieuNhapLe();
                    data.XoaChiTietPhieuNhapLe_Temp(IDPhieuNhapLe);
                    Response.Redirect("DanhSachPhieuNhapLe.aspx");
                }
                else
                {
                    Response.Write("<script language='JavaScript'> alert('Danh sách hàng hóa rỗng.'); </script>");
                }
            }
            else
            {
                Response.Write("<script language='JavaScript'> alert('Bạn chưa chọn nhà cung cấp.'); </script>");
            }
        }

        protected void gridDanhSachHangHoa_Temp_RowDeleting(object sender, DevExpress.Web.Data.ASPxDataDeletingEventArgs e)
        {
            int ID = Int32.Parse(e.Keys[0].ToString());
            data = new dtPhieuNhapLe();
            data.XoaChiTietPhieuNhapLe_Temp_ID(ID);
            e.Cancel = true;
            gridDanhSachHangHoa_Temp.CancelEdit();
            int IDPhieuNhapSi = Int32.Parse(IDPhieuNhapLe_Temp.Value.ToString());
            LoadGrid(IDPhieuNhapSi);
        }

        protected void cmbHangHoa_ItemRequestedByValue(object source, DevExpress.Web.ListEditItemRequestedByValueEventArgs e)
        {
            long value = 0;
            if (e.Value == null || !Int64.TryParse(e.Value.ToString(), out value))
                return;
            ASPxComboBox comboBox = (ASPxComboBox)source;
            sqlHangHoa.SelectCommand = @"SELECT GPM_HangHoa.ID, GPM_HangHoa.MaHang, GPM_HangHoa.TenHangHoa, GPM_HangHoa.GiaMua, GPM_DonViTinh.TenDonViTinh 
                                        FROM GPM_DonViTinh INNER JOIN GPM_HangHoa ON GPM_DonViTinh.ID = GPM_HangHoa.IDDonViTinh 
                                                           INNER JOIN GPM_HangHoaTonKho ON GPM_HangHoaTonKho.IDHangHoa = GPM_HangHoa.ID 
                                        WHERE (GPM_HangHoa.ID = @ID)";

            sqlHangHoa.SelectParameters.Clear();
            sqlHangHoa.SelectParameters.Add("ID", TypeCode.Int64, e.Value.ToString());
            comboBox.DataSource = sqlHangHoa;
            comboBox.DataBind();
        }

        protected void cmbHangHoa_ItemsRequestedByFilterCondition(object source, DevExpress.Web.ListEditItemsRequestedByFilterConditionEventArgs e)
        {
            ASPxComboBox comboBox = (ASPxComboBox)source;

            sqlHangHoa.SelectCommand = @"SELECT [ID], [MaHang], [TenHangHoa], [GiaMua] , [TenDonViTinh]
                                        FROM (
	                                        select GPM_HangHoa.ID, GPM_HangHoa.MaHang, GPM_HangHoa.TenHangHoa, GPM_HangHoa.GiaMua, GPM_DonViTinh.TenDonViTinh, 
	                                        row_number()over(order by GPM_HangHoa.MaHang) as [rn] 
	                                        FROM GPM_DonViTinh INNER JOIN GPM_HangHoa ON GPM_DonViTinh.ID = GPM_HangHoa.IDDonViTinh 
                                                               INNER JOIN GPM_HangHoaTonKho ON GPM_HangHoaTonKho.IDHangHoa = GPM_HangHoa.ID
	                                        WHERE (GPM_HangHoa.MaHang LIKE @MaHang) AND (GPM_HangHoaTonKho.IDKho = @IDKho) AND (GPM_HangHoaTonKho.DaXoa = 0)	
	                                        ) as st 
                                        where st.[rn] between @startIndex and @endIndex";

            sqlHangHoa.SelectParameters.Clear();
            sqlHangHoa.SelectParameters.Add("MaHang", TypeCode.String, string.Format("%{0}%", e.Filter));
            sqlHangHoa.SelectParameters.Add("IDKho", TypeCode.Int32, dtSetting.LayIDKho() + "");
            sqlHangHoa.SelectParameters.Add("startIndex", TypeCode.Int64, (e.BeginIndex + 1).ToString());
            sqlHangHoa.SelectParameters.Add("endIndex", TypeCode.Int64, (e.EndIndex + 1).ToString());
            comboBox.DataSource = sqlHangHoa;
            comboBox.DataBind();
        }

    }
}