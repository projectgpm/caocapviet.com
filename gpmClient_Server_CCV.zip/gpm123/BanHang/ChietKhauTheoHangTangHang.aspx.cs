﻿using BanHang.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace BanHang
{
    public partial class ChiecKhauTheoHangTangHang : System.Web.UI.Page
    {
        dtChietKhauHangTangHang data = new dtChietKhauHangTangHang();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (dtSetting.LayTrangThaiMenu_ChucNang(Session["IDNhom"].ToString(), 11) == 1)
                gridChietKhauTheoHangTangHang.Columns["iconaction"].Visible = false;

            if (dtSetting.LayTrangThaiMenu(Session["IDNhom"].ToString(), 11) == 1)
            {
                LoadGrid();
            }
            else
            { Response.Redirect("Default.aspx"); }
        }

        private void LoadGrid()
        {
            data = new dtChietKhauHangTangHang();
            gridChietKhauTheoHangTangHang.DataSource = data.LayDanhSachChietKhauHangTangHang();
            gridChietKhauTheoHangTangHang.DataBind();
        }

        protected void gridChietKhauTheoHangTangHang_RowDeleting(object sender, DevExpress.Web.Data.ASPxDataDeletingEventArgs e)
        {
            string ID = e.Keys[0].ToString();
            data = new dtChietKhauHangTangHang();
            data.XoaChietKhauHangTangHang(Int32.Parse(ID));
            e.Cancel = true;
            gridChietKhauTheoHangTangHang.CancelEdit();
            LoadGrid();

            ActionServer.CapNhatServer();
            dtLichSuTruyCap.ThemLichSu(Session["IDNhanVien"].ToString(), Session["IDNhom"].ToString(), "Chiết Khấu Theo Hàng Tặng Hàng", dtSetting.LayIDKho(), "Danh Mục", "Xóa");
        }

        protected void gridChietKhauTheoHangTangHang_RowInserting(object sender, DevExpress.Web.Data.ASPxDataInsertingEventArgs e)
        {
            DateTime NgayCapNhat = DateTime.Today.Date;
            data = new dtChietKhauHangTangHang();
            int IDHangHoa = Int32.Parse(e.NewValues["IDHangHoa"].ToString());
            int SoLuongHangHoa = Int32.Parse(e.NewValues["SoLuongHangHoa"].ToString());
            int IDHangHoaTang = Int32.Parse(e.NewValues["IDHangHoaTang"].ToString());
            int SoLuongHangHoaTang = Int32.Parse(e.NewValues["SoLuongHangHoaTang"].ToString());
            DateTime NgayBatDau = DateTime.Parse(e.NewValues["NgayBatDau"].ToString());
            DateTime NgayKetThuc = DateTime.Parse(e.NewValues["NgayKetThuc"].ToString());
            data.ThemChietKhauHangTangHang(IDHangHoa, SoLuongHangHoa, IDHangHoaTang, SoLuongHangHoaTang, NgayBatDau, NgayKetThuc, NgayCapNhat);
            e.Cancel = true;
            gridChietKhauTheoHangTangHang.CancelEdit();
            LoadGrid();

            ActionServer.CapNhatServer();
            dtLichSuTruyCap.ThemLichSu(Session["IDNhanVien"].ToString(), Session["IDNhom"].ToString(), "Chiết Khấu Theo Hàng Tặng Hàng", dtSetting.LayIDKho(), "Danh Mục", "Thêm");
        }

        protected void gridChietKhauTheoHangTangHang_RowUpdating(object sender, DevExpress.Web.Data.ASPxDataUpdatingEventArgs e)
        {
            string ID = e.Keys[0].ToString();
            int IDHangHoa = Int32.Parse(e.NewValues["IDHangHoa"].ToString());
            int SoLuongHangHoa = Int32.Parse(e.NewValues["SoLuongHangHoa"].ToString());
            int IDHangHoaTang = Int32.Parse(e.NewValues["IDHangHoaTang"].ToString());
            int SoLuongHangHoaTang = Int32.Parse(e.NewValues["SoLuongHangHoaTang"].ToString());
            DateTime NgayBatDau = DateTime.Parse(e.NewValues["NgayBatDau"].ToString());
            DateTime NgayKetThuc = DateTime.Parse(e.NewValues["NgayKetThuc"].ToString());
            DateTime NgayCapNhat = DateTime.Today.Date;
            data.SuaChietKhauHangTangHang(Int32.Parse(ID), IDHangHoa, SoLuongHangHoa, IDHangHoaTang, SoLuongHangHoaTang, NgayBatDau, NgayKetThuc, NgayCapNhat);
            e.Cancel = true;
            gridChietKhauTheoHangTangHang.CancelEdit();
            LoadGrid();

            ActionServer.CapNhatServer();
            dtLichSuTruyCap.ThemLichSu(Session["IDNhanVien"].ToString(), Session["IDNhom"].ToString(), "Chiết Khấu Theo Hàng Tặng Hàng", dtSetting.LayIDKho(), "Danh Mục", "Cập Nhật");   
        }
    }
}