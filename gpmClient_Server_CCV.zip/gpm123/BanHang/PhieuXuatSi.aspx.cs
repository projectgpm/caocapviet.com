﻿using BanHang.Data;
using DevExpress.Web;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace BanHang
{
    public partial class PhieuXuatSi : System.Web.UI.Page
    {
        dtPhieuXuatSi data = new dtPhieuXuatSi();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["KTDangNhap"] != "GPM")
            {
                Response.Redirect("DangNhap.aspx");
            }
            else
            {
                if (dtSetting.LayTrangThaiMenu_ChucNang(Session["IDNhom"].ToString(), 17) == 1)
                    Response.Redirect("Default.aspx");
                if (dtSetting.LayTrangThaiMenu(Session["IDNhom"].ToString(), 17) == 1)
                {
                    if (!IsPostBack)
                    {
                        data = new dtPhieuXuatSi();
                        data.XoaPhieuXuatSi_Null();
                        object IDPhieuXuatSi = data.ThemPhieuXuatSi_Temp();
                        IDPhieuXuatSi_Temp.Value = IDPhieuXuatSi.ToString();
                        cmbKho.Enabled = false;
                        cmbKho.Text = dtSetting.LayIDKho() + "";
                    }
                    LoadGrid(Int32.Parse(IDPhieuXuatSi_Temp.Value.ToString()));
                }
                else
                {
                    Response.Redirect("Default.aspx");
                }
            }
        }

        protected void cmbNgayLapPhieu_Init(object sender, EventArgs e)
        {
            cmbNgayLapPhieu.Date = DateTime.Today;
        }

        protected void cmbHangHoa_SelectedIndexChanged(object sender, EventArgs e)
        {

            if (cmbHangHoa.Text != "")
            {
                data = new dtPhieuXuatSi();
                DataTable dt = data.LayThongTinHangHoa(Int32.Parse(cmbHangHoa.Value.ToString()));
                txtTonKho.Text = dtCapNhatTonKho.SoLuongTonKho_Client(Int32.Parse(cmbHangHoa.Value.ToString()), dtSetting.LayIDKho()) + "";
                DataRow dr = dt.Rows[0];
                cmbDonViTinh.Value = dr["IDDonViTinh"].ToString();
                txtSoLuong.Text = "0";
                txtDonGia.Text = dr["GiaBan1"].ToString();
                txtThanhTien.Text = (Int32.Parse(txtSoLuong.Text.ToString()) * double.Parse(txtDonGia.Text.ToString())).ToString();
            }
        }

        protected void txtSoLuong_NumberChanged(object sender, EventArgs e)
        {
            LoadThanhTien();
        }

        protected void txtDonGia_NumberChanged(object sender, EventArgs e)
        {
            LoadThanhTien();
        }

        protected void btnThem_Click(object sender, EventArgs e)
        {
            if (cmbHangHoa.Value != null)
            {
                int SoLuong = Int32.Parse(txtSoLuong.Value.ToString());
                if (SoLuong > 0)
                {
                    int IDHangHoa = Int32.Parse(cmbHangHoa.Value.ToString());

                    int IDPhieuXuatSi = Int32.Parse(IDPhieuXuatSi_Temp.Value.ToString());
                    float DonGia = float.Parse(txtDonGia.Value.ToString());
                    float ThanhTien = float.Parse(txtThanhTien.Value.ToString());
                    int IDDonViTinh = Int32.Parse(cmbDonViTinh.Value.ToString());
                    DataTable db = data.KTChiTietPhieuXuatSi_Temp(IDHangHoa);// kiểm tra hàng hóa
                    if (db.Rows.Count == 0)
                    {
                        data = new dtPhieuXuatSi();
                        data.ThemPhieuXuatSi_Temp(IDPhieuXuatSi, IDHangHoa, IDDonViTinh, SoLuong, DonGia, ThanhTien);
                        Clear();
                    }
                    else
                    {
                        data = new dtPhieuXuatSi();
                        data.UpdatePhieuXuatSi_Temp(IDPhieuXuatSi, IDHangHoa, IDDonViTinh, SoLuong, DonGia, ThanhTien);
                        Clear();
                    }
                    LoadGrid(IDPhieuXuatSi);
                }
                else
                {
                    Response.Write("<script language='JavaScript'> alert('Số lượng > 0.'); </script>");
                }
            }
            else
            {
                Response.Write("<script language='JavaScript'> alert('Bạn chưa chọn hàng hóa.'); </script>");
            }
        }

        protected void btnThemPhieuXuat_Click(object sender, EventArgs e)
        {
            if (cmbKhachHang.Value != null)
            {
                int IDPhieuXuatSi = Int32.Parse(IDPhieuXuatSi_Temp.Value.ToString());
                DataTable db = data.LayDanhSachPhieuXuatSi_Temp(IDPhieuXuatSi);
                if (db.Rows.Count != 0)
                {
                    int IDKhachHang = Int32.Parse(cmbKhachHang.Value.ToString() == null ? "" : cmbKhachHang.Value.ToString());
                    DateTime NgayXuat = DateTime.Parse(cmbNgayLapPhieu.Text.ToString());
                    string GhiChu = txtGhiChu == null ? "" : txtGhiChu.Text.ToString();
                    int IDKho = dtSetting.LayIDKho();


                    data = new dtPhieuXuatSi();
                    float TongTien = 0;
                    foreach (DataRow dr in db.Rows)
                    {
                        float ThanhTien = float.Parse(dr["ThanhTien"].ToString());
                        TongTien = TongTien + ThanhTien;
                    }
                    data.CapNhatPhieuXuatSi_ID(IDPhieuXuatSi, IDKho, IDKhachHang, NgayXuat, TongTien, GhiChu);

                    foreach (DataRow dr in db.Rows)
                    {
                        int IDHangHoa = Int32.Parse(dr["IDHangHoa"].ToString());
                        
                        int SoLuong = Int32.Parse(dr["SoLuong"].ToString());
                        float DonGia = float.Parse(dr["DonGia"].ToString());
                        int IDDonViTinh = Int32.Parse(dr["IDDonViTinh"].ToString());
                        float ThanhTien = float.Parse(dr["ThanhTien"].ToString());
                        data = new dtPhieuXuatSi();
                        data.ThemChiTietPhieuXuatSi(IDPhieuXuatSi, IDHangHoa, IDDonViTinh, SoLuong, DonGia, ThanhTien);
                        dtCapNhatTonKho tk = new dtCapNhatTonKho();

                        dtLichSuKho.ThemLichSu(IDHangHoa, Int32.Parse(Session["IDNhanVien"].ToString()), SoLuong, "Phiếu xuất sỉ");

                        dtLichSuKho.ThemLichSuXuat(IDHangHoa, IDKhachHang, SoLuong);
                        tk.TruTonKho_IDHangHoa(IDHangHoa, SoLuong,IDKho);

                    }
                    dtLichSuTruyCap dt1 = new dtLichSuTruyCap();
                    dtLichSuTruyCap.ThemLichSu(Session["IDNhanVien"].ToString(), Session["IDNhom"].ToString(), "Phiếu Xuất Sỉ" , dtSetting.LayIDKho(), "Nhập xuất tồn", "Thêm");   
                    data = new dtPhieuXuatSi();
                    data.XoaChiTietPhieuXuatSi_Temp(IDPhieuXuatSi);
                    Response.Redirect("DanhSachPhieuXuatSi.aspx");
                }
                else
                {
                    Response.Write("<script language='JavaScript'> alert('Danh sách hàng hóa rỗng.'); </script>");
                }
            }
            else
            {
                Response.Write("<script language='JavaScript'> alert('Bạn chưa chọn khách hàng.'); </script>");
            }
        }
        public void LoadThanhTien()
        {
            if (cmbHangHoa.Text != "")
            {
                if (dtSetting.KT_SoLuong() == 0)
                {
                    DataTable dt = data.LayThongTinHangHoa(Int32.Parse(cmbHangHoa.Value.ToString()));
                    if (dt.Rows.Count != 0)
                    {
                        int SoLuong = Int32.Parse(txtSoLuong.Text.ToString());
                        double DonGia = double.Parse(txtDonGia.Text.ToString());
                        txtThanhTien.Text = (SoLuong * DonGia).ToString();
                    }
                }
                else
                {
                    DataTable dt = data.LayThongTinHangHoa(Int32.Parse(cmbHangHoa.Value.ToString()));
                    if (dt.Rows.Count != 0)
                    {
                        int SL = 0;
                        int SLTonKho = dtCapNhatTonKho.SoLuongTonKho_Client(Int32.Parse(cmbHangHoa.Value.ToString()), dtSetting.LayIDKho());
                        int SoLuong = Int32.Parse(txtSoLuong.Text.ToString());
                        if (SLTonKho >= SoLuong)
                        {
                            SL = SoLuong;
                        }
                        else
                        {
                            SL = SLTonKho;
                            txtSoLuong.Text = SLTonKho + "";
                            Response.Write("<script language='JavaScript'> alert('Số hàng trong kho không đủ.'); </script>");
                        }
                        double DonGia = double.Parse(txtDonGia.Text.ToString());
                        txtThanhTien.Text = (SL * DonGia).ToString();
                    }
                }
            }
        }

        protected void btnHuyPhieuXuat_Click(object sender, EventArgs e)
        {
            data = new dtPhieuXuatSi();
            int ID = Int32.Parse(IDPhieuXuatSi_Temp.Value.ToString());
            if (ID != null)
            {
                data.XoaPhieuXuatSi_Temp(ID);
                data.XoaPhieuXuatSi_Null();
                data.XoaChiTietPhieuXuatSi_Temp(ID);
                Response.Redirect("DanhSachPhieuXuatSi.aspx");
            }
        }

        protected void gridDanhSachHangHoa_Temp_RowDeleting(object sender, DevExpress.Web.Data.ASPxDataDeletingEventArgs e)
        {
            int ID = Int32.Parse(e.Keys[0].ToString());
            data = new dtPhieuXuatSi();
            data.XoaChiTietPhieuXuatSi_Temp_ID(ID);
            e.Cancel = true;
            gridDanhSachHangHoa_Temp.CancelEdit();
            int IDPhieuXuatKhac = Int32.Parse(IDPhieuXuatSi_Temp.Value.ToString());
            LoadGrid(IDPhieuXuatKhac);
        }
        public void Clear()
        {
            cmbHangHoa.Text = "";
            txtSoLuong.Text = "";
            txtTonKho.Text = "";
            cmbDonViTinh.Text = "";
            txtDonGia.Text = "";
            txtThanhTien.Text = "";
        }
        private void LoadGrid(int IDPhieuXuatSi)
        {
            data = new dtPhieuXuatSi();
            gridDanhSachHangHoa_Temp.DataSource = data.LayDanhSachPhieuXuatSi_Temp(IDPhieuXuatSi);
            gridDanhSachHangHoa_Temp.DataBind();

        }

        protected void cmbHangHoa_ItemRequestedByValue(object source, DevExpress.Web.ListEditItemRequestedByValueEventArgs e)
        {
            long value = 0;
            if (e.Value == null || !Int64.TryParse(e.Value.ToString(), out value))
                return;
            ASPxComboBox comboBox = (ASPxComboBox)source;
            sqlHangHoa.SelectCommand = @"SELECT GPM_HangHoa.ID, GPM_HangHoa.MaHang, GPM_HangHoa.TenHangHoa, GPM_HangHoa.GiaMua, GPM_DonViTinh.TenDonViTinh 
                                        FROM GPM_DonViTinh INNER JOIN GPM_HangHoa ON GPM_DonViTinh.ID = GPM_HangHoa.IDDonViTinh 
                                                           INNER JOIN GPM_HangHoaTonKho ON GPM_HangHoaTonKho.IDHangHoa = GPM_HangHoa.ID 
                                        WHERE (GPM_HangHoa.ID = @ID)";

            sqlHangHoa.SelectParameters.Clear();
            sqlHangHoa.SelectParameters.Add("ID", TypeCode.Int64, e.Value.ToString());
            comboBox.DataSource = sqlHangHoa;
            comboBox.DataBind();
        }

        protected void cmbHangHoa_ItemsRequestedByFilterCondition(object source, DevExpress.Web.ListEditItemsRequestedByFilterConditionEventArgs e)
        {
            ASPxComboBox comboBox = (ASPxComboBox)source;

            sqlHangHoa.SelectCommand = @"SELECT [ID], [MaHang], [TenHangHoa], [GiaMua] , [TenDonViTinh]
                                        FROM (
	                                        select GPM_HangHoa.ID, GPM_HangHoa.MaHang, GPM_HangHoa.TenHangHoa, GPM_HangHoa.GiaMua, GPM_DonViTinh.TenDonViTinh, 
	                                        row_number()over(order by GPM_HangHoa.MaHang) as [rn] 
	                                        FROM GPM_DonViTinh INNER JOIN GPM_HangHoa ON GPM_DonViTinh.ID = GPM_HangHoa.IDDonViTinh 
                                                               INNER JOIN GPM_HangHoaTonKho ON GPM_HangHoaTonKho.IDHangHoa = GPM_HangHoa.ID
	                                        WHERE (GPM_HangHoa.MaHang LIKE @MaHang) AND (GPM_HangHoaTonKho.IDKho = @IDKho) AND (GPM_HangHoaTonKho.DaXoa = 0)	
	                                        ) as st 
                                        where st.[rn] between @startIndex and @endIndex";

            sqlHangHoa.SelectParameters.Clear();
            sqlHangHoa.SelectParameters.Add("MaHang", TypeCode.String, string.Format("%{0}%", e.Filter));
            sqlHangHoa.SelectParameters.Add("IDKho", TypeCode.Int32, dtSetting.LayIDKho() + "");
            sqlHangHoa.SelectParameters.Add("startIndex", TypeCode.Int64, (e.BeginIndex + 1).ToString());
            sqlHangHoa.SelectParameters.Add("endIndex", TypeCode.Int64, (e.EndIndex + 1).ToString());
            comboBox.DataSource = sqlHangHoa;
            comboBox.DataBind();
        }
        
    }
}