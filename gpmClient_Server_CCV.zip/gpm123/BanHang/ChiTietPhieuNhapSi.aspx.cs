﻿using BanHang.Data;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace BanHang
{
    public partial class ChiTietPhieuNhapSi : System.Web.UI.Page
    {
        dtPhieuNhapSi data = new dtPhieuNhapSi();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["KTDangNhap"] == "GPM")
            {
                string IDPhieuNhapSi = Request.QueryString["IDPhieuNhapSi"];
                if (IDPhieuNhapSi != null)
                {

                    LoadGrid(Int32.Parse(IDPhieuNhapSi.ToString()));
                }
            }
            else
            {
                Response.Redirect("DangNhap.aspx");
            }
        }

        private void LoadGrid(int IDPhieuNhapSi)
        {
            data = new dtPhieuNhapSi();
            gridChiTietPhieuNhapSi.DataSource = data.DanhSachChiTietPhieuNhapSi_ID(IDPhieuNhapSi);
            gridChiTietPhieuNhapSi.DataBind();
        }

        protected void gridChiTietPhieuNhapSi_RowDeleting(object sender, DevExpress.Web.Data.ASPxDataDeletingEventArgs e)
        {
            string IDPhieuNhapSi = Request.QueryString["IDPhieuNhapSi"];

            if (IDPhieuNhapSi != null)
            {
                data = new dtPhieuNhapSi();
                DataTable db = data.DanhSachChiTietPhieuNhapSi_ID(Int32.Parse(IDPhieuNhapSi.ToString()));

                if (db.Rows.Count > 1)
                {
                    int ID = Int32.Parse(e.Keys[0].ToString());
                    data = new dtPhieuNhapSi();

                    DataTable da = data.LayChiTietPhieuNhapSi_ID(ID);
                    if (da.Rows.Count != 0)
                    {
                        DataRow dr = da.Rows[0];
                        int SoLuong = Int32.Parse(dr["SoLuong"].ToString());
                        dtLichSuKho.ThemLichSu(ID, Int32.Parse(Session["IDNhanVien"].ToString()), SoLuong * (-1), "Xóa chi tiết phiếu nhập sỉ");
                    }

                    data.XoaChiTietPhieuNhapSi_ID(ID);
                    e.Cancel = true;
                    gridChiTietPhieuNhapSi.CancelEdit();
                    LoadGrid(Int32.Parse(IDPhieuNhapSi.ToString()));

                  
                    dtLichSuTruyCap.ThemLichSu(Session["IDNhanVien"].ToString(), Session["IDNhom"].ToString(), "Chi Tiết Phiếu Nhập Sỉ" + ID, dtSetting.LayIDKho(), "Nhập xuất tồn", "Xóa");   
                }
            }
        }

        protected void gridChiTietPhieuNhapSi_RowUpdating(object sender, DevExpress.Web.Data.ASPxDataUpdatingEventArgs e)
        {
            string IDPhieuNhapSi = Request.QueryString["IDPhieuNhapSi"];
            if (IDPhieuNhapSi != null)
            {
                int ID = Int32.Parse(e.Keys[0].ToString());
                data = new dtPhieuNhapSi();
                DataTable db = data.LayDanhSachChiTietPhieuNhapSi_ID(ID);
                if (db.Rows.Count != 0)
                {
                    int SoLuong = Int32.Parse(e.NewValues["SoLuong"].ToString());
                    DataRow dr1 = db.Rows[0];
                    int IDThue = Int32.Parse(dr1["IDThue"].ToString());
                    int IDHangHoa = Int32.Parse(dr1["IDHangHoa"].ToString());

                    int SLCu = Int32.Parse(dr1["SoLuong"].ToString());
                    DataTable dt = data.LayThongTinVAT(IDThue);
                    if (dt.Rows.Count != 0)
                    {
                        DataRow dr2 = dt.Rows[0];
                        float txtGiaTri = float.Parse(dr2["GiaTri"].ToString());
                        int txtCALCU = Int32.Parse(dr2["IDThue_CALCU"].ToString());
                        float DonGia = float.Parse(dr1["DonGia"].ToString());
                        float GiaTri = float.Parse(txtGiaTri.ToString());

                        if (txtCALCU == 1)
                        {
                            float TienChuaThue = float.Parse(SoLuong * Math.Round((DonGia / (1 + (GiaTri / 100)))) + "");
                            float TienThue = float.Parse(SoLuong * (DonGia - Math.Round((DonGia / (1 + (GiaTri / 100))))) + "");
                            float ThanhTien = float.Parse(SoLuong * DonGia + "");
                            data = new dtPhieuNhapSi();
                            data.CapNhatChiTietPhieuNhapSi_ID(ID, SoLuong, TienChuaThue, TienThue, ThanhTien);
                            dtCapNhatTonKho tk = new dtCapNhatTonKho();

                            dtLichSuKho.ThemLichSu(ID, Int32.Parse(Session["IDNhanVien"].ToString()), (SoLuong - SLCu) * (-1), "Sửa chi tiết phiếu nhập sỉ");

                            tk.CongTonKho_IDHangHoa(IDHangHoa, (SoLuong - SLCu), dtSetting.LayIDKho());
                            DataTable tb = data.DanhSachChiTietPhieuNhapSi_ID(Int32.Parse(IDPhieuNhapSi.ToString()));

                            if (tb.Rows.Count != 0)
                            {
                                float TongTien = 0;
                                foreach (DataRow dr4 in tb.Rows)
                                {
                                    float txtThanhTien = float.Parse(dr4["ThanhTien"].ToString());
                                    TongTien = TongTien + txtThanhTien;
                                }
                                data.CapNhatTongTienPhieuNhapSi_ID(Int32.Parse(IDPhieuNhapSi.ToString()), TongTien);//cập nhật tổng tiền
                            }

                            e.Cancel = true;
                            gridChiTietPhieuNhapSi.CancelEdit();
                            LoadGrid(Int32.Parse(IDPhieuNhapSi.ToString()));
                        }
                        else if (txtCALCU == 2)
                        {
                            float TienChuaThue = float.Parse((SoLuong * DonGia).ToString());
                            float TienThue = float.Parse(txtGiaTri.ToString());
                            float txtTienThue = float.Parse((SoLuong * DonGia * (TienThue / 100)).ToString());
                            float ThanhTien = float.Parse((SoLuong * (DonGia + (DonGia * (TienThue / 100)))).ToString());

                            data = new dtPhieuNhapSi();
                            data.CapNhatChiTietPhieuNhapSi_ID(ID, SoLuong, TienChuaThue, txtTienThue, ThanhTien);
                            dtCapNhatTonKho tk = new dtCapNhatTonKho();

                            dtLichSuKho.ThemLichSu(ID, Int32.Parse(Session["IDNhanVien"].ToString()), (SoLuong - SLCu) * (-1), "Sửa phiếu nhập sỉ");
                            
                            tk.CongTonKho_IDHangHoa(IDHangHoa, (SoLuong - SLCu), dtSetting.LayIDKho());
                            DataTable tb = data.DanhSachChiTietPhieuNhapSi_ID(Int32.Parse(IDPhieuNhapSi.ToString()));

                            if (tb.Rows.Count != 0)
                            {
                                float TongTien = 0;
                                foreach (DataRow dr4 in tb.Rows)
                                {
                                    float txtThanhTien = float.Parse(dr4["ThanhTien"].ToString());
                                    TongTien = TongTien + txtThanhTien;
                                }
                                data.CapNhatTongTienPhieuNhapSi_ID(Int32.Parse(IDPhieuNhapSi.ToString()), TongTien);//cập nhật tổng tiền
                            }
                            e.Cancel = true;
                            gridChiTietPhieuNhapSi.CancelEdit();
                            LoadGrid(Int32.Parse(IDPhieuNhapSi.ToString()));

                        }

                        dtLichSuTruyCap.ThemLichSu(Session["IDNhanVien"].ToString(), Session["IDNhom"].ToString(), "Chi Tiết Phiếu Nhập Sỉ" + ID, dtSetting.LayIDKho(), "Nhập xuất tồn", "Cập Nhật");  
                    }
                }
            }
        }
    }
}