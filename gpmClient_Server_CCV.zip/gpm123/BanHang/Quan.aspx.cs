﻿using BanHang.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace BanHang
{
    public partial class Quan : System.Web.UI.Page
    {
        dtQuan data = new dtQuan();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (dtSetting.LayTrangThaiMenu(Session["IDNhom"].ToString(), 4) == 1)
            {
                LoadGrid();
            }
            else
            {
                Response.Redirect("Default.aspx");
            }
        }

        private void LoadGrid()
        {
            data = new dtQuan();
            gridQuan.DataSource = data.LayDanhSachQuan();
            gridQuan.DataBind();
        }

        protected void gridQuan_RowInserting(object sender, DevExpress.Web.Data.ASPxDataInsertingEventArgs e)
        {
            string districtid = e.NewValues["districtid"].ToString();
            string name = e.NewValues["name"].ToString();
            string type = e.NewValues["type"].ToString();
            string provinceid = e.NewValues["provinceid"].ToString();
            data = new dtQuan();
            data.ThemQuan(districtid, name, type, provinceid);
            e.Cancel = true;
            gridQuan.CancelEdit();
            LoadGrid();

            ActionServer.CapNhatServer();
            dtLichSuTruyCap.ThemLichSu(Session["IDNhanVien"].ToString(), Session["IDNhom"].ToString(), "Quận:" + name, dtSetting.LayIDKho(), "Danh Mục", "Thêm");  
        }

        protected void gridQuan_RowUpdating(object sender, DevExpress.Web.Data.ASPxDataUpdatingEventArgs e)
        {
            string districtid = e.NewValues["districtid"].ToString();
            string name = e.NewValues["name"].ToString();
            string type = e.NewValues["type"].ToString();
            string provinceid = e.NewValues["provinceid"].ToString();
            data.SuaQuan(districtid, name, type, provinceid);
            e.Cancel = true;
            gridQuan.CancelEdit();
            LoadGrid();

            ActionServer.CapNhatServer();
            dtLichSuTruyCap.ThemLichSu(Session["IDNhanVien"].ToString(), Session["IDNhom"].ToString(), "Quận:" + name, dtSetting.LayIDKho(), "Danh Mục", "Cập Nhật");
        }

        protected void gridQuan_RowDeleting(object sender, DevExpress.Web.Data.ASPxDataDeletingEventArgs e)
        {
            string ID = e.Keys[0].ToString();
            data = new dtQuan();
            data.XoaQuan(ID);
            e.Cancel = true;
            gridQuan.CancelEdit();
            LoadGrid();

            ActionServer.CapNhatServer();
            dtLichSuTruyCap.ThemLichSu(Session["IDNhanVien"].ToString(), Session["IDNhom"].ToString(), "Quận:" + ID, dtSetting.LayIDKho(), "Danh Mục", "Xóa");  
        }
    }
}