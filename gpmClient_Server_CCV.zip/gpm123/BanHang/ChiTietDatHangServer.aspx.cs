﻿using BanHang.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace BanHang
{
    public partial class ChiTietDatHangServer : System.Web.UI.Page
    {
        dtDuyetHangNhaCungCap data = new dtDuyetHangNhaCungCap();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["KTDangNhap"] == "GPM")
            {
                string IDDonDatHang = Request.QueryString["IDDonDatHang"];
                if (IDDonDatHang != null)
                {
                    LoadGrid(Int32.Parse(IDDonDatHang.ToString()));
                }
            }
            else
            {
                Response.Redirect("DangNhap.aspx");
            }
        }

        private void LoadGrid(int IDDonDatHang)
        {
            data = new dtDuyetHangNhaCungCap();
            gridChiTietDonHang.DataSource = data.LayDanhSachChiTietDonDatHang(IDDonDatHang);
            gridChiTietDonHang.DataBind();

        }
    }
}