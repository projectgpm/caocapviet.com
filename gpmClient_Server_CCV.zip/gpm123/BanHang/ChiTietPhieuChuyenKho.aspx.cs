﻿using BanHang.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace BanHang
{
    public partial class ChiTietPhieuChuyenKho : System.Web.UI.Page
    {
        dtChuyenKho data = new dtChuyenKho();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["KTDangNhap"] == "GPM")
            {
                string IDPhieuChuyenKho = Request.QueryString["IDPhieuChuyenKho"];
                if (IDPhieuChuyenKho != null)
                {

                    LoadGrid(Int32.Parse(IDPhieuChuyenKho.ToString()));
                }
            }
            else
            {
                Response.Redirect("DangNhap.aspx");
            }
        }

        private void LoadGrid(int IDPhieuChuyenKho)
        {
            gridChiTietPhieuChuyenKho.DataSource = data.LayDanhSachChiTietPhieuChuyenKho_ID(IDPhieuChuyenKho);
            gridChiTietPhieuChuyenKho.DataBind();

        }
        protected void gridChiTietPhieuChuyenKho_RowUpdating(object sender, DevExpress.Web.Data.ASPxDataUpdatingEventArgs e)
        {

        }

        protected void gridChiTietPhieuChuyenKho_RowDeleting(object sender, DevExpress.Web.Data.ASPxDataDeletingEventArgs e)
        {

        }
    }
}