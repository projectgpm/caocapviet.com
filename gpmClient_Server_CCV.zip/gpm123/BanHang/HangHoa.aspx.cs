﻿using BanHang.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using DevExpress.Web;
using System.Data;
using System.IO;
using DevExpress.XtraRichEdit.API.Native;

namespace BanHang
{
    public partial class HangHoa : System.Web.UI.Page
    {
        dataHangHoa data = new dataHangHoa();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["KTDangNhap"] != "GPM")
            {
                Response.Redirect("DangNhap.aspx");
            }
            else
            {
                if (dtSetting.LayTrangThaiMenu_ChucNang(Session["IDNhom"].ToString(), 7) == 1)
                {
                    gridHangHoa.Columns["iconaction"].Visible = false;
                    btnNhapExel.Enabled = false;
                }

                if (dtSetting.LayTrangThaiMenu(Session["IDNhom"].ToString(), 7) == 1)
                {
                    LoadGrid();
                }
                else
                {
                    Response.Redirect("Default.aspx");
                }
            }
        }
        public void LoadGrid()
        {
            gridHangHoa.DataSource = data.getDanhSachHangHoa();
            gridHangHoa.DataBind();
        }

        protected void gridHangHoa_RowDeleting(object sender, DevExpress.Web.Data.ASPxDataDeletingEventArgs e)
        {
            data = new dataHangHoa();
            int ID = Int32.Parse(e.Keys["ID"].ToString());
            data.XoaHangHoa(ID);
            dtKhoHang d = new dtKhoHang();
            d.XoaHang_IDHangHoa(ID);

            e.Cancel = true;
            gridHangHoa.CancelEdit();
            LoadGrid();

            ActionServer.CapNhatServer();
            dtLichSuTruyCap.ThemLichSu(Session["IDNhanVien"].ToString(), Session["IDNhom"].ToString(), "Hàng Hóa", dtSetting.LayIDKho(), "Hàng Hóa", "Xóa: " + ID); 
        }

        protected void gridHangHoa_RowInserting(object sender, DevExpress.Web.Data.ASPxDataInsertingEventArgs e)
        {
            List<string> ListBarCode = GetListBarCode();
            data = new dataHangHoa();

            int IDNhomHang = Int32.Parse(e.NewValues["IDNhomHang"].ToString());
            string MaHang = e.NewValues["MaHang"].ToString();
            dtImportHangHoa hh = new dtImportHangHoa();
            DataTable dd = hh.KiemTraHangHoa(MaHang);
            if (dd.Rows.Count == 0)
            {
                string TenHangHoa = e.NewValues["TenHangHoa"].ToString();
                TenHangHoa = dtSetting.convertDauSangKhongDau(TenHangHoa).ToUpper();
                int IDDonViTinh = Int32.Parse(e.NewValues["IDDonViTinh"].ToString());
                int IDNhaSanXuat = Int32.Parse(e.NewValues["IDNhaSanXuat"].ToString());
                int TrangThai = Int32.Parse(e.NewValues["TrangThai"].ToString());
                float GiaMua = float.Parse(e.NewValues["GiaMua"].ToString());
                float GiaBan1 = float.Parse(e.NewValues["GiaBan1"].ToString());

                float GiaBan2 = float.Parse(e.NewValues["GiaBan2"] != null ? e.NewValues["GiaBan2"].ToString() : "0");
                float GiaBan3 = float.Parse(e.NewValues["GiaBan3"] != null ? e.NewValues["GiaBan3"].ToString() : "0");
                float GiaBan4 = float.Parse(e.NewValues["GiaBan4"] != null ? e.NewValues["GiaBan4"].ToString() : "0");
                float GiaBan5 = float.Parse(e.NewValues["GiaBan5"] != null ? e.NewValues["GiaBan5"].ToString() : "0");
                string GhiChu = e.NewValues["GhiChu"] != null ? e.NewValues["GhiChu"].ToString() : "";

                object IDHangHoa = data.insertHangHoa(IDNhomHang, MaHang, TenHangHoa, IDDonViTinh, IDNhaSanXuat, GiaMua, GiaBan1, GiaBan2, GiaBan3, GiaBan4, GiaBan5, TrangThai, GhiChu);
                if (IDHangHoa != null)
                    data.ThemDanhSachBarCode(IDHangHoa, ListBarCode);
                e.Cancel = true;
                gridHangHoa.CancelEdit();
                LoadGrid();

                ActionServer.CapNhatServer();
                dtLichSuTruyCap.ThemLichSu(Session["IDNhanVien"].ToString(), Session["IDNhom"].ToString(), "Hàng Hóa", dtSetting.LayIDKho(), "Hàng Hóa", "Thêm: " + TenHangHoa);

                // Thêm hàng hóa vào các kho....
                dtThongTinCuaHangKho dt = new dtThongTinCuaHangKho();
                DataTable dta = dt.LayDanhSach();
                for (int i = 0; i < dta.Rows.Count; i++)
                {
                    DataRow dr = dta.Rows[i];
                    int IDKho = Int32.Parse(dr["ID"].ToString());
                    dtHangHoa da = new dtHangHoa();
                    da.ThemHangVaoTonKho(IDKho, (int)IDHangHoa, 0, DateTime.Now, GiaBan1);
                }
            }
            else Response.Write("<script language='JavaScript'> alert('Mã hàng đã tồn tại.'); </script>");
        }

        protected void gridHangHoa_RowUpdating(object sender, DevExpress.Web.Data.ASPxDataUpdatingEventArgs e)
        {
            List<string> ListBarCode = GetListBarCode();
            data = new dataHangHoa();

            int ID = Int32.Parse(e.Keys["ID"].ToString());
            int IDNhomHang = Int32.Parse(e.NewValues["IDNhomHang"].ToString());
            string MaHang = e.NewValues["MaHang"].ToString();
            dtImportHangHoa hh = new dtImportHangHoa();
            DataTable dd = hh.KiemTraHangHoa(MaHang);
            //if (dd.Rows.Count == 0)
            //{
                int TrangThai = Int32.Parse(e.NewValues["TrangThai"].ToString());
                string TenHangHoa = e.NewValues["TenHangHoa"].ToString();
                TenHangHoa = dtSetting.convertDauSangKhongDau(TenHangHoa).ToUpper();
                int IDDonViTinh = Int32.Parse(e.NewValues["IDDonViTinh"].ToString());
                int IDNhaSanXuat = Int32.Parse(e.NewValues["IDNhaSanXuat"].ToString());
                float GiaMua = float.Parse(e.NewValues["GiaMua"].ToString());
                float GiaBan1 = float.Parse(e.NewValues["GiaBan1"].ToString());

                float GiaBan2 = float.Parse(e.NewValues["GiaBan2"].ToString());
                float GiaBan3 = float.Parse(e.NewValues["GiaBan3"].ToString());
                float GiaBan4 = float.Parse(e.NewValues["GiaBan4"].ToString());
                float GiaBan5 = float.Parse(e.NewValues["GiaBan5"].ToString());
                string GhiChu = e.NewValues["GhiChu"] != null ? e.NewValues["GhiChu"].ToString() : "";

                data.SuaThongTinHangHoa(ID, IDNhomHang, MaHang, TenHangHoa, IDDonViTinh, IDNhaSanXuat, GiaMua, GiaBan1, GiaBan2, GiaBan3, GiaBan4, GiaBan5, TrangThai, GhiChu);
                data.SuaDanhSachBarCode(e.Keys["ID"] as object, ListBarCode);
                e.Cancel = true;
                gridHangHoa.CancelEdit();
                LoadGrid();

                ActionServer.CapNhatServer();
                dtLichSuTruyCap.ThemLichSu(Session["IDNhanVien"].ToString(), Session["IDNhom"].ToString(), "Hàng Hóa", dtSetting.LayIDKho(), "Hàng Hóa", "Cập Nhật: " + ID);

                //thêm dữ  liệu vào bảng lịch sử thay đổi giá
                dtHangHoa d1 = new dtHangHoa();
                DataTable dbt = d1.LayDanhSachHangHoa_ID(ID);
                if (dbt.Rows.Count != 0)
                {
                    DataRow drt = dbt.Rows[0];
                    float GiaCu = float.Parse(drt["GiaBan1"].ToString());
                    float GiaMoi = float.Parse(GiaBan1.ToString());
                    int IDNguoiDung = 1; // 
                    if (GiaCu != GiaMoi)
                    {
                        d1 = new dtHangHoa();
                        d1.ThemLichSuThayDoiGia(ID, IDDonViTinh, GiaCu, GiaMoi, IDNguoiDung, MaHang);
                    }
                }
            //}
            //else Response.Write("<script language='JavaScript'> alert('Mã hàng đã tồn tại.'); </script>");
        }

        protected List<string> GetListBarCode()
        {
            ASPxTokenBox tkbListBarCode = gridHangHoa.FindEditFormTemplateControl("tkbListBarCode") as ASPxTokenBox;
            List<string> ListBarCode = new List<string>();
            foreach (string barCode in tkbListBarCode.Tokens)
            {
                ListBarCode.Add(barCode);
            }
            return ListBarCode;
        }

        protected TokenCollection LoadListBarCode(object ID)
        {
            TokenCollection listBarCode = new TokenCollection();
            if (ID != null)
            {
                DataTable dt = data.GetListBarCode(ID);
                foreach (DataRow row in dt.Rows)
                {
                    listBarCode.Add(row["Barcode"].ToString());
                }
            }
            return listBarCode;
        }

        protected void gridBarCode_Init(object sender, EventArgs e)
        {
            data = new dataHangHoa();
            ASPxGridView gridBarCode = sender as ASPxGridView;
            object IDHangHoa = gridBarCode.GetMasterRowKeyValue();
            gridBarCode.DataSource = data.GetListBarCode(IDHangHoa);
            gridBarCode.DataBind();
        }

        protected void gridBarCode_RowUpdating(object sender, DevExpress.Web.Data.ASPxDataUpdatingEventArgs e)
        {
            data = new dataHangHoa();
            ASPxGridView gridBarCode = sender as ASPxGridView;
            int ID = Int32.Parse(e.Keys["ID"].ToString());
            object IDHangHoa = gridBarCode.GetMasterRowKeyValue();
            string BarCode = e.NewValues["Barcode"] != null ? e.NewValues["Barcode"].ToString() : "";
            data.CapNhatBarCode(ID, IDHangHoa, BarCode);
            e.Cancel = true;
            gridBarCode.CancelEdit();
            gridBarCode.DataSource = data.GetListBarCode(IDHangHoa);
            gridBarCode.DataBind();

            ActionServer.CapNhatServer();
            dtLichSuTruyCap.ThemLichSu(Session["IDNhanVien"].ToString(), Session["IDNhom"].ToString(), "Hàng Hóa", dtSetting.LayIDKho(), "Hàng Hóa Barcode", "Cập nhật: " + ID); 
        }

        protected void gridBarCode_RowInserting(object sender, DevExpress.Web.Data.ASPxDataInsertingEventArgs e)
        {
            data = new dataHangHoa();
            ASPxGridView gridBarCode = sender as ASPxGridView;
            object IDHangHoa = gridBarCode.GetMasterRowKeyValue();
            string BarCode = e.NewValues["Barcode"] != null ? e.NewValues["Barcode"].ToString() : "";
            data.ThemBarCode(IDHangHoa, BarCode);
            e.Cancel = true;
            gridBarCode.CancelEdit();
            gridBarCode.DataSource = data.GetListBarCode(IDHangHoa);
            gridBarCode.DataBind();

            ActionServer.CapNhatServer();
            dtLichSuTruyCap.ThemLichSu(Session["IDNhanVien"].ToString(), Session["IDNhom"].ToString(), "Hàng Hóa", dtSetting.LayIDKho(), "Hàng Hóa Barcode", "Thêm: " + BarCode); 
        }

        protected void gridBarCode_RowDeleting(object sender, DevExpress.Web.Data.ASPxDataDeletingEventArgs e)
        {
            data = new dataHangHoa();
            int ID = Int32.Parse(e.Keys["ID"].ToString());
            data.XoaBarCode(ID);
            e.Cancel = true;
            ASPxGridView gridBarCode = sender as ASPxGridView;
            object IDHangHoa = gridBarCode.GetMasterRowKeyValue();
            gridBarCode.DataSource = data.GetListBarCode(IDHangHoa);
            gridBarCode.DataBind();

            ActionServer.CapNhatServer();
            dtLichSuTruyCap.ThemLichSu(Session["IDNhanVien"].ToString(), Session["IDNhom"].ToString(), "Hàng Hóa", dtSetting.LayIDKho(), "Hàng Hóa Barcode", "Xóa: " + ID); 
        }

        protected void btnXuatExcel_Click(object sender, EventArgs e)
        {
            HangHoaExport.DataSource = data.getDanhSachHangHoa_Full_Barcode();
            HangHoaExport.DataBind();
            export.WriteXlsToResponse();
        }

        protected void btnNhapExcel_Click(object sender, EventArgs e)
        {
            Response.Redirect("ImportExcel_HangHoa.aspx");
        }

        protected void btnXuatPDF_Click(object sender, EventArgs e)
        {
            
        }

        protected void XuatFilePDF_Click(object sender, EventArgs e)
        {
            HangHoaExport.DataSource = data.getDanhSachHangHoa_Full_Barcode();
            HangHoaExport.DataBind();
            export.WritePdfToResponse();
        }
    }
}