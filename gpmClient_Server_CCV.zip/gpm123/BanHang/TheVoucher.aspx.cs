﻿using BanHang.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace BanHang
{
    public partial class TheVoucher : System.Web.UI.Page
    {
        dtThevoucher data = new dtThevoucher();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (dtSetting.LayTrangThaiMenu(Session["IDNhom"].ToString(), 59) == 1)
            {
                LoadGrid();
            }
            else
            {
                Response.Redirect("Default.aspx");
            }
        }

        private void LoadGrid()
        {
            data = new dtThevoucher();
            gridTheVoucher.DataSource = data.LayDanhSachThevoucher();
            gridTheVoucher.DataBind();
        }

        protected void gridTheVoucher_RowDeleting(object sender, DevExpress.Web.Data.ASPxDataDeletingEventArgs e)
        {
            int ID = Int32.Parse(e.Keys[0].ToString());
            data = new dtThevoucher();
            data.XoaTheVoucher(ID);
            e.Cancel = true;
            gridTheVoucher.CancelEdit();
            LoadGrid();
            dtLichSuTruyCap.ThemLichSu(Session["IDNhanVien"].ToString(), Session["IDNhom"].ToString(), "Thẻ Voucher", dtSetting.LayIDKho(), "Hệ Thống", "Xóa");
        }

        protected void gridTheVoucher_RowInserting(object sender, DevExpress.Web.Data.ASPxDataInsertingEventArgs e)
        {
            data = new dtThevoucher();
            DateTime NgayCapNhat = DateTime.Today.Date;
            string MaVoucher = e.NewValues["MaVoucher"].ToString();
            string TenVoucher = e.NewValues["TenVoucher"].ToString();
            DateTime TuNgay = DateTime.Parse(e.NewValues["TuNgay"].ToString());
            DateTime DenNgay = DateTime.Parse(e.NewValues["DenNgay"].ToString());
            float GiaTri = float.Parse(e.NewValues["GiaTri"].ToString());
            data.ThemTheVoucher(MaVoucher, TenVoucher, TuNgay, DenNgay, GiaTri, NgayCapNhat);
            e.Cancel = true;
            gridTheVoucher.CancelEdit();
            LoadGrid();
            dtLichSuTruyCap.ThemLichSu(Session["IDNhanVien"].ToString(), Session["IDNhom"].ToString(), "Thẻ Voucher", dtSetting.LayIDKho(), "Hệ Thống", "Thêm");
        }

        protected void gridTheVoucher_RowUpdating(object sender, DevExpress.Web.Data.ASPxDataUpdatingEventArgs e)
        {
            string ID = e.Keys["ID"].ToString();
            string MaVoucher = e.NewValues["MaVoucher"].ToString();
            string TenVoucher = e.NewValues["TenVoucher"].ToString();
            DateTime TuNgay = DateTime.Parse(e.NewValues["TuNgay"].ToString());
            DateTime DenNgay = DateTime.Parse(e.NewValues["DenNgay"].ToString());
            float GiaTri = float.Parse(e.NewValues["GiaTri"].ToString());
            DateTime NgayCapNhat = DateTime.Today.Date;
            data.SuaTheVoucher(Int32.Parse(ID), MaVoucher, TenVoucher, TuNgay, DenNgay, GiaTri, NgayCapNhat);
            e.Cancel = true;
            gridTheVoucher.CancelEdit();
            LoadGrid();
            dtLichSuTruyCap.ThemLichSu(Session["IDNhanVien"].ToString(), Session["IDNhom"].ToString(), "Thẻ Voucher", dtSetting.LayIDKho(), "Hệ Thống", "Cập nhật"); 
        }
    }
}