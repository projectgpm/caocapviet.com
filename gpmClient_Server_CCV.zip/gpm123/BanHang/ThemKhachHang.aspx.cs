﻿using BanHang.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace BanHang
{
    public partial class ThemKhachHang : System.Web.UI.Page
    {
        dtKhachHang data = new dtKhachHang();
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnHuyBo_Click(object sender, EventArgs e)
        {
            Response.Redirect("BanHangLe.aspx");
        }

        protected void btnThemKhachHang_Click(object sender, EventArgs e)
        {
            if (cmbNhomKhachHang.Text != "")
            {
                if (txtTenKhachHang.Text != "")
                {
                    int IDNhomKhachHang = Int32.Parse(cmbNhomKhachHang.Value.ToString());
                    string TenKhachHang = txtTenKhachHang.Text.ToString();
                    DateTime NgaySinh = DateTime.Parse(dtNgaySinh.Text == null ? "" : dtNgaySinh.Text.ToString());
                    string DiaChi = txtDiaChi.Text == null ? "" : txtDiaChi.Text.ToString();
                    string IDThanhPho = cmbThanhPho.Value == null ? "" : cmbThanhPho.Value.ToString();
                    string IDQuan = cmbQuan.Value == null ? "" : cmbQuan.Value.ToString();
                    string CMND = txtCMND.Text == null ? "" : txtCMND.Text.ToString();
                    string DienThoai = txtDienThoai.Text == null ? "" : txtDienThoai.Text.ToString();
                    string Email = txtEMail.Text == null ? "" : txtEMail.Text.ToString();
                    string GhiChu = txtGhiChu.Text == null ? "" : txtGhiChu.Text.ToString();
                    data = new dtKhachHang();
                    //data.ThemKhachHang(IDNhomKhachHang, TenKhachHang, NgaySinh, CMND, DiaChi, Int32.Parse(IDThanhPho), Int32.Parse(IDQuan), DienThoai, Email, "", GhiChu, DateTime.Today);
                    //Response.Redirect("BanHangLe.aspx");
                    
                }
                else
                {
                    Response.Write("<script language='JavaScript'> alert('Vui lòng nhập tên khách hàng.'); </script>");
                }
            }
            else
            {
                Response.Write("<script language='JavaScript'> alert('Vui lòng chọn Nhóm Khách hàng.'); </script>");
            }
        }

        protected void cmbThanhPho_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cmbThanhPho.Text != "")
            {
                string IDthanhPho = cmbThanhPho.Value.ToString();
                data = new dtKhachHang();
                cmbQuan.DataSource =  data.DanhSachQuan_IDThanhPho(IDthanhPho);
                cmbQuan.ValueField = "districtid";
                cmbQuan.TextField = "name";
                cmbQuan.DataBind();
                
            }
        }
    }
}