﻿using BanHang.Data;
using BanHang.Report;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace BanHang
{
    public partial class InBanKePhieuChuyenKho : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            int IDKhoXuat = Int32.Parse(Request.QueryString["khoxuat"]);
            int IDKhoNhap = Int32.Parse(Request.QueryString["khonhap"]);

            dtThongTinCuaHangKho dt = new dtThongTinCuaHangKho();
            DataTable da = dt.LayDanhSach_ID_2(dtSetting.LayIDKho());
            DataRow dr = da.Rows[0];
            string strCty = dr["TenCuaHang"].ToString();
            string strKho1 = "Tất cả kho", strKho2 = "Tất cả kho";
            if (IDKhoXuat != -1)
            {
                dtThongTinCuaHangKho d = new dtThongTinCuaHangKho();
                da = d.LayDanhSach_ID_2(IDKhoXuat);
                if (da.Rows.Count != 0)
                {
                    dr = da.Rows[0];
                    strKho1 = dr["TenCuaHang"].ToString();
                }
            }
            if (IDKhoNhap != -1)
            {
                dtThongTinCuaHangKho d = new dtThongTinCuaHangKho();
                da = d.LayDanhSach_ID_2(IDKhoNhap);
                if (da.Rows.Count != 0)
                {
                    dr = da.Rows[0];
                    strKho2 = dr["TenCuaHang"].ToString();
                }
            }

            rpBangKePhieuChuyenKho rp = new rpBangKePhieuChuyenKho();
            rp.Parameters["strCty"].Value = strCty;
            rp.Parameters["strCty"].Visible = false;
            rp.Parameters["strKho1"].Value = strKho1;
            rp.Parameters["strKho1"].Visible = false;
            rp.Parameters["strKho2"].Value = strKho2;
            rp.Parameters["strKho2"].Visible = false;

            rp.Parameters["KhoXuat"].Value = IDKhoXuat;
            rp.Parameters["KhoNhap"].Value = IDKhoNhap;
            rp.Parameters["KhoXuat"].Visible = false;
            rp.Parameters["KhoNhap"].Visible = false;

            rp.Parameters["NgayBD"].Value = Request.QueryString["ngaybd"] + " 00:00:00.000";
            rp.Parameters["NgayBD"].Visible = false;
            rp.Parameters["NgayKT"].Value = Request.QueryString["ngaykt"] + " 23:59:59.000";
            rp.Parameters["NgayKT"].Visible = false;
            DateTime d1 = DateTime.Parse(Request.QueryString["ngaybd"]);
            string s = d1.Date.ToString("dd/MM/yyyy");
            DateTime d2 = DateTime.Parse(Request.QueryString["ngaykt"]);
            string s2 = d2.Date.ToString("dd/MM/yyyy");
            rp.Parameters["strNgay"].Value = s + " - " + s2;
            rp.Parameters["strNgay"].Visible = false;
            reportView.Report = rp;
        }
    }
}