﻿using BanHang.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace BanHang
{
    public partial class DanhMucThue : System.Web.UI.Page
    {
        dtDanhMucThue data = new dtDanhMucThue();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (dtSetting.LayTrangThaiMenu_ChucNang(Session["IDNhom"].ToString(), 5) == 1)
                gridDanhMucThue.Columns["iconaction"].Visible = false;

            if (dtSetting.LayTrangThaiMenu(Session["IDNhom"].ToString(), 5) == 1)
            {
                LoadGrid();
            }
            else
            {
                Response.Redirect("Default.aspx");
            }
        }
        public void LoadGrid()
        {
            data = new dtDanhMucThue();
            gridDanhMucThue.DataSource = data.LayDanhSachDanhMucThue();
            gridDanhMucThue.DataBind();
        }

        protected void gridDanhMucThue_RowUpdating(object sender, DevExpress.Web.Data.ASPxDataUpdatingEventArgs e)
        {
            string ID = e.Keys["ID"].ToString();
            string TenThue = e.NewValues["TenThue"].ToString();
            string GiaTri = e.NewValues["GiaTri"].ToString();
            string TenTinhThue = e.NewValues["IDThue_CALCU"].ToString();
            string TenLamTron = e.NewValues["IDThue_ROUND"].ToString();
            DateTime NgayCapNhat = DateTime.Today.Date;
            data.SuaDanhMucThue(Int32.Parse(ID), TenThue, float.Parse(GiaTri), Int32.Parse(TenTinhThue), Int32.Parse(TenLamTron), NgayCapNhat);
            e.Cancel = true;
            gridDanhMucThue.CancelEdit();
            LoadGrid();

            ActionServer.CapNhatServer();
            dtLichSuTruyCap.ThemLichSu(Session["IDNhanVien"].ToString(), Session["IDNhom"].ToString(), "Danh Mục Thuế:" + TenThue, dtSetting.LayIDKho(), "Danh Mục", "Cập Nhật"); 
        }

        protected void gridDanhMucThue_RowInserting(object sender, DevExpress.Web.Data.ASPxDataInsertingEventArgs e)
        {
            string TenThue = e.NewValues["TenThue"].ToString();
            string GiaTri = e.NewValues["GiaTri"].ToString();
            string TenTinhThue = e.NewValues["IDThue_CALCU"].ToString();
            string TenLamTron = e.NewValues["IDThue_ROUND"].ToString();
            DateTime NgayCapNhat = DateTime.Today.Date;
            data = new dtDanhMucThue();
            data.ThemDanhMucThue(TenThue, float.Parse(GiaTri), Int32.Parse(TenTinhThue), Int32.Parse(TenLamTron), NgayCapNhat);
            e.Cancel = true;
            gridDanhMucThue.CancelEdit();
            LoadGrid();

            ActionServer.CapNhatServer();
            dtLichSuTruyCap.ThemLichSu(Session["IDNhanVien"].ToString(), Session["IDNhom"].ToString(), "Danh Mục Thuế:" + TenThue, dtSetting.LayIDKho(), "Danh Mục", "Thêm"); 
        }

        protected void gridDanhMucThue_RowDeleting(object sender, DevExpress.Web.Data.ASPxDataDeletingEventArgs e)
        {
            string ID = e.Keys[0].ToString();
            data = new dtDanhMucThue();
            data.XoaDanhMucThue(Int32.Parse(ID));
            e.Cancel = true;
            gridDanhMucThue.CancelEdit();
            LoadGrid();

            ActionServer.CapNhatServer();
            dtLichSuTruyCap.ThemLichSu(Session["IDNhanVien"].ToString(), Session["IDNhom"].ToString(), "Danh Mục Thuế:" + ID, dtSetting.LayIDKho(), "Danh Mục", "Xóa"); 
        }
    }
}