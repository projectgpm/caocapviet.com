﻿using BanHang.Data;
using BanHang.Report;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace BanHang
{
    public partial class InDonDatHang : System.Web.UI.Page
    {
        dtDuyetHangNhaCungCap data = new dtDuyetHangNhaCungCap();
        protected void Page_Load(object sender, EventArgs e)
        {
            int SoDoHang = Int32.Parse(Request.QueryString["SoDoHang"]);
            string TenNhaCungCap = "";
            int IDDonDatHang = -1;
            DataTable dt = data.LayThongTinDonDatHangNCC(SoDoHang);
            if (dt.Rows.Count != 0)
            {
                DataRow dr = dt.Rows[0];
                TenNhaCungCap = dr["TenNhaCungCap"].ToString();
                IDDonDatHang = Int32.Parse(dr["ID"].ToString());
            }
            rpDonDatHang rp = new rpDonDatHang();
            rp.Parameters["TenNhaCungCap"].Value = TenNhaCungCap;
            rp.Parameters["TenNhaCungCap"].Visible = false;
            rp.Parameters["IDDonDatHang"].Value = IDDonDatHang;
            rp.Parameters["IDDonDatHang"].Visible = false;
            reportView.Report = rp;
        }
    }
}