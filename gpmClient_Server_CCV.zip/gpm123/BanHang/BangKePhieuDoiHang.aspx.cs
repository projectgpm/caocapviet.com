﻿using BanHang.Data;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace BanHang
{
    public partial class BangKePhieuDoiHang : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["KTDangNhap"] != "GPM")
            {
                Response.Redirect("DangNhap.aspx");
            }
            else
            {
                if (dtSetting.LayTrangThaiMenu(Session["IDNhom"].ToString(), 26) == 1)
                {
                    if (!IsPostBack)
                    {
                        dtThongTinCuaHangKho d = new dtThongTinCuaHangKho();
                        DataTable dx = d.LayDanhSach();
                        dx.Rows.Add(-1, "Tất cả Cửa Hàng", "", "", 0, 0, "", DateTime.Now.Date, 0);
                        cmbCuaHangKho.DataSource = dx;
                        cmbCuaHangKho.TextField = "TenCuaHang";
                        cmbCuaHangKho.ValueField = "ID";
                        cmbCuaHangKho.DataBind();
                        cmbCuaHangKho.Value = dtSetting.LayIDKho() + "";

                        dtKhachHang d2 = new dtKhachHang();
                        DataTable d2x = d2.LayDanhSachKhachHang();
                        d2x.Rows.Add(-1, 0, 0, "", "Tất cả Khách Hàng", DateTime.Now.Date, "", "", 0, 0, "", "", "", "", 0, DateTime.Now.Date, 0, 0, 0);
                        cmbKhachHang.DataSource = d2x;
                        cmbKhachHang.TextField = "TenKhachHang";
                        cmbKhachHang.ValueField = "ID";
                        cmbKhachHang.DataBind();
                        cmbKhachHang.SelectedIndex = cmbKhachHang.Items.Count;

                        txtNgayBD.Date = DateTime.Today.AddDays(-30);
                        txtNgayKT.Date = DateTime.Today;
                    }
                }
                else
                {
                    Response.Redirect("Default.aspx");
                }
            }
        }

        protected void btnIn_Click(object sender, EventArgs e)
        {
            string ngaybd = txtNgayBD.Date.ToString("yyyy-MM-dd");
            string ngaykt = txtNgayKT.Date.ToString("yyyy-MM-dd");
            string khohang = cmbCuaHangKho.Value + "";
            string khachhang = cmbKhachHang.Value + "";
            popup.ContentUrl = "~/InBangKePhieuDoiHang.aspx?khohang=" + khohang + "&khachhang=" + khachhang + "&ngaybd=" + ngaybd + "&ngaykt=" + ngaykt;
            popup.ShowOnPageLoad = true;
        }
    }
}