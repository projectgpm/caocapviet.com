﻿using BanHang.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace BanHang
{
    public partial class CaBan : System.Web.UI.Page
    {
        dtCaBan data = new dtCaBan();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["KTDangNhap"] != "GPM")
            {
                Response.Redirect("DangNhap.aspx");
            }
            else
            {
                if (dtSetting.LayTrangThaiMenu_ChucNang(Session["IDNhom"].ToString(), 44) == 1)
                    gridCaBan.Columns["iconaction"].Visible = false;

                if (dtSetting.LayTrangThaiMenu(Session["IDNhom"].ToString(), 44) == 1)
                {
                    LoadGrid();
                }
                else
                {
                    Response.Redirect("Default.aspx");
                }
            }
        }

        private void LoadGrid()
        {
            data = new dtCaBan();
            gridCaBan.DataSource = data.LayDanhSachCaBan();
            gridCaBan.DataBind();
        }

        protected void gridCaBan_RowDeleting(object sender, DevExpress.Web.Data.ASPxDataDeletingEventArgs e)
        {
            int ID = Int32.Parse(e.Keys[0].ToString());

            dtLichSuTruyCap.ThemLichSu(Session["IDNhanVien"].ToString(), Session["IDNhom"].ToString(), "Ca Bán", dtSetting.LayIDKho(), "Ca bán", "Xóa");
            data = new dtCaBan();
            data.XoaCaBan(ID);
            e.Cancel = true;
            gridCaBan.CancelEdit();
            LoadGrid();
        }

        protected void gridCaBan_RowInserting(object sender, DevExpress.Web.Data.ASPxDataInsertingEventArgs e)
        {
            string TenCa = e.NewValues["TenCa"].ToString();
            DateTime GioBatDau = DateTime.Parse(e.NewValues["GioBatDau"].ToString());
            DateTime GioKetThuc =DateTime.Parse(e.NewValues["GioKetThuc"].ToString());
            DateTime NgayCapNhat = DateTime.Today.Date;
            dtLichSuTruyCap.ThemLichSu(Session["IDNhanVien"].ToString(), Session["IDNhom"].ToString(), TenCa, dtSetting.LayIDKho(), "Ca bán", "Thêm");

            data = new dtCaBan();
            data.ThemCaBan(TenCa, GioBatDau, GioKetThuc, NgayCapNhat);
            e.Cancel = true;
            gridCaBan.CancelEdit();
            LoadGrid();
        }

        protected void gridCaBan_RowUpdating(object sender, DevExpress.Web.Data.ASPxDataUpdatingEventArgs e)
        {
            string ID = e.Keys["ID"].ToString();
            string TenCa = e.NewValues["TenCa"].ToString();
            dtLichSuTruyCap.ThemLichSu(Session["IDNhanVien"].ToString(), Session["IDNhom"].ToString(), TenCa, dtSetting.LayIDKho(), "Ca bán", "Cập nhật");
            DateTime GioBatDau = DateTime.Parse(e.NewValues["GioBatDau"].ToString());
            DateTime GioKetThuc = DateTime.Parse(e.NewValues["GioKetThuc"].ToString());
            DateTime NgayCapNhat = DateTime.Today.Date;
            data.SuaCaBan(Int32.Parse(ID), TenCa, GioBatDau, GioKetThuc, NgayCapNhat);
            e.Cancel = true;
            gridCaBan.CancelEdit();
            LoadGrid();
        }
    }
}