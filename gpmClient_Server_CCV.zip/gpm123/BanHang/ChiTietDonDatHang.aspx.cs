﻿using BanHang.Data;
using DevExpress.Web;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace BanHang
{
    public partial class ChiTietDonDatHang : System.Web.UI.Page
    {
        dtChiTietDonDatHang data = new dtChiTietDonDatHang();
        
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["KTDangNhap"] == "GPM")
            {
                string IDDonDatHang = Request.QueryString["IDDonDatHang"];
                if (IDDonDatHang != null)
                {
                    LoadGrid(Int32.Parse(IDDonDatHang.ToString()));
                }
            }
            else
            {
                Response.Redirect("DangNhap.aspx"); 
            }
            
        }

        private void LoadGrid(int IDDonDatHang)
        {
            data = new dtChiTietDonDatHang();
            gridChiTietDonHang.DataSource = data.LayDanhSachChiTietDonDatHang(IDDonDatHang);
            gridChiTietDonHang.DataBind();
            
        }

        protected void gridChiTietDonHang_RowDeleting(object sender, DevExpress.Web.Data.ASPxDataDeletingEventArgs e)
        {
            string IDDonDatHang = Request.QueryString["IDDonDatHang"];
            
            if (IDDonDatHang != null)
            {
                data = new dtChiTietDonDatHang();
                DataTable db = data.LayDanhSachChiTietDonDatHang(Int32.Parse(IDDonDatHang.ToString()));


                int aa = db.Rows.Count;

                if (db.Rows.Count > 1)
                {
                    int ID = Int32.Parse(e.Keys[0].ToString());
                    data = new dtChiTietDonDatHang();
                    data.XoaChiTietDonHang(ID);
                    e.Cancel = true;
                    gridChiTietDonHang.CancelEdit();
                    LoadGrid(Int32.Parse(IDDonDatHang.ToString()));
                    dtLichSuTruyCap.ThemLichSu(Session["IDNhanVien"].ToString(), Session["IDNhom"].ToString(), "Chi Tiết Đơn Đặt hàng:" + ID, dtSetting.LayIDKho(), "Nhập xuất tồn", "Xóa"); 
                }
            }
        }
        dtThemDonHang data1 = new dtThemDonHang();


        protected void gridChiTietDonHang_RowUpdating(object sender, DevExpress.Web.Data.ASPxDataUpdatingEventArgs e)
        {
            string IDDonDatHang = Request.QueryString["IDDonDatHang"];
            if (IDDonDatHang != null)
            {
                int ID = Int32.Parse(e.Keys[0].ToString());
                data = new dtChiTietDonDatHang();
                DataTable db = data.LayDanhSachChiTietDonDatHang_ID(ID);
                if (db.Rows.Count != 0)
                {
                    int SoLuong = Int32.Parse(e.NewValues["SoLuong"].ToString());
                    DataRow dr1 = db.Rows[0];
                    int IDHangHoa = Int32.Parse(dr1["IDHangHoa"].ToString());
                    float GiaBan = dtCapNhatTonKho.GiaBan_Client(IDHangHoa);
                    // SendToDatabaseServer.setUpdateChiTietDonDatHang_Sending(IDHangHoa);// Update server
                    float ThanhTien = SoLuong * GiaBan;
                    data = new dtChiTietDonDatHang();
                    data.CapNhatChiTietDonHang_ID(ID, SoLuong, ThanhTien);
                    DataTable tb = data.LayDanhSachChiTietDonDatHang(Int32.Parse(IDDonDatHang.ToString()));
                    if (tb.Rows.Count != 0)
                    {
                        float TongTien = 0;
                        foreach (DataRow dr4 in tb.Rows)
                        {
                            float txtThanhTien = float.Parse(dr4["ThanhTien"].ToString());
                            TongTien = TongTien + txtThanhTien;
                        }
                        data.CapNhatTongTienDonHang_ID(Int32.Parse(IDDonDatHang.ToString()), TongTien);//cập nhật tổng tiền
                        //SendToDatabaseServer.setUpdateChiTietDonDatHang_Sending(ID);// Update server
                    }
                    e.Cancel = true;
                    gridChiTietDonHang.CancelEdit();
                    LoadGrid(Int32.Parse(IDDonDatHang.ToString()));

                }
                dtLichSuTruyCap.ThemLichSu(Session["IDNhanVien"].ToString(), Session["IDNhom"].ToString(), "Chi Tiết Đơn Đặt hàng:", dtSetting.LayIDKho(), "Nhập xuất tồn", "Cập Nhật");
                //SendToDatabaseServer.setUpdateDonDatHang_Sending(Int32.Parse(IDDonDatHang)); // Update server
            }
                

            //=========================================================================================================
            //string IDDonDatHang = Request.QueryString["IDDonDatHang"];
            //if (IDDonDatHang != null)
            //{
            //    int ID = Int32.Parse(e.Keys[0].ToString());
            //    data = new dtChiTietDonDatHang();
            //    DataTable db = data.LayDanhSachChiTietDonDatHang_ID(ID);
            //    if (db.Rows.Count != 0)
            //    {
            //        int SoLuong = Int32.Parse(e.NewValues["SoLuong"].ToString());
            //        DataRow dr1 = db.Rows[0];
            //        int IDThue = Int32.Parse(dr1["IDThue"].ToString());
            //        int IDHangHoa = Int32.Parse(dr1["IDHangHoa"].ToString());

            //        SendToDatabaseServer.setUpdateChiTietDonDatHang_Sending(IDHangHoa);// Update server
                    
            //        dtThemDonHang data1 = new dtThemDonHang();
            //        DataTable dt = data1.LayThongTinVAT(IDThue);
            //        if (dt.Rows.Count != 0)
            //        {
            //            DataRow dr2 = dt.Rows[0];
            //            float txtGiaTri = float.Parse(dr2["GiaTri"].ToString());
            //            int txtCALCU = Int32.Parse(dr2["IDThue_CALCU"].ToString());
            //            float DonGia = float.Parse(dr1["DonGia"].ToString());
            //            float GiaTri = float.Parse(txtGiaTri.ToString());

            //            if (txtCALCU == 1)
            //            {
            //                float TienChuaThue = float.Parse(SoLuong * Math.Round((DonGia / (1 + (GiaTri / 100)))) + "");
            //                float TienThue = float.Parse(SoLuong * (DonGia - Math.Round((DonGia / (1 + (GiaTri / 100))))) + "");
            //                float ThanhTien = float.Parse(SoLuong * DonGia + "");
            //                data = new dtChiTietDonDatHang();
            //                data.CapNhatChiTietDonHang_ID(ID, SoLuong, TienChuaThue, TienThue, ThanhTien);



            //                DataTable tb = data.LayDanhSachChiTietDonDatHang(Int32.Parse(IDDonDatHang.ToString()));

            //                if (tb.Rows.Count != 0)
            //                {
            //                    float TongTien = 0;
            //                    foreach (DataRow dr4 in tb.Rows)
            //                    {
            //                        float txtThanhTien = float.Parse(dr4["ThanhTien"].ToString());
            //                        TongTien = TongTien + txtThanhTien;
            //                    }
            //                    data.CapNhatTongTienDonHang_ID(Int32.Parse(IDDonDatHang.ToString()),TongTien);//cập nhật tổng tiền
            //                    SendToDatabaseServer.setUpdateChiTietDonDatHang_Sending(ID);// Update server
            //                }
                                
            //                e.Cancel = true;
            //                gridChiTietDonHang.CancelEdit();
            //                LoadGrid(Int32.Parse(IDDonDatHang.ToString()));
            //            }
            //            else if (txtCALCU == 2)
            //            {
            //                float TienChuaThue = float.Parse((SoLuong * DonGia).ToString());
            //                float TienThue = float.Parse(txtGiaTri.ToString());
            //                float txtTienThue = float.Parse((SoLuong * DonGia * (TienThue / 100)).ToString());
            //                float ThanhTien = float.Parse((SoLuong * (DonGia + (DonGia * (TienThue / 100)))).ToString());
                                    
            //                data = new dtChiTietDonDatHang();
            //                data.CapNhatChiTietDonHang_ID(ID, SoLuong, TienChuaThue, txtTienThue, ThanhTien);
            //                DataTable tb = data.LayDanhSachChiTietDonDatHang(Int32.Parse(IDDonDatHang.ToString()));

            //                if (tb.Rows.Count != 0)
            //                {
            //                    float TongTien = 0;
            //                    foreach (DataRow dr4 in tb.Rows)
            //                    {
            //                        float txtThanhTien = float.Parse(dr4["ThanhTien"].ToString());
            //                        TongTien = TongTien + txtThanhTien;
            //                    }
            //                    data.CapNhatTongTienDonHang_ID(Int32.Parse(IDDonDatHang.ToString()), TongTien);//cập nhật tổng tiền
            //                    SendToDatabaseServer.setUpdateChiTietDonDatHang_Sending(ID);// Update server
            //                }
            //                e.Cancel = true;
            //                gridChiTietDonHang.CancelEdit();
            //                LoadGrid(Int32.Parse(IDDonDatHang.ToString()));

            //            }
                            
                        
            //        }
            //    }
            //    dtLichSuTruyCap.ThemLichSu(Session["IDNhanVien"].ToString(), Session["IDNhom"].ToString(), "Chi Tiết Đơn Đặt hàng:" + ID, dtSetting.LayIDKho(), "Nhập xuất tồn", "Cập Nhật");   
            //    SendToDatabaseServer.setUpdateDonDatHang_Sending(Int32.Parse(IDDonDatHang)); // Update server
            //}


        }

    }
}