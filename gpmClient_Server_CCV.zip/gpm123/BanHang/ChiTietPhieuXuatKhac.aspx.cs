﻿using BanHang.Data;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace BanHang
{
    public partial class ChiTietPhieuXuatKhac : System.Web.UI.Page
    {
        dtPhieuXuatKhac data = new dtPhieuXuatKhac();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["KTDangNhap"] == "GPM")
            {
                string IDPhieuXuatKhac = Request.QueryString["IDPhieuXuatKhac"];
                if (IDPhieuXuatKhac != null)
                {

                    LoadGrid(Int32.Parse(IDPhieuXuatKhac.ToString()));
                }
            }
            else
            {
                Response.Redirect("DangNhap.aspx");
            }
        }
        private void LoadGrid(int IDPhieuXuatKhac)
        {
            data = new dtPhieuXuatKhac();
            gridChiTietPhieuXuatKhac.DataSource = data.DanhSachChiTietPhieuXuatKhac_ID(IDPhieuXuatKhac);
            gridChiTietPhieuXuatKhac.DataBind();
        }

        protected void gridChiTietPhieuXuatKhac_RowUpdating(object sender, DevExpress.Web.Data.ASPxDataUpdatingEventArgs e)
        {
            string IDPhieuXuatKhac = Request.QueryString["IDPhieuXuatKhac"];
            if (IDPhieuXuatKhac != null)
            {
                int ID = Int32.Parse(e.Keys[0].ToString());
                data = new dtPhieuXuatKhac();
                DataTable db = data.LayDanhSachChiTietPhieuXuatKhac_ID(ID);
                if (db.Rows.Count != 0)
                {
                    int SoLuong = Int32.Parse(e.NewValues["SoLuong"].ToString());
                    
                    DataRow dr1 = db.Rows[0];

                    int IDHangHoa = Int32.Parse(dr1["IDHangHoa"].ToString());
                    int SLCu = Int32.Parse(dr1["SoLuong"].ToString());

                    data = new dtPhieuXuatKhac();

                    data.CapNhatChiTietPhieuXuatKhac_ID(ID, SoLuong);
                    dtCapNhatTonKho tk = new dtCapNhatTonKho();

                    dtLichSuKho.ThemLichSu(IDHangHoa, Int32.Parse(Session["IDNhanVien"].ToString()), SoLuong - SLCu, "Cập nhật chi tiết phiếu xuất khác");

                    tk.TruTonKho_IDHangHoa(IDHangHoa, SoLuong - SLCu, dtSetting.LayIDKho());
                    e.Cancel = true;
                    gridChiTietPhieuXuatKhac.CancelEdit();
                    LoadGrid(Int32.Parse(IDPhieuXuatKhac.ToString()));
                    dtLichSuTruyCap.ThemLichSu(Session["IDNhanVien"].ToString(), Session["IDNhom"].ToString(), "Chi Tiết Phiếu Xuất Khác" + ID, dtSetting.LayIDKho(), "Nhập xuất tồn", "Cập Nhật");   
                }
            }
        }

        protected void gridChiTietPhieuXuatKhac_RowDeleting(object sender, DevExpress.Web.Data.ASPxDataDeletingEventArgs e)
        {

        }

       
    }
}