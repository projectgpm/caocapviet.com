﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace BanHang.Data
{
    public class dtChietKhauNhomHang
    {
        public DataTable LayDanhSachChietKhauNhomHang()
        {
            using (SqlConnection con = new SqlConnection(StaticContext.ConnectionString))
            {
                con.Open();
                string cmdText = "SELECT * FROM [GPM_ChietKhauNhomHang] WHERE DaXoa = 0";
                using (SqlCommand command = new SqlCommand(cmdText, con))
                using (SqlDataReader reader = command.ExecuteReader())
                {
                    DataTable tb = new DataTable();
                    tb.Load(reader);
                    return tb;
                }
            }
        }
        public void ThemChietKhauNhomHang(int IDNhomHang, float GiaTri, DateTime NgayBatDau, DateTime NgayKetThuc, DateTime NgayCapNhat)
        {
            using (SqlConnection myConnection = new SqlConnection(StaticContext.ConnectionString))
            {
                try
                {
                    myConnection.Open();
                    string cmdText = "INSERT INTO [GPM_ChietKhauNhomHang] ( [IDNhomHang],[GiaTri], [NgayBatDau], [NgayKetThuc], [NgayCapNhat]) VALUES (@IDNhomHang, @GiaTri, @NgayBatDau, @NgayKetThuc, @NgayCapNhat)";
                    using (SqlCommand myCommand = new SqlCommand(cmdText, myConnection))
                    {
                        myCommand.Parameters.AddWithValue("@IDNhomHang", IDNhomHang);
                        myCommand.Parameters.AddWithValue("@GiaTri", GiaTri);
                        myCommand.Parameters.AddWithValue("@NgayBatDau", NgayBatDau);
                        myCommand.Parameters.AddWithValue("@NgayKetThuc", NgayKetThuc);
                        myCommand.Parameters.AddWithValue("@NgayCapNhat", NgayCapNhat);
                        myCommand.ExecuteNonQuery();
                    }
                    myConnection.Close();
                }
                catch
                {
                    throw new Exception("Lỗi: Quá trình thêm dữ liệu gặp lỗi");
                }
            }
        }

        public void ThemChietKhauNhomHang_Full(int IDNhomHang, float GiaTri, DateTime NgayBatDau, DateTime NgayKetThuc, DateTime NgayCapNhat, int DaXoa)
        {
            using (SqlConnection myConnection = new SqlConnection(StaticContext.ConnectionString))
            {
                try
                {
                    myConnection.Open();
                    string cmdText = "INSERT INTO [GPM_ChietKhauNhomHang] ( [IDNhomHang],[GiaTri], [NgayBatDau], [NgayKetThuc], [NgayCapNhat],[DaXoa]) VALUES (@IDNhomHang, @GiaTri, @NgayBatDau, @NgayKetThuc, @NgayCapNhat,@DaXoa)";
                    using (SqlCommand myCommand = new SqlCommand(cmdText, myConnection))
                    {
                        myCommand.Parameters.AddWithValue("@IDNhomHang", IDNhomHang);
                        myCommand.Parameters.AddWithValue("@GiaTri", GiaTri);
                        myCommand.Parameters.AddWithValue("@NgayBatDau", NgayBatDau);
                        myCommand.Parameters.AddWithValue("@NgayKetThuc", NgayKetThuc);
                        myCommand.Parameters.AddWithValue("@NgayCapNhat", NgayCapNhat);
                        myCommand.Parameters.AddWithValue("@DaXoa", DaXoa);
                        myCommand.ExecuteNonQuery();
                    }
                    myConnection.Close();
                }
                catch
                {
                    throw new Exception("Lỗi: Quá trình thêm dữ liệu gặp lỗi");
                }
            }
        }
        public void SuaChietKhauNhomHang_NhomHang(int IDNhomHang, float GiaTri, DateTime NgayBatDau, DateTime NgayKetThuc, DateTime NgayCapNhat)
        {
            using (SqlConnection myConnection = new SqlConnection(StaticContext.ConnectionString))
            {
                try
                {
                    myConnection.Open();
                    string cmdText = "UPDATE [GPM_ChietKhauNhomHang] SET [GiaTri] = @GiaTri, [NgayBatDau] = @NgayBatDau, [NgayKetThuc] = @NgayKetThuc, [NgayCapNhat] = @NgayCapNhat WHERE [@IDNhomHang] = @IDNhomHang";
                    using (SqlCommand myCommand = new SqlCommand(cmdText, myConnection))
                    {
                        myCommand.Parameters.AddWithValue("@IDNhomHang", IDNhomHang);
                        myCommand.Parameters.AddWithValue("@GiaTri", GiaTri);
                        myCommand.Parameters.AddWithValue("@NgayBatDau", NgayBatDau);
                        myCommand.Parameters.AddWithValue("@NgayKetThuc", NgayKetThuc);
                        myCommand.Parameters.AddWithValue("@NgayCapNhat", NgayCapNhat);
                        myCommand.ExecuteNonQuery();
                    }
                    myConnection.Close();
                }
                catch
                {
                    throw new Exception("Lỗi: Quá trình thêm dữ liệu gặp lỗi");
                }
            }
        }
        public void SuaChietKhauNhomHang(int ID,int IDNhomHang, float GiaTri, DateTime NgayBatDau, DateTime NgayKetThuc, DateTime NgayCapNhat)
        {
            using (SqlConnection myConnection = new SqlConnection(StaticContext.ConnectionString))
            {
                try
                {
                    myConnection.Open();
                    string cmdText = "UPDATE [GPM_ChietKhauNhomHang] SET [IDNhomHang] = @IDNhomHang,[GiaTri] = @GiaTri, [NgayBatDau] = @NgayBatDau, [NgayKetThuc] = @NgayKetThuc, [NgayCapNhat] = @NgayCapNhat WHERE [@ID] = @ID";
                    using (SqlCommand myCommand = new SqlCommand(cmdText, myConnection))
                    {
                        myCommand.Parameters.AddWithValue("@ID", ID);
                        myCommand.Parameters.AddWithValue("@IDNhomHang", IDNhomHang);
                        myCommand.Parameters.AddWithValue("@GiaTri", GiaTri);
                        myCommand.Parameters.AddWithValue("@NgayBatDau", NgayBatDau);
                        myCommand.Parameters.AddWithValue("@NgayKetThuc", NgayKetThuc);
                        myCommand.Parameters.AddWithValue("@NgayCapNhat", NgayCapNhat);
                        myCommand.ExecuteNonQuery();
                    }
                    myConnection.Close();
                }
                catch
                {
                    throw new Exception("Lỗi: Quá trình thêm dữ liệu gặp lỗi");
                }
            }
        }

        public void SuaChietKhauNhomHang_Full(int ID, int IDNhomHang, float GiaTri, DateTime NgayBatDau, DateTime NgayKetThuc, DateTime NgayCapNhat, int DaXoa)
        {
            using (SqlConnection myConnection = new SqlConnection(StaticContext.ConnectionString))
            {
                try
                {
                    myConnection.Open();
                    string cmdText = "UPDATE [GPM_ChietKhauNhomHang] SET [IDNhomHang] = @IDNhomHang,[GiaTri] = @GiaTri, [NgayBatDau] = @NgayBatDau, [NgayKetThuc] = @NgayKetThuc, [NgayCapNhat] = @NgayCapNhat,[DaXoa] = @DaXoa WHERE [@ID] = @ID";
                    using (SqlCommand myCommand = new SqlCommand(cmdText, myConnection))
                    {
                        myCommand.Parameters.AddWithValue("@ID", ID);
                        myCommand.Parameters.AddWithValue("@IDNhomHang", IDNhomHang);
                        myCommand.Parameters.AddWithValue("@GiaTri", GiaTri);
                        myCommand.Parameters.AddWithValue("@NgayBatDau", NgayBatDau);
                        myCommand.Parameters.AddWithValue("@NgayKetThuc", NgayKetThuc);
                        myCommand.Parameters.AddWithValue("@NgayCapNhat", NgayCapNhat);
                        myCommand.Parameters.AddWithValue("@DaXoa", DaXoa);
                        myCommand.ExecuteNonQuery();
                    }
                    myConnection.Close();
                }
                catch
                {
                    throw new Exception("Lỗi: Quá trình thêm dữ liệu gặp lỗi");
                }
            }
        }
        public void XoaChietKhauNhomHang(int ID)
        {
            using (SqlConnection myConnection = new SqlConnection(StaticContext.ConnectionString))
            {
                try
                {
                    myConnection.Open();
                    string strSQL = "UPDATE [GPM_ChietKhauNhomHang] SET [DaXoa] = 1 WHERE [ID] = @ID";
                    using (SqlCommand myCommand = new SqlCommand(strSQL, myConnection))
                    {
                        myCommand.Parameters.AddWithValue("@ID", ID);
                        myCommand.ExecuteNonQuery();
                    }
                }
                catch (Exception e)
                {
                    throw new Exception("Lỗi: Quá trình cập nhật dữ liệu gặp lỗi, hãy tải lại trang");
                }
            }
        }
    }
}