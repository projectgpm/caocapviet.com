﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace BanHang.Data
{
    public class dtNhanVienThuNgan
    {
        public DataTable LayDanhSachNhanVienThuNgan()
        {
            using (SqlConnection con = new SqlConnection(StaticContext.ConnectionString))
            {
                con.Open();
                string cmdText = "SELECT [GPM_NhanVienThuNgan].ID,[GPM_NhanVienThuNgan].IDCaBan,[GPM_NhanVienThuNgan].MatKhau,[GPM_NhanVienThuNgan].TenDangNhap,[GPM_NhanVienThuNgan].NgayCapNhat,[GPM_NhanVienThuNgan].TenNhanVien,[GPM_NhanVienThuNgan].TrangThai,[GPM_CaBan].TenCa FROM [GPM_NhanVienThuNgan],[GPM_CaBan] WHERE [GPM_CaBan].ID = [GPM_NhanVienThuNgan].IDCaBan AND [GPM_NhanVienThuNgan].DaXoa = 0";
                using (SqlCommand command = new SqlCommand(cmdText, con))
                using (SqlDataReader reader = command.ExecuteReader())
                {
                    DataTable tb = new DataTable();
                    tb.Load(reader);
                    return tb;
                }
            }
        }
        public DataTable KiemTraNhanVien(string TenDangNhap)
        {
            using (SqlConnection con = new SqlConnection(StaticContext.ConnectionString))
            {
                con.Open();
                string cmdText = "SELECT * FROM [GPM_NhanVienThuNgan] WHERE TenDangNhap = " + TenDangNhap;
                using (SqlCommand command = new SqlCommand(cmdText, con))
                using (SqlDataReader reader = command.ExecuteReader())
                {
                    DataTable tb = new DataTable();
                    tb.Load(reader);
                    return tb;
                }
            }
        }

        public void ThemNhanVienThuNgan(string TenNhanVien, string TenDangNhap,int IDCaBan,string MatKhau, int TrangThai)
        {
            using (SqlConnection myConnection = new SqlConnection(StaticContext.ConnectionString))
            {
                try
                {
                    myConnection.Open();
                    string cmdText = "INSERT INTO [GPM_NhanVienThuNgan] ([TenNhanVien],[TenDangNhap],[IDCaBan],[MatKhau],[TrangThai], [NgayCapNhat]) VALUES (@TenNhanVien,@TenDangNhap, @IDCaBan,@MatKhau, @TrangThai ,getdate())";
                    using (SqlCommand myCommand = new SqlCommand(cmdText, myConnection))
                    {
                        myCommand.Parameters.AddWithValue("@TenNhanVien", TenNhanVien);
                        myCommand.Parameters.AddWithValue("@TenDangNhap", TenDangNhap);
                        myCommand.Parameters.AddWithValue("@IDCaBan", IDCaBan);
                        myCommand.Parameters.AddWithValue("@MatKhau", MatKhau);
                        myCommand.Parameters.AddWithValue("@TrangThai", TrangThai);
                        myCommand.ExecuteNonQuery();
                    }
                    myConnection.Close();
                }
                catch
                {
                    throw new Exception("Lỗi: Quá trình thêm dữ liệu gặp lỗi");
                }
            }
        }

        public void XoaNhanVienThuNgan(int ID)
        {
            using (SqlConnection myConnection = new SqlConnection(StaticContext.ConnectionString))
            {
                try
                {
                    myConnection.Open();
                    string strSQL = "UPDATE [GPM_NhanVienThuNgan] SET [DAXOA] = 1 WHERE [ID] = @ID";
                    using (SqlCommand myCommand = new SqlCommand(strSQL, myConnection))
                    {
                        myCommand.Parameters.AddWithValue("@ID", ID);
                        myCommand.ExecuteNonQuery();
                    }
                }
                catch (Exception e)
                {
                    throw new Exception("Lỗi: Quá trình Xóa dữ liệu gặp lỗi, hãy tải lại trang");
                }
            }
        }



        public void SuaNhanVienThuNgan(int ID, string TenNhanVien,string TenDangNhap, int IDCaBan, string MatKhau, int TrangThai)
        {
            using (SqlConnection myConnection = new SqlConnection(StaticContext.ConnectionString))
            {
                try
                {
                    myConnection.Open();
                    string strSQL = "UPDATE [GPM_NhanVienThuNgan] SET [TenNhanVien] = @TenNhanVien,[TenDangNhap] = @TenDangNhap, [IDCaBan] = @IDCaBan, [MatKhau] = @MatKhau, [TrangThai] = @TrangThai,[NgayCapNhat] = getdate() WHERE [ID] = @ID";
                    using (SqlCommand myCommand = new SqlCommand(strSQL, myConnection))
                    {
                        myCommand.Parameters.AddWithValue("@ID", ID);
                        myCommand.Parameters.AddWithValue("@TenNhanVien", TenNhanVien);
                        myCommand.Parameters.AddWithValue("@IDCaBan", IDCaBan);
                        myCommand.Parameters.AddWithValue("@TenDangNhap", TenDangNhap);
                        myCommand.Parameters.AddWithValue("@MatKhau", MatKhau);
                        myCommand.Parameters.AddWithValue("@TrangThai", TrangThai);
                        myCommand.ExecuteNonQuery();
                    }
                }
                catch (Exception e)
                {
                    throw new Exception("Lỗi: Quá trình cập nhật dữ liệu gặp lỗi, hãy tải lại trang");
                }
            }
        }
    }
}