﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.SqlClient;

namespace BanHang.Data
{
    public class dtDanhMucThue
    {
        public DataTable LayDanhSachDanhMucThue()
        {
            using (SqlConnection con = new SqlConnection(StaticContext.ConnectionString))
            {
                con.Open();
                string cmdText = " SELECT [GPM_Thue].ID ,[GPM_Thue].TenThue,[GPM_Thue].IDThue_ROUND,[GPM_Thue].IDThue_CALCU,[GPM_Thue].NgayCapNhat ,[GPM_Thue].GiaTri, [GPM_Thue_CALCU].Ten as TenTinhThue, [GPM_Thue_ROUND].Ten as TenLamTron FROM [GPM_Thue],[GPM_Thue_CALCU],[GPM_Thue_ROUND] WHERE [GPM_Thue].IDThue_CALCU = [GPM_Thue_CALCU].ID AND [GPM_Thue].IDThue_ROUND = [GPM_Thue_ROUND].ID AND [GPM_Thue].DaXoa = 0 ";
                using (SqlCommand command = new SqlCommand(cmdText, con))
                using (SqlDataReader reader = command.ExecuteReader())
                {
                    DataTable tb = new DataTable();
                    tb.Load(reader);
                    return tb;
                }
            }
        }

        public void ThemDanhMucThue(string TenThue, float GiaTri, int IDThue_CALCU, int IDThue_ROUND, DateTime NgayCapNhat)
        {
            using (SqlConnection myConnection = new SqlConnection(StaticContext.ConnectionString))
            {
                try
                {
                    myConnection.Open();
                    string cmdText = "INSERT INTO [GPM_Thue] ([TenThue], [GiaTri], [IDThue_CALCU], [IDThue_ROUND], [NgayCapNhat]) VALUES (@TenThue, @GiaTri, @IDThue_CALCU, @IDThue_ROUND, @NgayCapNhat)";
                    using (SqlCommand myCommand = new SqlCommand(cmdText, myConnection))
                    {
                        myCommand.Parameters.AddWithValue("@TenThue", TenThue);
                        myCommand.Parameters.AddWithValue("@GiaTri", GiaTri);
                        myCommand.Parameters.AddWithValue("@IDThue_CALCU", IDThue_CALCU);
                        myCommand.Parameters.AddWithValue("@IDThue_ROUND", IDThue_ROUND);
                        myCommand.Parameters.AddWithValue("@NgayCapNhat", NgayCapNhat);
                        myCommand.ExecuteNonQuery();
                    }
                    myConnection.Close();
                }
                catch
                {
                    throw new Exception("Lỗi: Quá trình thêm dữ liệu gặp lỗi");
                }
            }
        }

        public void XoaDanhMucThue(int ID)
        {
            using (SqlConnection myConnection = new SqlConnection(StaticContext.ConnectionString))
            {
                try
                {
                    myConnection.Open();
                    string strSQL = "UPDATE [GPM_Thue] SET [DAXOA] = 1 WHERE [ID] = @ID";
                    using (SqlCommand myCommand = new SqlCommand(strSQL, myConnection))
                    {
                        myCommand.Parameters.AddWithValue("@ID", ID);
                        myCommand.ExecuteNonQuery();
                    }
                }
                catch (Exception e)
                {
                    throw new Exception("Lỗi: Quá trình Xóa dữ liệu gặp lỗi, hãy tải lại trang");
                }
            }
        }

        public void SuaDanhMucThue(int ID, string TenThue, float GiaTri, int IDThue_CALCU, int IDThue_ROUND, DateTime NgayCapNhat)
        {
            using (SqlConnection myConnection = new SqlConnection(StaticContext.ConnectionString))
            {
                try
                {
                    myConnection.Open();
                    string strSQL = "UPDATE [GPM_Thue] SET [TenThue] = @TenThue, [GiaTri] = @GiaTri, [IDThue_CALCU] = @IDThue_CALCU, [IDThue_ROUND] = @IDThue_ROUND, [NgayCapNhat] = @NgayCapNhat WHERE [ID] = @ID";
                    using (SqlCommand myCommand = new SqlCommand(strSQL, myConnection))
                    {
                        myCommand.Parameters.AddWithValue("@ID", ID);
                        myCommand.Parameters.AddWithValue("@TenThue", TenThue);
                        myCommand.Parameters.AddWithValue("@GiaTri", GiaTri);
                        myCommand.Parameters.AddWithValue("@IDThue_CALCU", IDThue_CALCU);
                        myCommand.Parameters.AddWithValue("@IDThue_ROUND", IDThue_ROUND);
                        myCommand.Parameters.AddWithValue("@NgayCapNhat", NgayCapNhat);
                        myCommand.ExecuteNonQuery();
                    }
                }
                catch (Exception e)
                {
                    throw new Exception("Lỗi: Quá trình cập nhật dữ liệu gặp lỗi, hãy tải lại trang");
                }
            }
        }
    }
}