﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace BanHang.Data
{
    public class dataNhomHang
    {

        public DataTable getData(string cmd)
        {
            using (SqlConnection con = new SqlConnection(StaticContext.ConnectionString))
            {
                try
                {
                    con.Open();
                    using (SqlCommand command = new SqlCommand(cmd, con))
                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        DataTable tb = new DataTable();
                        tb.Load(reader);
                        return tb;
                    }
                }
                catch (Exception) { return new DataTable(); }
            }
        }

        public DataTable getDanhSachNhomHang()
        {
            string cmd = "SELECT * FROM [GPM_NHOMHANG] WHERE [DAXOA] = 0";
            return getData(cmd);
        }

        public void XoaNhomHang(int ID)
        {
            using (SqlConnection myConnection = new SqlConnection(StaticContext.ConnectionString))
            {
                try
                {
                    myConnection.Open();
                    string strSQL = "UPDATE [GPM_NHOMHANG] SET [DAXOA] = 1 WHERE [ID] = @ID";
                    using (SqlCommand myCommand = new SqlCommand(strSQL, myConnection))
                    {
                        myCommand.Parameters.AddWithValue("@ID", ID);
                        myCommand.ExecuteNonQuery();
                    }
                }
                catch (Exception e)
                {
                    throw new Exception("Lỗi: Quá trình cập nhật dữ liệu gặp lỗi, hãy tải lại trang");
                }
            }
        }

        public void updateNhomHang(int ID, int IDNganhHang, string MaNhom, string TenNhomHang, string GhiChu)
        {
            using (SqlConnection myConnection = new SqlConnection(StaticContext.ConnectionString))
            {
                try
                {
                    myConnection.Open();
                    string strSQL = "UPDATE [GPM_NHOMHANG] SET [IDNganhHang] = @IDNganhHang,[MaNhom] = @MaNhom,[TenNhomHang]=@TenNhomHang,[GhiChu] = @GhiChu, [NgayCapNhat] = getDATE() WHERE [ID] = @ID";
                    using (SqlCommand myCommand = new SqlCommand(strSQL, myConnection))
                    {
                        myCommand.Parameters.AddWithValue("@ID", ID);
                        myCommand.Parameters.AddWithValue("@IDNganhHang", IDNganhHang);
                        myCommand.Parameters.AddWithValue("@MaNhom", MaNhom);
                        myCommand.Parameters.AddWithValue("@TenNhomHang", TenNhomHang);
                        myCommand.Parameters.AddWithValue("@GhiChu", GhiChu);
                        myCommand.ExecuteNonQuery();
                    }
                }
                catch (Exception e)
                {
                    throw new Exception("Lỗi: Quá trình cập nhật dữ liệu gặp lỗi, hãy tải lại trang");
                }
            }
        }


        public void updateNhomHang_Full(int ID, int IDNganhHang, string MaNhom, string TenNhomHang, string GhiChu, int DaXoa)
        {
            using (SqlConnection myConnection = new SqlConnection(StaticContext.ConnectionString))
            {
                try
                {
                    myConnection.Open();
                    string strSQL = "UPDATE [GPM_NHOMHANG] SET [IDNganhHang] = @IDNganhHang,[MaNhom] = @MaNhom,[TenNhomHang]=@TenNhomHang,[GhiChu] = @GhiChu, [DaXoa] = @DaXoa, [NgayCapNhat] = getDATE() WHERE [ID] = @ID";
                    using (SqlCommand myCommand = new SqlCommand(strSQL, myConnection))
                    {
                        myCommand.Parameters.AddWithValue("@ID", ID);
                        myCommand.Parameters.AddWithValue("@IDNganhHang", IDNganhHang);
                        myCommand.Parameters.AddWithValue("@MaNhom", MaNhom);
                        myCommand.Parameters.AddWithValue("@TenNhomHang", TenNhomHang);
                        myCommand.Parameters.AddWithValue("@GhiChu", GhiChu);
                        myCommand.Parameters.AddWithValue("@DaXoa", DaXoa);
                        myCommand.ExecuteNonQuery();
                    }
                }
                catch (Exception e)
                {
                    throw new Exception("Lỗi: Quá trình cập nhật dữ liệu gặp lỗi, hãy tải lại trang");
                }
            }
        }

        public void insertNhomHang(int IDNganhHang, string MaNhom, string TenNhomHang, string GhiChu)
        {
            using (SqlConnection myConnection = new SqlConnection(StaticContext.ConnectionString))
            {
                try
                {
                    myConnection.Open();
                    string cmdText = "INSERT INTO [GPM_NHOMHANG] ([IDNganhHang], [MaNhom],[TenNhomHang],[GhiChu],[NgayCapNhat]) VALUES (@IDNganhHang, @MaNhom,@TenNhomHang,@GhiChu,getDATE())";
                    using (SqlCommand myCommand = new SqlCommand(cmdText, myConnection))
                    {
                        myCommand.Parameters.AddWithValue("@IDNganhHang", IDNganhHang);
                        myCommand.Parameters.AddWithValue("@MaNhom", MaNhom);
                        myCommand.Parameters.AddWithValue("@TenNhomHang", TenNhomHang);
                        myCommand.Parameters.AddWithValue("@GhiChu", GhiChu);
                        myCommand.ExecuteNonQuery();
                    }
                    myConnection.Close();
                }
                catch
                {
                    throw new Exception("Lỗi: Quá trình thêm dữ liệu gặp lỗi");
                }
            }
        }


        public void insertNhomHang_Full(int IDNganhHang, string MaNhom, string TenNhomHang, string GhiChu, int DaXoa)
        {
            using (SqlConnection myConnection = new SqlConnection(StaticContext.ConnectionString))
            {
                try
                {
                    myConnection.Open();
                    string cmdText = "INSERT INTO [GPM_NHOMHANG] ([IDNganhHang], [MaNhom],[TenNhomHang],[GhiChu],[NgayCapNhat],[DaXoa]) VALUES (@IDNganhHang, @MaNhom,@TenNhomHang,@GhiChu,getDATE(),@DaXoa)";
                    using (SqlCommand myCommand = new SqlCommand(cmdText, myConnection))
                    {
                        myCommand.Parameters.AddWithValue("@IDNganhHang", IDNganhHang);
                        myCommand.Parameters.AddWithValue("@MaNhom", MaNhom);
                        myCommand.Parameters.AddWithValue("@TenNhomHang", TenNhomHang);
                        myCommand.Parameters.AddWithValue("@GhiChu", GhiChu);
                        myCommand.Parameters.AddWithValue("@DaXoa", DaXoa);
                        myCommand.ExecuteNonQuery();
                    }
                    myConnection.Close();
                }
                catch
                {
                    throw new Exception("Lỗi: Quá trình thêm dữ liệu gặp lỗi");
                }
            }
        }
    }
}