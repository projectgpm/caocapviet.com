﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.SqlClient;

namespace BanHang.Data
{
    public class dtNhomHang
    {
        public DataTable LayDanhSachNhomHang()
        {
            using (SqlConnection con = new SqlConnection(StaticContext.ConnectionString))
            {
                con.Open();
                string cmdText = "SELECT [GPM_NHOMHANG].ID, [GPM_NHOMHANG].TenNhomHang, [GPM_NHOMHANG].NgayCapNhat ,[GPM_NHOMHANG].IDNganhHang FROM [GPM_NHOMHANG],[GPM_NGANHHANG] WHERE [GPM_NHOMHANG].[DAXOA] = 0 AND [GPM_NGANHHANG].ID = [GPM_NHOMHANG].IDNganhHang;";
                using (SqlCommand command = new SqlCommand(cmdText, con))
                using (SqlDataReader reader = command.ExecuteReader())
                {
                    DataTable tb = new DataTable();
                    tb.Load(reader);
                    return tb;
                }
            }
        }

        public DataTable LayDanhSachNhomHang_Full()
        {
            using (SqlConnection con = new SqlConnection(StaticContext.ConnectionString))
            {
                con.Open();
                string cmdText = "SELECT * FROM [GPM_NHOMHANG]";
                using (SqlCommand command = new SqlCommand(cmdText, con))
                using (SqlDataReader reader = command.ExecuteReader())
                {
                    DataTable tb = new DataTable();
                    tb.Load(reader);
                    return tb;
                }
            }
        }

		public DataTable LayDanhSachNhomHang_Ten(string ten)
        {
            using (SqlConnection con = new SqlConnection(StaticContext.ConnectionString))
            {
                con.Open();
                string cmdText = "SELECT * FROM [GPM_NHOMHANG] WHERE [DAXOA] = 0 AND TenNhomHang = '"+ten+"'";
                using (SqlCommand command = new SqlCommand(cmdText, con))
                using (SqlDataReader reader = command.ExecuteReader())
                {
                    DataTable tb = new DataTable();
                    tb.Load(reader);
                    return tb;
                }
            }
        }
		
        public DataTable LayDanhSachNhomHang_ID(int ID)
        {
            using (SqlConnection con = new SqlConnection(StaticContext.ConnectionString))
            {
                con.Open();
                string cmdText = "SELECT * FROM [GPM_NHOMHANG] WHERE [DAXOA] = 0 AND ID = " + ID;
                using (SqlCommand command = new SqlCommand(cmdText, con))
                using (SqlDataReader reader = command.ExecuteReader())
                {
                    DataTable tb = new DataTable();
                    tb.Load(reader);
                    return tb;
                }
            }
        }

        public int LayDanhSachNhomHang_GetID(string Ten)
        {
            using (SqlConnection con = new SqlConnection(StaticContext.ConnectionString))
            {
                con.Open();
                string cmdText = "SELECT ID FROM [GPM_NHOMHANG] WHERE [DAXOA] = 0 AND TenNhomHang = '" + Ten + "'";
                using (SqlCommand command = new SqlCommand(cmdText, con))
                using (SqlDataReader reader = command.ExecuteReader())
                {
                    string s = "52";
                    DataTable tb = new DataTable();
                    tb.Load(reader);
                    if (tb.Rows.Count != 0)
                    {
                        DataRow dr = tb.Rows[0];
                        s = dr["ID"].ToString();
                    }
                    return Int32.Parse(s);
                }
            }
        }

        public void ThemNhomHangMoi(string TenNhomHang,int IDNganhHang, DateTime NgayCapNhat)
        {
            using (SqlConnection myConnection = new SqlConnection(StaticContext.ConnectionString))
            {
                try
                {
                    myConnection.Open();
                    string cmdText = "INSERT INTO [GPM_NHOMHANG] ([TenNhomHang],[IDNganhHang], [NgayCapNhat]) VALUES (@TenNhomHang, @IDNganhHang, @NgayCapNhat)";
                    using (SqlCommand myCommand = new SqlCommand(cmdText, myConnection))
                    {
                        myCommand.Parameters.AddWithValue("@TenNhomHang", TenNhomHang);
                        myCommand.Parameters.AddWithValue("@IDNganhHang", IDNganhHang);
                        myCommand.Parameters.AddWithValue("@NgayCapNhat", NgayCapNhat);
                        myCommand.ExecuteNonQuery();
                    }
                    myConnection.Close();
                }
                catch
                {
                    throw new Exception("Lỗi: Quá trình thêm dữ liệu gặp lỗi");
                }
            }
        }

        public void ThemNhomHangMoi_Full(string TenNhomHang, int IDNganhHang, DateTime NgayCapNhat, int DaXoa)
        {
            using (SqlConnection myConnection = new SqlConnection(StaticContext.ConnectionString))
            {
                try
                {
                    myConnection.Open();
                    string cmdText = "INSERT INTO [GPM_NHOMHANG] ([TenNhomHang],[IDNganhHang], [NgayCapNhat],[DaXoa]) VALUES (@TenNhomHang, @IDNganhHang, @NgayCapNhat,@DaXoa)";
                    using (SqlCommand myCommand = new SqlCommand(cmdText, myConnection))
                    {
                        myCommand.Parameters.AddWithValue("@TenNhomHang", TenNhomHang);
                        myCommand.Parameters.AddWithValue("@IDNganhHang", IDNganhHang);
                        myCommand.Parameters.AddWithValue("@NgayCapNhat", NgayCapNhat);
                        myCommand.Parameters.AddWithValue("@DaXoa", DaXoa);
                        myCommand.ExecuteNonQuery();
                    }
                    myConnection.Close();
                }
                catch
                {
                    throw new Exception("Lỗi: Quá trình thêm dữ liệu gặp lỗi");
                }
            }
        }
        public void XoaNhomHang(int ID)
        {
            using (SqlConnection myConnection = new SqlConnection(StaticContext.ConnectionString))
            {
                try
                {
                    dtMaHang dt = new dtMaHang();
                    dt.XoaMaHang_NhomHang(ID);

                    myConnection.Open();
                    string strSQL = "UPDATE [GPM_NHOMHANG] SET [DAXOA] = 1 WHERE [ID] = @ID";
                    using (SqlCommand myCommand = new SqlCommand(strSQL, myConnection))
                    {
                        myCommand.Parameters.AddWithValue("@ID", ID);
                        myCommand.ExecuteNonQuery();
                    }
                }
                catch (Exception e)
                {
                    throw new Exception("Lỗi: Quá trình Xóa dữ liệu gặp lỗi, hãy tải lại trang");
                }
            }
        }

        public void XoaNhomHang_NganhHang(int ID)
        {
            using (SqlConnection myConnection = new SqlConnection(StaticContext.ConnectionString))
            {
                try
                {
                    dtMaHang dt = new dtMaHang();
                    dt.XoaMaHang_NhomHang(ID);

                    myConnection.Open();
                    string strSQL = "UPDATE [GPM_NHOMHANG] SET [DAXOA] = 1 WHERE [IDNganhHang] = @ID";
                    using (SqlCommand myCommand = new SqlCommand(strSQL, myConnection))
                    {
                        myCommand.Parameters.AddWithValue("@ID", ID);
                        myCommand.ExecuteNonQuery();
                    }
                }
                catch (Exception e)
                {
                    throw new Exception("Lỗi: Quá trình Xóa dữ liệu gặp lỗi, hãy tải lại trang");
                }
            }
        }

        public void SuaThongTinNhomHang(int ID, string TenNhomHang, int IDNganhHang, DateTime NgayCapNhat)
        {
            using (SqlConnection myConnection = new SqlConnection(StaticContext.ConnectionString))
            {
                try
                {
                    myConnection.Open();
                    string strSQL = "UPDATE [GPM_NHOMHANG] SET [TenNhomHang] = @TenNhomHang, [IDNganhHang] = @IDNganhHang, [NgayCapNhat] = @NgayCapNhat WHERE [ID] = @ID";
                    using (SqlCommand myCommand = new SqlCommand(strSQL, myConnection))
                    {
                        myCommand.Parameters.AddWithValue("@ID", ID);
                        myCommand.Parameters.AddWithValue("@TenNhomHang", TenNhomHang);
                        myCommand.Parameters.AddWithValue("@IDNganhHang", IDNganhHang);
                        myCommand.Parameters.AddWithValue("@NgayCapNhat", NgayCapNhat);
                        myCommand.ExecuteNonQuery();
                    }
                }
                catch (Exception e)
                {
                    throw new Exception("Lỗi: Quá trình cập nhật dữ liệu gặp lỗi, hãy tải lại trang");
                }
            }
        }
        public void SuaThongTinNhomHang_Full(int ID, string TenNhomHang, int IDNganhHang, DateTime NgayCapNhat, int DaXoa)
        {
            using (SqlConnection myConnection = new SqlConnection(StaticContext.ConnectionString))
            {
                try
                {
                    myConnection.Open();
                    string strSQL = "UPDATE [GPM_NHOMHANG] SET [TenNhomHang] = @TenNhomHang, [IDNganhHang] = @IDNganhHang, [NgayCapNhat] = @NgayCapNhat, [DaXoa] = @DaXoa WHERE [ID] = @ID";
                    using (SqlCommand myCommand = new SqlCommand(strSQL, myConnection))
                    {
                        myCommand.Parameters.AddWithValue("@ID", ID);
                        myCommand.Parameters.AddWithValue("@TenNhomHang", TenNhomHang);
                        myCommand.Parameters.AddWithValue("@IDNganhHang", IDNganhHang);
                        myCommand.Parameters.AddWithValue("@NgayCapNhat", NgayCapNhat);
                        myCommand.Parameters.AddWithValue("@DaXoa", DaXoa);
                        myCommand.ExecuteNonQuery();
                    }
                }
                catch (Exception e)
                {
                    throw new Exception("Lỗi: Quá trình cập nhật dữ liệu gặp lỗi, hãy tải lại trang");
                }
            }
        }
    }
}