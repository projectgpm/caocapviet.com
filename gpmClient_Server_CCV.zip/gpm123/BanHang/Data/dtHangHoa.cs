﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.SqlClient;

namespace BanHang.Data
{
    public class dtHangHoa
    {
        public void CapNhatBarCode(int ID, object IDHangHoa, string BarCode)
        {
            using (SqlConnection myConnection = new SqlConnection(StaticContext.ConnectionString))
            {
                try
                {
                    myConnection.Open();
                    string cmdText = "UPDATE [GPM_HangHoa_Barcode] SET [IDHangHoa] = @IDHangHoa, [BarCode] = @BarCode,[NgayCapNhat] = getdate() WHERE [ID] = @ID";
                    using (SqlCommand myCommand = new SqlCommand(cmdText, myConnection))
                    {
                        myCommand.Parameters.AddWithValue("@ID", ID);
                        myCommand.Parameters.AddWithValue("@BarCode", BarCode);
                        myCommand.Parameters.AddWithValue("@IDHangHoa", IDHangHoa);
                        myCommand.ExecuteNonQuery();
                    }
                }
                catch (Exception e)
                {
                    throw new Exception("Lỗi: Quá trình cập nhật dữ liệu gặp lỗi, hãy tải lại trang");
                }
            }
        }

        public DataTable LayDanhSachHangHoa()
        {
            using (SqlConnection con = new SqlConnection(StaticContext.ConnectionString))
            {
                con.Open();
                string cmdText = "SELECT [GPM_HANGHOA].* FROM [GPM_HANGHOA] WHERE GPM_HANGHOA.[DAXOA] = 0 AND TrangThai = 0";
                using (SqlCommand command = new SqlCommand(cmdText, con))
                using (SqlDataReader reader = command.ExecuteReader())
                {
                    DataTable tb = new DataTable();
                    tb.Load(reader);
                    return tb;
                }
            }
        }
        public string LayIDHangHoa(string ID)
        {
            using (SqlConnection con = new SqlConnection(StaticContext.ConnectionString))
            {
                string s = "-1";
                con.Open();
                string cmdText = "SELECT ID FROM [GPM_HANGHOA] WHERE MaHang = " + ID;
                using (SqlCommand command = new SqlCommand(cmdText, con))
                using (SqlDataReader reader = command.ExecuteReader())
                {
                    DataTable tb = new DataTable();
                    tb.Load(reader);
                    if (tb.Rows.Count != 0)
                    {
                        DataRow dr = tb.Rows[0];
                        s = dr["ID"].ToString();
                    }
                    return s;
                }
            }
        }
        public string LaymaHang_IDHangHoa(int IDHangHoa)
        {
            using (SqlConnection con = new SqlConnection(StaticContext.ConnectionString))
            {
                string s = "-1";
                con.Open();
                string cmdText = "SELECT MaHang FROM [GPM_HANGHOA] WHERE ID = " + IDHangHoa;
                using (SqlCommand command = new SqlCommand(cmdText, con))
                using (SqlDataReader reader = command.ExecuteReader())
                {
                    DataTable tb = new DataTable();
                    tb.Load(reader);
                    if (tb.Rows.Count != 0)
                    {
                        DataRow dr = tb.Rows[0];
                        s = dr["MaHang"].ToString().Trim();
                    }
                    return s;
                }
            }
        }
        public int LayIDĐVT_IDHangHoa(int IDHangHoa)
        {
            using (SqlConnection con = new SqlConnection(StaticContext.ConnectionString))
            {
                
                con.Open();
                string cmdText = "SELECT IDDonViTinh FROM [GPM_HANGHOA] WHERE ID = " + IDHangHoa;
                using (SqlCommand command = new SqlCommand(cmdText, con))
                using (SqlDataReader reader = command.ExecuteReader())
                {
                    DataTable tb = new DataTable();
                    tb.Load(reader);
                    if (tb.Rows.Count != 0)
                    {
                        DataRow dr = tb.Rows[0];
                        return Int32.Parse(dr["IDDonViTinh"].ToString());
                    }
                    return -1;
                }
            }
        }

        public DataTable LayDanhSachHangHoa_BanHangCombo()
        {
            using (SqlConnection con = new SqlConnection(StaticContext.ConnectionString))
            {
                con.Open();
                string cmdText = "SELECT * FROM [GPM_HANGHOA] WHERE [DAXOA] = 0 AND (TrangThai = 0 OR (TrangThai > 1 AND TrangThai < 4))";
                using (SqlCommand command = new SqlCommand(cmdText, con))
                using (SqlDataReader reader = command.ExecuteReader())
                {
                    DataTable tb = new DataTable();
                    tb.Load(reader);
                    return tb;
                }
            }
        }

        public DataTable LayDanhSachHangHoa_IDNhomHang(int ID)
        {
            using (SqlConnection con = new SqlConnection(StaticContext.ConnectionString))
            {
                con.Open();
                string cmdText = "  SELECT [GPM_HANGHOA].*, [GPM_HangHoaTonKho].GiaBan FROM [GPM_HANGHOA],[GPM_NhomHang],[GPM_HangHoaTonKho] WHERE [GPM_HANGHOA].[DaXoa] = 0 AND [GPM_HANGHOA].IDNhomHang = [GPM_NhomHang].ID AND [GPM_HangHoaTonKho].IDHangHoa = [GPM_HANGHOA].ID AND [GPM_HangHoaTonKho].IDKho= '" + dtSetting.LayIDKho() + "' AND ('" + ID + "' = -1 OR [GPM_NhomHang].ID = '" + ID + "')";
                using (SqlCommand command = new SqlCommand(cmdText, con))
                using (SqlDataReader reader = command.ExecuteReader())
                {
                    DataTable tb = new DataTable();
                    tb.Load(reader);
                    return tb;
                }
            }
        }

        public DataTable LayDanhSachHangHoa_ID(int ID)
        {
            using (SqlConnection con = new SqlConnection(StaticContext.ConnectionString))
            {
                con.Open();
                string cmdText = "SELECT * FROM [GPM_HANGHOA] WHERE TrangThai = 0 AND [ID] = " + ID;
                using (SqlCommand command = new SqlCommand(cmdText, con))
                using (SqlDataReader reader = command.ExecuteReader())
                {
                    DataTable tb = new DataTable();
                    tb.Load(reader);
                    return tb;
                }
            }
        }
        public void ThemLichSuThayDoiGia(int IDHangHoa, int IDDonViTinh, float GiaCu, float GiaMoi,int IDNguoiDung, string MaHang)
        {
            using (SqlConnection myConnection = new SqlConnection(StaticContext.ConnectionString))
            {
                try
                {
                    string TenMay = Environment.MachineName; // tên máy tinh
                    myConnection.Open();
                    string cmdText = "INSERT INTO [GPM_LichSuThayDoiGia] ([IDHangHoa],[IDDonViTinh],[GiaCu],[GiaMoi],[IDNguoiDung],[MaHang],[TenMay],[NgayThayDoi]) VALUES(@IDHangHoa, @IDDonViTinh,@GiaCu,@GiaMoi,@IDNguoiDung,@MaHang,@TenMay, getdate())";
                    using (SqlCommand myCommand = new SqlCommand(cmdText, myConnection))
                    {
                        myCommand.Parameters.AddWithValue("@MaHang", MaHang.Trim());
                        myCommand.Parameters.AddWithValue("@IDHangHoa", IDHangHoa);
                        myCommand.Parameters.AddWithValue("@GiaCu", GiaCu);
                        myCommand.Parameters.AddWithValue("@IDDonViTinh", IDDonViTinh);
                        myCommand.Parameters.AddWithValue("@GiaMoi", GiaMoi);
                        myCommand.Parameters.AddWithValue("@IDNguoiDung", IDNguoiDung);
                        myCommand.Parameters.AddWithValue("@TenMay", TenMay);
                        myCommand.ExecuteNonQuery();
                    }
                }
                catch (Exception e)
                {
                    throw new Exception("Lỗi: Quá trình cập nhật dữ liệu gặp lỗi, hãy tải lại trang");
                }
            }
        }
        public DataTable LayDanhSachHangHoa_Full()
        {
            using (SqlConnection con = new SqlConnection(StaticContext.ConnectionString))
            {
                con.Open();
                string cmdText = "SELECT [GPM_HANGHOA].* FROM [GPM_HANGHOA]";
                using (SqlCommand command = new SqlCommand(cmdText, con))
                using (SqlDataReader reader = command.ExecuteReader())
                {
                    DataTable tb = new DataTable();
                    tb.Load(reader);
                    return tb;
                }
            }
        }
        public object ThemHangHoa(string TenHangHoa, int IDDonViTinh, string DonViQuiDoi, string GiaMua, string GiaBan1, string GiaBan2, string GiaBan3, string GiaBan4, string GiaBan5, string GiaBan6, string GiaBan7, string GiaBan8, string GiaBan9, string GiaBan10, int IDNhaCungCap, int IDMaHang, DateTime NgayCapNhat)
        {
            using (SqlConnection myConnection = new SqlConnection(StaticContext.ConnectionString))
            {
                try
                {
                    object IDHangHoa = null;
                    myConnection.Open();
                    string cmdText = "INSERT INTO [GPM_HANGHOA] ([TenHangHoa], [IDDonViTinh], [DonViQuiDoi], [GiaMua], [GiaBan1], [GiaBan2], [GiaBan3], [GiaBan4], [GiaBan5], [GiaBan6], [GiaBan7], [GiaBan8], [GiaBan9], [GiaBan10], [IDNhaCungCap], [IDMaHang], [NgayCapNhat])" +
                                     " OUTPUT INSERTED.ID" +
                                     " VALUES (@TenHangHoa, @IDDonViTinh, @DonViQuiDoi, @GiaMua, @GiaBan1, @GiaBan2, @GiaBan3, @GiaBan4, @GiaBan5, @GiaBan6, @GiaBan7, @GiaBan8, @GiaBan9, @GiaBan10, @IDNhaCungCap, @IDMaHang, @NgayCapNhat)";
                    using (SqlCommand myCommand = new SqlCommand(cmdText, myConnection))
                    {
                        myCommand.Parameters.AddWithValue("@TenHangHoa", TenHangHoa);
                        myCommand.Parameters.AddWithValue("@IDDonViTinh", IDDonViTinh);
                        myCommand.Parameters.AddWithValue("@DonViQuiDoi", DonViQuiDoi);
                        myCommand.Parameters.AddWithValue("@GiaMua", GiaMua);
                        myCommand.Parameters.AddWithValue("@GiaBan1", GiaBan1);
                        myCommand.Parameters.AddWithValue("@GiaBan2", GiaBan2);
                        myCommand.Parameters.AddWithValue("@GiaBan3", GiaBan3);
                        myCommand.Parameters.AddWithValue("@GiaBan4", GiaBan4);
                        myCommand.Parameters.AddWithValue("@GiaBan5", GiaBan5);
                        myCommand.Parameters.AddWithValue("@GiaBan6", GiaBan6);
                        myCommand.Parameters.AddWithValue("@GiaBan7", GiaBan7);
                        myCommand.Parameters.AddWithValue("@GiaBan8", GiaBan8);
                        myCommand.Parameters.AddWithValue("@GiaBan9", GiaBan9);
                        myCommand.Parameters.AddWithValue("@GiaBan10", GiaBan10);
                        myCommand.Parameters.AddWithValue("@IDNhaCungCap", IDNhaCungCap);
                        myCommand.Parameters.AddWithValue("@IDMaHang", IDMaHang);
                        myCommand.Parameters.AddWithValue("@NgayCapNhat", NgayCapNhat);
                        IDHangHoa = myCommand.ExecuteScalar();
                    }
                    myConnection.Close();

                    return IDHangHoa;
                }
                catch
                {
                    throw new Exception("Lỗi: Quá trình thêm dữ liệu gặp lỗi");                    
                }
            }
        }

        public object ThemHangHoa_Full(string TenHangHoa, int IDDonViTinh, string DonViQuiDoi, string GiaMua, string GiaBan1, string GiaBan2, string GiaBan3, string GiaBan4, string GiaBan5, string GiaBan6, string GiaBan7, string GiaBan8, string GiaBan9, string GiaBan10, int IDNhaCungCap, int IDMaHang, DateTime NgayCapNhat, int DaXoa)
        {
            using (SqlConnection myConnection = new SqlConnection(StaticContext.ConnectionString))
            {
                try
                {
                    object IDHangHoa = null;
                    myConnection.Open();
                    string cmdText = "INSERT INTO [GPM_HANGHOA] ([TenHangHoa], [IDDonViTinh], [DonViQuiDoi], [GiaMua], [GiaBan1], [GiaBan2], [GiaBan3], [GiaBan4], [GiaBan5], [GiaBan6], [GiaBan7], [GiaBan8], [GiaBan9], [GiaBan10], [IDNhaCungCap], [IDMaHang], [NgayCapNhat],[DaXoa])" +
                                     " OUTPUT INSERTED.ID" +
                                     " VALUES (@TenHangHoa, @IDDonViTinh, @DonViQuiDoi, @GiaMua, @GiaBan1, @GiaBan2, @GiaBan3, @GiaBan4, @GiaBan5, @GiaBan6, @GiaBan7, @GiaBan8, @GiaBan9, @GiaBan10, @IDNhaCungCap, @IDMaHang, @NgayCapNhat,@DaXoa)";
                    using (SqlCommand myCommand = new SqlCommand(cmdText, myConnection))
                    {
                        myCommand.Parameters.AddWithValue("@TenHangHoa", TenHangHoa);
                        myCommand.Parameters.AddWithValue("@IDDonViTinh", IDDonViTinh);
                        myCommand.Parameters.AddWithValue("@DonViQuiDoi", DonViQuiDoi);
                        myCommand.Parameters.AddWithValue("@GiaMua", GiaMua);
                        myCommand.Parameters.AddWithValue("@GiaBan1", GiaBan1);
                        myCommand.Parameters.AddWithValue("@GiaBan2", GiaBan2);
                        myCommand.Parameters.AddWithValue("@GiaBan3", GiaBan3);
                        myCommand.Parameters.AddWithValue("@GiaBan4", GiaBan4);
                        myCommand.Parameters.AddWithValue("@GiaBan5", GiaBan5);
                        myCommand.Parameters.AddWithValue("@GiaBan6", GiaBan6);
                        myCommand.Parameters.AddWithValue("@GiaBan7", GiaBan7);
                        myCommand.Parameters.AddWithValue("@GiaBan8", GiaBan8);
                        myCommand.Parameters.AddWithValue("@GiaBan9", GiaBan9);
                        myCommand.Parameters.AddWithValue("@GiaBan10", GiaBan10);
                        myCommand.Parameters.AddWithValue("@IDNhaCungCap", IDNhaCungCap);
                        myCommand.Parameters.AddWithValue("@IDMaHang", IDMaHang);
                        myCommand.Parameters.AddWithValue("@NgayCapNhat", NgayCapNhat);
                        myCommand.Parameters.AddWithValue("@DaXoa", DaXoa);
                        IDHangHoa = myCommand.ExecuteScalar();
                    }
                    myConnection.Close();

                    return IDHangHoa;
                }
                catch
                {
                    throw new Exception("Lỗi: Quá trình thêm dữ liệu gặp lỗi");
                }
            }
        }

        public void XoaHangHoa(int ID)
        {
            using (SqlConnection myConnection = new SqlConnection(StaticContext.ConnectionString))
            {
                try
                {
                    myConnection.Open();
                    string strSQL = "UPDATE [GPM_HANGHOA] SET [DAXOA] = 1 WHERE [ID] = @ID";
                    using (SqlCommand myCommand = new SqlCommand(strSQL, myConnection))
                    {
                        myCommand.Parameters.AddWithValue("@ID", ID);
                        myCommand.ExecuteNonQuery();
                    }
                }
                catch (Exception e)
                {
                    throw new Exception("Lỗi: Quá trình cập nhật dữ liệu gặp lỗi, hãy tải lại trang");
                }
            }
        }

        public void XoaHangHoa_MaHang(int ID)
        {
            using (SqlConnection myConnection = new SqlConnection(StaticContext.ConnectionString))
            {
                try
                {
                    myConnection.Open();
                    string strSQL = "UPDATE [GPM_HANGHOA] SET [DAXOA] = 1 WHERE [IDMaHang] = @ID";
                    using (SqlCommand myCommand = new SqlCommand(strSQL, myConnection))
                    {
                        myCommand.Parameters.AddWithValue("@ID", ID);
                        myCommand.ExecuteNonQuery();
                    }
                }
                catch (Exception e)
                {
                    throw new Exception("Lỗi: Quá trình cập nhật dữ liệu gặp lỗi, hãy tải lại trang");
                }
            }
        }
        public void Update_HangHoaTonKho(int ID, int DaXoa,float GiaBan)
        {
            using (SqlConnection myConnection = new SqlConnection(StaticContext.ConnectionString))
            {
                try
                {
                    myConnection.Open();
                    string strSQL = "UPDATE [GPM_HangHoaTonKho] SET [DaXoa] = @DaXoa,[GiaBan] = @GiaBan WHERE [IDHangHoa] = @IDHangHoa";
                    using (SqlCommand myCommand = new SqlCommand(strSQL, myConnection))
                    {
                        myCommand.Parameters.AddWithValue("@IDHangHoa", ID);
                        myCommand.Parameters.AddWithValue("@DaXoa", DaXoa);
                        myCommand.Parameters.AddWithValue("@GiaBan", GiaBan);
                        myCommand.ExecuteNonQuery();
                    }
                }
                catch (Exception e)
                {
                    throw new Exception("Lỗi: Quá trình cập nhật dữ liệu gặp lỗi, hãy tải lại trang");
                }
            }
        }
        public void SuaThongTinHangHoa(int ID, string TenHangHoa, int IDDonViTinh, string DonViQuiDoi, string GiaMua, string GiaBan1, string GiaBan2, string GiaBan3, string GiaBan4, string GiaBan5, string GiaBan6, string GiaBan7, string GiaBan8, string GiaBan9, string GiaBan10, int IDNhaCungCap, int IDMaHang, DateTime NgayCapNhat)
        {
            using (SqlConnection myConnection = new SqlConnection(StaticContext.ConnectionString))
            {
                try
                {
                    myConnection.Open();
                    string strSQL = "UPDATE [GPM_HANGHOA] SET [TenHangHoa] = @TenHangHoa, [IDDonViTinh] = @IDDonViTinh, [DonViQuiDoi] = @DonViQuiDoi, [GiaMua] = @GiaMua, [GiaBan1] = @GiaBan1, [GiaBan2] = @GiaBan2, [GiaBan3] = @GiaBan3, [GiaBan4] = @GiaBan4, [GiaBan5] = @GiaBan5, [GiaBan6] = @GiaBan6, [GiaBan7] = @GiaBan7, [GiaBan8] = @GiaBan8, [GiaBan9] = @GiaBan9, [GiaBan10] = @GiaBan10, [IDNhaCungCap] = @IDNhaCungCap, [IDMaHang] = @IDMaHang, [NgayCapNhat] = @NgayCapNhat WHERE [ID] = @ID";
                    using (SqlCommand myCommand = new SqlCommand(strSQL, myConnection))
                    {
                        myCommand.Parameters.AddWithValue("@ID", ID);
                        myCommand.Parameters.AddWithValue("@TenHangHoa", TenHangHoa);
                        myCommand.Parameters.AddWithValue("@IDDonViTinh", IDDonViTinh);
                        myCommand.Parameters.AddWithValue("@DonViQuiDoi", DonViQuiDoi);
                        myCommand.Parameters.AddWithValue("@GiaMua", GiaMua);
                        myCommand.Parameters.AddWithValue("@GiaBan1", GiaBan1);
                        myCommand.Parameters.AddWithValue("@GiaBan2", GiaBan2);
                        myCommand.Parameters.AddWithValue("@GiaBan3", GiaBan3);
                        myCommand.Parameters.AddWithValue("@GiaBan4", GiaBan4);
                        myCommand.Parameters.AddWithValue("@GiaBan5", GiaBan5);
                        myCommand.Parameters.AddWithValue("@GiaBan6", GiaBan6);
                        myCommand.Parameters.AddWithValue("@GiaBan7", GiaBan7);
                        myCommand.Parameters.AddWithValue("@GiaBan8", GiaBan8);
                        myCommand.Parameters.AddWithValue("@GiaBan9", GiaBan9);
                        myCommand.Parameters.AddWithValue("@GiaBan10", GiaBan10);
                        myCommand.Parameters.AddWithValue("@IDNhaCungCap", IDNhaCungCap);
                        myCommand.Parameters.AddWithValue("@IDMaHang", IDMaHang);
                        myCommand.Parameters.AddWithValue("@NgayCapNhat", NgayCapNhat);
                        myCommand.ExecuteNonQuery();
                    }
                }
                catch (Exception e)
                {
                    throw new Exception("Lỗi: Quá trình cập nhật dữ liệu gặp lỗi, hãy tải lại trang");
                }
            }
        }

        public void SuaThongTinHangHoa_Full(int ID, string TenHangHoa, int IDDonViTinh, string DonViQuiDoi, string GiaMua, string GiaBan1, string GiaBan2, string GiaBan3, string GiaBan4, string GiaBan5, string GiaBan6, string GiaBan7, string GiaBan8, string GiaBan9, string GiaBan10, int IDNhaCungCap, int IDMaHang, DateTime NgayCapNhat, int DaXoa)
        {
            using (SqlConnection myConnection = new SqlConnection(StaticContext.ConnectionString))
            {
                try
                {
                    myConnection.Open();
                    string strSQL = "UPDATE [GPM_HANGHOA] SET [TenHangHoa] = @TenHangHoa, [IDDonViTinh] = @IDDonViTinh, [DonViQuiDoi] = @DonViQuiDoi, [GiaMua] = @GiaMua, [GiaBan1] = @GiaBan1, [GiaBan2] = @GiaBan2, [GiaBan3] = @GiaBan3, [GiaBan4] = @GiaBan4, [GiaBan5] = @GiaBan5, [GiaBan6] = @GiaBan6, [GiaBan7] = @GiaBan7, [GiaBan8] = @GiaBan8, [GiaBan9] = @GiaBan9, [GiaBan10] = @GiaBan10, [IDNhaCungCap] = @IDNhaCungCap, [IDMaHang] = @IDMaHang, [NgayCapNhat] = @NgayCapNhat, [DaXoa] = @DaXoa WHERE [ID] = @ID";
                    using (SqlCommand myCommand = new SqlCommand(strSQL, myConnection))
                    {
                        myCommand.Parameters.AddWithValue("@ID", ID);
                        myCommand.Parameters.AddWithValue("@TenHangHoa", TenHangHoa);
                        myCommand.Parameters.AddWithValue("@IDDonViTinh", IDDonViTinh);
                        myCommand.Parameters.AddWithValue("@DonViQuiDoi", DonViQuiDoi);
                        myCommand.Parameters.AddWithValue("@GiaMua", GiaMua);
                        myCommand.Parameters.AddWithValue("@GiaBan1", GiaBan1);
                        myCommand.Parameters.AddWithValue("@GiaBan2", GiaBan2);
                        myCommand.Parameters.AddWithValue("@GiaBan3", GiaBan3);
                        myCommand.Parameters.AddWithValue("@GiaBan4", GiaBan4);
                        myCommand.Parameters.AddWithValue("@GiaBan5", GiaBan5);
                        myCommand.Parameters.AddWithValue("@GiaBan6", GiaBan6);
                        myCommand.Parameters.AddWithValue("@GiaBan7", GiaBan7);
                        myCommand.Parameters.AddWithValue("@GiaBan8", GiaBan8);
                        myCommand.Parameters.AddWithValue("@GiaBan9", GiaBan9);
                        myCommand.Parameters.AddWithValue("@GiaBan10", GiaBan10);
                        myCommand.Parameters.AddWithValue("@IDNhaCungCap", IDNhaCungCap);
                        myCommand.Parameters.AddWithValue("@IDMaHang", IDMaHang);
                        myCommand.Parameters.AddWithValue("@NgayCapNhat", NgayCapNhat);
                        myCommand.Parameters.AddWithValue("@DaXoa", DaXoa);
                        myCommand.ExecuteNonQuery();
                    }
                }
                catch (Exception e)
                {
                    throw new Exception("Lỗi: Quá trình cập nhật dữ liệu gặp lỗi, hãy tải lại trang");
                }
            }
        }

        public void SuaThongTinBarcode_Full(int ID, int IDHangHoa, string Barcode, DateTime NgayCapNhat, int DaXoa)
        {
            using (SqlConnection myConnection = new SqlConnection(StaticContext.ConnectionString))
            {
                try
                {
                    myConnection.Open();
                    string strSQL = "UPDATE [GPM_HangHoa_Barcode] SET [IDHangHoa] = @IDHangHoa, [Barcode] = @Barcode, [NgayCapNhat] = @NgayCapNhat, [DaXoa] = @DaXoa WHERE [ID] = @ID";
                    using (SqlCommand myCommand = new SqlCommand(strSQL, myConnection))
                    {
                        myCommand.Parameters.AddWithValue("@ID", ID);
                        myCommand.Parameters.AddWithValue("@IDHangHoa", IDHangHoa);
                        myCommand.Parameters.AddWithValue("@Barcode", Barcode);
                        myCommand.Parameters.AddWithValue("@NgayCapNhat", NgayCapNhat);
                        myCommand.Parameters.AddWithValue("@DaXoa", DaXoa);
                        myCommand.ExecuteNonQuery();
                    }
                }
                catch (Exception e)
                {
                    throw new Exception("Lỗi: Quá trình cập nhật dữ liệu gặp lỗi, hãy tải lại trang");
                }
            }
        }

        public void ThemDanhSachBarCode(object IDHangHoa, List<string> ListBarCode)
        {            
            using (SqlConnection myConnection = new SqlConnection(StaticContext.ConnectionString))
            {
                try
                {
                    myConnection.Open();
                    string cmdText = "INSERT INTO [GPM_HangHoa_Barcode] ([IDHangHoa],[Barcode],[NgayCapNhat])" +
                             " VALUES(@IDHangHoa, @BarCode, getdate())";
                    using (SqlCommand myCommand = new SqlCommand(cmdText, myConnection))
                    {
                        myCommand.Parameters.AddWithValue("@IDHangHoa", IDHangHoa);
                        myCommand.Parameters.AddWithValue("@BarCode", "");
                        foreach (string barCode in ListBarCode)
                        {
                            myCommand.Parameters["@BarCode"].Value = barCode;                             
                            myCommand.ExecuteNonQuery();
                        }
                    }
                }
                catch (Exception e)
                {
                    throw new Exception("Lỗi: Quá trình cập nhật dữ liệu gặp lỗi, hãy tải lại trang");
                }
            }
        }

        public void ThemBarCode(object IDHangHoa, string BarCode)
        {
            using (SqlConnection myConnection = new SqlConnection(StaticContext.ConnectionString))
            {
                try
                {
                    myConnection.Open();
                    string cmdText = "INSERT INTO [GPM_HangHoa_Barcode] ([IDHangHoa],[Barcode],[NgayCapNhat])" +
                             " VALUES(@IDHangHoa, @BarCode, getdate())";
                    using (SqlCommand myCommand = new SqlCommand(cmdText, myConnection))
                    {
                        myCommand.Parameters.AddWithValue("@IDHangHoa", IDHangHoa);
                        myCommand.Parameters.AddWithValue("@BarCode", BarCode);
                        myCommand.ExecuteNonQuery();
                    }
                }
                catch (Exception e)
                {
                    throw new Exception("Lỗi: Quá trình cập nhật dữ liệu gặp lỗi, hãy tải lại trang");
                }
            }
        }
        public void ThemBarCode_Full(object IDHangHoa, string BarCode, int DaXoa)
        {
            using (SqlConnection myConnection = new SqlConnection(StaticContext.ConnectionString))
            {
                try
                {
                    myConnection.Open();
                    string cmdText = "INSERT INTO [GPM_HangHoa_Barcode] ([IDHangHoa],[Barcode],[NgayCapNhat],[DaXoa])" +
                             " VALUES(@IDHangHoa, @BarCode, getdate(),@DaXoa)";
                    using (SqlCommand myCommand = new SqlCommand(cmdText, myConnection))
                    {
                        myCommand.Parameters.AddWithValue("@IDHangHoa", IDHangHoa);
                        myCommand.Parameters.AddWithValue("@BarCode", BarCode);
                        myCommand.Parameters.AddWithValue("@DaXoa", DaXoa);
                        myCommand.ExecuteNonQuery();
                    }
                }
                catch (Exception e)
                {
                    throw new Exception("Lỗi: Quá trình cập nhật dữ liệu gặp lỗi, hãy tải lại trang");
                }
            }
        }
        public DataTable GetListBarCode(object ID)
        {
            DataTable dt = new DataTable();
            using (SqlConnection con = new SqlConnection(StaticContext.ConnectionString))
            {
                con.Open();
                string cmdText = "SELECT [ID], [Barcode], [NgayCapNhat] FROM [GPM_HangHoa_Barcode] WHERE [IDHangHoa] = @IDHangHoa";
                using (SqlCommand command = new SqlCommand(cmdText, con))
                {
                    command.Parameters.AddWithValue("@IDHangHoa", ID);
                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        dt.Load(reader);
                    }
                }
            }
            return dt;
        }

        public void SuaDanhSachBarCode(object ID, List<string> ListBarCode)
        {
            using (SqlConnection myConnection = new SqlConnection(StaticContext.ConnectionString))
            {
                try
                {
                    myConnection.Open();
                    string cmdText = "DELETE FROM [GPM_HangHoa_Barcode] WHERE [IDHangHoa] = @IDHangHoa";
                    using (SqlCommand myCommand = new SqlCommand(cmdText, myConnection))
                    {
                        myCommand.Parameters.AddWithValue("@IDHangHoa", ID);
                        myCommand.ExecuteNonQuery();
                    }
                    ThemDanhSachBarCode(ID, ListBarCode);
                }
                catch (Exception e)
                {
                    throw new Exception("Lỗi: Quá trình cập nhật dữ liệu gặp lỗi, hãy tải lại trang");
                }
            }
        }
        public void XoaBarCode(int ID)
        {
            using (SqlConnection myConnection = new SqlConnection(StaticContext.ConnectionString))
            {
                try
                {
                    myConnection.Open();
                    string cmdText = "DELETE FROM [GPM_HangHoa_Barcode] WHERE [ID] = @ID";
                    using (SqlCommand myCommand = new SqlCommand(cmdText, myConnection))
                    {
                        myCommand.Parameters.AddWithValue("@ID", ID);
                        myCommand.ExecuteNonQuery();
                    }
                }
                catch (Exception e)
                {
                    throw new Exception("Lỗi: Quá trình cập nhật dữ liệu gặp lỗi, hãy tải lại trang");
                }
            }
        }

        public void ThemHangVaoTonKho(object IDKho1, int IDHangHoa, int SoLuongCon, DateTime NgayCapNhat, float GiaBan)
        {
            using (SqlConnection myConnection = new SqlConnection(StaticContext.ConnectionString))
            {
                try
                {
                    myConnection.Open();
                    string cmdText = "INSERT INTO [GPM_HangHoaTonKho] ([IDKho],[IDHangHoa],[SoLuongCon],[NgayCapNhat],[GiaBan]) VALUES (@IDKho,@IDHangHoa,@SoLuongCon,@NgayCapNhat,@GiaBan)";
                    using (SqlCommand myCommand = new SqlCommand(cmdText, myConnection))
                    {
                        myCommand.Parameters.AddWithValue("@IDKho", IDKho1);
                        myCommand.Parameters.AddWithValue("@IDHangHoa", IDHangHoa);
                        myCommand.Parameters.AddWithValue("@SoLuongCon", SoLuongCon);
                        myCommand.Parameters.AddWithValue("@GiaBan", GiaBan);
                        myCommand.Parameters.AddWithValue("@NgayCapNhat", NgayCapNhat);
                        myCommand.ExecuteNonQuery();
                    }
                }
                catch (Exception e)
                {
                    throw new Exception("Lỗi: Quá trình cập nhật dữ liệu gặp lỗi, hãy tải lại trang");
                }
            }
        }
    }
}