﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace BanHang.Data
{
    public class dataHangSanXuat
    {

        public void insertHangSX_Full(string TenNhanHang, string SDT, string DiaChi, int IDQuan, int IDThanhPho, string Email, string GhiChu, int DaXoa)
        {
            using (SqlConnection myConnection = new SqlConnection(StaticContext.ConnectionString))
            {
                try
                {
                    myConnection.Open();
                    string cmdText = "INSERT INTO [GPM_HangSanXuat] ([TenNhanHang], [SDT],[DiaChi],[IDQuan],[IDThanhPho],[Email],[GhiChu],[DaXoa],[NgayCapNhat]) VALUES (@TenNhanHang, @SDT,@DiaChi,@IDQuan,@IDThanhPho,@Email,@GhiChu,@DaXoa,getDATE())";
                    using (SqlCommand myCommand = new SqlCommand(cmdText, myConnection))
                    {
                        myCommand.Parameters.AddWithValue("@TenNhanHang", TenNhanHang);
                        myCommand.Parameters.AddWithValue("@SDT", SDT);
                        myCommand.Parameters.AddWithValue("@DiaChi", DiaChi);
                        myCommand.Parameters.AddWithValue("@IDQuan", IDQuan);
                        myCommand.Parameters.AddWithValue("@IDThanhPho", IDThanhPho);
                        myCommand.Parameters.AddWithValue("@Email", Email);
                        myCommand.Parameters.AddWithValue("@GhiChu", GhiChu);
                        myCommand.Parameters.AddWithValue("@DaXoa", DaXoa);
                        myCommand.ExecuteNonQuery();
                    }
                    myConnection.Close();
                }
                catch
                {
                    throw new Exception("Lỗi: Quá trình thêm dữ liệu gặp lỗi");
                }
            }
        }

        public void updateHangSX_Full(int ID, string TenNhanHang, string SDT, string DiaChi, int IDQuan, int IDThanhPho, string Email, string GhiChu, int DaXoa)
        {
            using (SqlConnection myConnection = new SqlConnection(StaticContext.ConnectionString))
            {
                try
                {
                    myConnection.Open();
                    string strSQL = "UPDATE [GPM_HangSanXuat] SET [TenNhanHang] = @TenNhanHang,[SDT] = @SDT,[DiaChi] = @DiaChi,[IDQuan] = @IDQuan,[IDThanhPho] = @IDThanhPho,[Email] = @Email,[GhiChu] = @GhiChu,[DaXoa] = @DaXoa, [NgayCapNhat] = getDATE() WHERE [ID] = @ID";
                    using (SqlCommand myCommand = new SqlCommand(strSQL, myConnection))
                    {
                        myCommand.Parameters.AddWithValue("@ID", ID);
                        myCommand.Parameters.AddWithValue("@TenNhanHang", TenNhanHang);
                        myCommand.Parameters.AddWithValue("@SDT", SDT);
                        myCommand.Parameters.AddWithValue("@DiaChi", DiaChi);
                        myCommand.Parameters.AddWithValue("@IDQuan", IDQuan);
                        myCommand.Parameters.AddWithValue("@IDThanhPho", IDThanhPho);
                        myCommand.Parameters.AddWithValue("@Email", Email);
                        myCommand.Parameters.AddWithValue("@GhiChu", GhiChu);
                        myCommand.Parameters.AddWithValue("@DaXoa", DaXoa);
                        myCommand.ExecuteNonQuery();
                    }
                }
                catch (Exception e)
                {
                    throw new Exception("Lỗi: Quá trình cập nhật dữ liệu gặp lỗi, hãy tải lại trang");
                }
            }
        }
    }
}