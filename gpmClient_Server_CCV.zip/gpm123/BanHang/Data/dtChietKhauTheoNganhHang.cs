﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace BanHang.Data
{
    public class dtChietKhauTheoNganhHang
    {
        public DataTable LayDanhSach()
        {
            using (SqlConnection con = new SqlConnection(StaticContext.ConnectionString))
            {
                con.Open();
                string cmdText = " SELECT * FROM [GPM_ChietKhauTheoNganhHang] WHERE DaXoa = 0";
                using (SqlCommand command = new SqlCommand(cmdText, con))
                using (SqlDataReader reader = command.ExecuteReader())
                {
                    DataTable tb = new DataTable();
                    tb.Load(reader);
                    return tb;
                }
            }
        }

        public void Them(int IDNganhHang, float GiaTri, DateTime NgayBatDau, DateTime NgayKetThuc)
        {
            using (SqlConnection myConnection = new SqlConnection(StaticContext.ConnectionString))
            {
                try
                {
                    myConnection.Open();
                    string cmdText = "INSERT INTO [GPM_ChietKhauTheoNganhHang] ([IDNganhHang],[GiaTri], [NgayBatDau], [NgayKetThuc], [NgayCapNhat]) VALUES (@IDNganhHang, @GiaTri, @NgayBatDau, @NgayKetThuc, getdate())";
                    using (SqlCommand myCommand = new SqlCommand(cmdText, myConnection))
                    {
                        myCommand.Parameters.AddWithValue("@IDNganhHang", IDNganhHang);
                        myCommand.Parameters.AddWithValue("@GiaTri", GiaTri);
                        myCommand.Parameters.AddWithValue("@NgayBatDau", NgayBatDau);
                        myCommand.Parameters.AddWithValue("@NgayKetThuc", NgayKetThuc);
                        myCommand.ExecuteNonQuery();
                    }
                    myConnection.Close();
                }
                catch
                {
                    throw new Exception("Lỗi: Quá trình thêm dữ liệu gặp lỗi");
                }
            }
        }

        public void Them_Full(int IDNganhHang, float GiaTri, DateTime NgayBatDau, DateTime NgayKetThuc, int DaXoa)
        {
            using (SqlConnection myConnection = new SqlConnection(StaticContext.ConnectionString))
            {
                try
                {
                    myConnection.Open();
                    string cmdText = "INSERT INTO [GPM_ChietKhauTheoNganhHang] ([IDNganhHang],[GiaTri], [NgayBatDau], [NgayKetThuc], [NgayCapNhat],[DaXoa]) VALUES (@IDNganhHang, @GiaTri, @NgayBatDau, @NgayKetThuc, getdate(),@DaXoa)";
                    using (SqlCommand myCommand = new SqlCommand(cmdText, myConnection))
                    {
                        myCommand.Parameters.AddWithValue("@IDNganhHang", IDNganhHang);
                        myCommand.Parameters.AddWithValue("@GiaTri", GiaTri);
                        myCommand.Parameters.AddWithValue("@NgayBatDau", NgayBatDau);
                        myCommand.Parameters.AddWithValue("@NgayKetThuc", NgayKetThuc);
                        myCommand.Parameters.AddWithValue("@DaXoa", DaXoa);
                        myCommand.ExecuteNonQuery();
                    }
                    myConnection.Close();
                }
                catch
                {
                    throw new Exception("Lỗi: Quá trình thêm dữ liệu gặp lỗi");
                }
            }
        }
        public void Xoa(int ID)
        {
            using (SqlConnection myConnection = new SqlConnection(StaticContext.ConnectionString))
            {
                try
                {
                    myConnection.Open();
                    string strSQL = "UPDATE [GPM_ChietKhauTheoNganhHang] SET [DaXoa] = 1 WHERE [ID] = @ID";
                    using (SqlCommand myCommand = new SqlCommand(strSQL, myConnection))
                    {
                        myCommand.Parameters.AddWithValue("@ID", ID);
                        myCommand.ExecuteNonQuery();
                    }
                }
                catch (Exception e)
                {
                    throw new Exception("Lỗi: Quá trình Xóa dữ liệu gặp lỗi, hãy tải lại trang");
                }
            }
        }

        public void Sua(int ID, int IDNganhHang, float GiaTri, DateTime NgayBatDau, DateTime NgayKetThuc)
        {
            using (SqlConnection myConnection = new SqlConnection(StaticContext.ConnectionString))
            {
                try
                {
                    myConnection.Open();
                    string strSQL = "UPDATE [GPM_ChietKhauTheoNganhHang] SET [IDNganhHang] = @IDNganhHang, [GiaTri] = @GiaTri, [NgayBatDau] = @NgayBatDau, [NgayKetThuc] = @NgayKetThuc, [NgayCapNhat] = getdate() WHERE [ID] = @ID";
                    using (SqlCommand myCommand = new SqlCommand(strSQL, myConnection))
                    {
                        myCommand.Parameters.AddWithValue("@ID", ID);
                        myCommand.Parameters.AddWithValue("@IDNganhHang", IDNganhHang);
                        myCommand.Parameters.AddWithValue("@GiaTri", GiaTri);
                        myCommand.Parameters.AddWithValue("@NgayBatDau", NgayBatDau);
                        myCommand.Parameters.AddWithValue("@NgayKetThuc", NgayKetThuc);
                        myCommand.ExecuteNonQuery();
                    }
                }
                catch (Exception e)
                {
                    throw new Exception("Lỗi: Quá trình cập nhật dữ liệu gặp lỗi, hãy tải lại trang");
                }
            }
        }

        public void Sua_Full(int ID, int IDNganhHang, float GiaTri, DateTime NgayBatDau, DateTime NgayKetThuc, int DaXoa)
        {
            using (SqlConnection myConnection = new SqlConnection(StaticContext.ConnectionString))
            {
                try
                {
                    myConnection.Open();
                    string strSQL = "UPDATE [GPM_ChietKhauTheoNganhHang] SET [IDNganhHang] = @IDNganhHang, [GiaTri] = @GiaTri, [NgayBatDau] = @NgayBatDau, [NgayKetThuc] = @NgayKetThuc, [NgayCapNhat] = getdate(),[DaXoa] = @DaXoa WHERE [ID] = @ID";
                    using (SqlCommand myCommand = new SqlCommand(strSQL, myConnection))
                    {
                        myCommand.Parameters.AddWithValue("@ID", ID);
                        myCommand.Parameters.AddWithValue("@IDNganhHang", IDNganhHang);
                        myCommand.Parameters.AddWithValue("@GiaTri", GiaTri);
                        myCommand.Parameters.AddWithValue("@NgayBatDau", NgayBatDau);
                        myCommand.Parameters.AddWithValue("@NgayKetThuc", NgayKetThuc);
                        myCommand.Parameters.AddWithValue("@DaXoa", DaXoa);
                        myCommand.ExecuteNonQuery();
                    }
                }
                catch (Exception e)
                {
                    throw new Exception("Lỗi: Quá trình cập nhật dữ liệu gặp lỗi, hãy tải lại trang");
                }
            }
        }
    }
}