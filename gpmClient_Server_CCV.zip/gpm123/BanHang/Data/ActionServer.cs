﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace BanHang.Data
{
    public class ActionServer
    {
        public static void CapNhatServer()
        {
            //dtThongTinCuaHangKho da = new dtThongTinCuaHangKho();
            //da.UpdateCapNhatNews();
        }
    }
}