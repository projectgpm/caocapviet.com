﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace BanHang.Data
{
    public class dtHangSanXuat
    {
        public static void CapNhatHangSanXuat(string ID,string TenNhanHang, string SDT, string DiaChi, string IDQuan, string IDThanhPho, string Email, string GhiChu)
        {
            using (SqlConnection myConnection = new SqlConnection(StaticContext.ConnectionString))
            {
                try
                {
                    myConnection.Open();
                    string strSQL = "UPDATE [GPM_HangSanXuat] SET [TenNhanHang] = @TenNhanHang,[SDT] = @SDT,[DiaChi] = @DiaChi,[IDQuan] = @IDQuan,[IDThanhPho] = @IDThanhPho,[Email] = @Email,[GhiChu] =  @GhiChu WHERE [ID] = @ID";
                    using (SqlCommand myCommand = new SqlCommand(strSQL, myConnection))
                    {
                        myCommand.Parameters.AddWithValue("@ID", ID);
                        myCommand.Parameters.AddWithValue("@TenNhanHang", TenNhanHang);
                        myCommand.Parameters.AddWithValue("@SDT", SDT);
                        myCommand.Parameters.AddWithValue("@DiaChi", DiaChi);
                        myCommand.Parameters.AddWithValue("@IDQuan", IDQuan);
                        myCommand.Parameters.AddWithValue("@IDThanhPho", IDThanhPho);
                        myCommand.Parameters.AddWithValue("@Email", Email);
                        myCommand.Parameters.AddWithValue("@GhiChu", GhiChu);
                        myCommand.ExecuteNonQuery();
                    }
                }
                catch (Exception e)
                {
                    throw new Exception("Lỗi: Quá trình cập nhật dữ liệu gặp lỗi, hãy tải lại trang");
                }
            }
        }
        public static void ThemHangSanXuat(string TenNhanHang, string SDT, string DiaChi, string IDQuan, string IDThanhPho, string Email, string GhiChu)
        {
            using (SqlConnection myConnection = new SqlConnection(StaticContext.ConnectionString))
            {
                try
                {
                    myConnection.Open();
                    string strSQL = "INSERT INTO [GPM_HangSanXuat] ([TenNhanHang],[SDT],[DiaChi],[IDQuan],[IDThanhPho],[Email],[GhiChu]) VALUES(@TenNhanHang,@SDT,@DiaChi,@IDQuan,@IDThanhPho,@Email,@GhiChu)";
                    using (SqlCommand myCommand = new SqlCommand(strSQL, myConnection))
                    {
                        myCommand.Parameters.AddWithValue("@TenNhanHang", TenNhanHang);
                        myCommand.Parameters.AddWithValue("@SDT", SDT);
                        myCommand.Parameters.AddWithValue("@DiaChi", DiaChi);
                        myCommand.Parameters.AddWithValue("@IDQuan", IDQuan);
                        myCommand.Parameters.AddWithValue("@IDThanhPho", IDThanhPho);
                        myCommand.Parameters.AddWithValue("@Email", Email);
                        myCommand.Parameters.AddWithValue("@GhiChu", GhiChu);
                        myCommand.ExecuteNonQuery();
                    }
                }
                catch (Exception e)
                {
                    throw new Exception("Lỗi: Quá trình cập nhật dữ liệu gặp lỗi, hãy tải lại trang");
                }
            }
        }
        public static void XoaHangSanXuat(string ID)
        {
            using (SqlConnection myConnection = new SqlConnection(StaticContext.ConnectionString))
            {
                try
                {
                    myConnection.Open();
                    string strSQL = "UPDATE [GPM_HangSanXuat] SET [DaXoa] = 1 WHERE [ID] = @ID";
                    using (SqlCommand myCommand = new SqlCommand(strSQL, myConnection))
                    {
                        myCommand.Parameters.AddWithValue("@ID", ID);
                        myCommand.ExecuteNonQuery();
                    }
                }
                catch (Exception e)
                {
                    throw new Exception("Lỗi: Quá trình cập nhật dữ liệu gặp lỗi, hãy tải lại trang");
                }
            }
        }
        public DataTable DanhSachHangSanXuat()
        {
            using (SqlConnection con = new SqlConnection(StaticContext.ConnectionString))
            {
                con.Open();
                string cmdText = "SELECT [GPM_HangSanXuat].* FROM [GPM_HangSanXuat] WHERE [DAXOA]=0 and ID != 1";
                using (SqlCommand command = new SqlCommand(cmdText, con))
                using (SqlDataReader reader = command.ExecuteReader())
                {
                    DataTable tb = new DataTable();
                    tb.Load(reader);
                    return tb;
                }
            }
        }
        public int LayNhaSanXuat_GetID(string Ten)
        {
            using (SqlConnection con = new SqlConnection(StaticContext.ConnectionString))
            {
                con.Open();
                string cmdText = " SELECT ID FROM [GPM_HangSanXuat] WHERE [DAXOA] = 0 AND TenNhanHang ='" + Ten + "'";
                using (SqlCommand command = new SqlCommand(cmdText, con))
                using (SqlDataReader reader = command.ExecuteReader())
                {
                    string s = "1";
                    DataTable tb = new DataTable();
                    tb.Load(reader);
                    if (tb.Rows.Count != 0)
                    {
                        DataRow dr = tb.Rows[0];
                        s = dr["ID"].ToString();
                    }
                    return Int32.Parse(s);
                }
            }
        }
    }
}