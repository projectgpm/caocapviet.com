﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace BanHang.Data
{
    public class dtThevoucher
    {
        // Temp

        public DataTable LayDanhSachThevoucher_Temp()
        {
            using (SqlConnection con = new SqlConnection(StaticContext.ConnectionString))
            {
                con.Open();
                string cmdText = " SELECT * FROM [GPM_Temp_TheVoucher]";
                using (SqlCommand command = new SqlCommand(cmdText, con))
                using (SqlDataReader reader = command.ExecuteReader())
                {
                    DataTable tb = new DataTable();
                    tb.Load(reader);
                    return tb;
                }
            }
        }

        public void ThemTheVoucher_Temp(string MaVoucher, string TenVoucher, DateTime TuNgay, DateTime DenNgay, float GiaTri, DateTime NgayTao)
        {
            using (SqlConnection myConnection = new SqlConnection(StaticContext.ConnectionString))
            {
                try
                {
                    myConnection.Open();
                    string cmdText = "INSERT INTO [GPM_Temp_TheVoucher] ([MaVoucher],[TenVoucher],[TuNgay],[DenNgay],[GiaTri],[NgayTao]) VALUES (@MaVoucher,@TenVoucher,@TuNgay,@DenNgay,@GiaTri,@NgayTao)";
                    using (SqlCommand myCommand = new SqlCommand(cmdText, myConnection))
                    {
                        myCommand.Parameters.AddWithValue("@MaVoucher", MaVoucher);
                        myCommand.Parameters.AddWithValue("@TenVoucher", TenVoucher);
                        myCommand.Parameters.AddWithValue("@TuNgay", TuNgay);
                        myCommand.Parameters.AddWithValue("@DenNgay", DenNgay);
                        myCommand.Parameters.AddWithValue("@GiaTri", GiaTri);
                        myCommand.Parameters.AddWithValue("@NgayTao", NgayTao);
                        myCommand.ExecuteNonQuery();
                    }
                    myConnection.Close();
                }
                catch
                {
                    throw new Exception("Lỗi: Quá trình thêm dữ liệu gặp lỗi");
                }
            }
        }
        public void SuaTheVoucher_temp(int ID, string MaVoucher, string TenVoucher, DateTime TuNgay, DateTime DenNgay, float GiaTri, DateTime NgayTao)
        {
            using (SqlConnection myConnection = new SqlConnection(StaticContext.ConnectionString))
            {
                try
                {
                    myConnection.Open();
                    string cmdText = "UPDATE [GPM_Temp_TheVoucher] SET [MaVoucher] = @MaVoucher, [TenVoucher] = @TenVoucher, [TuNgay] = @TuNgay, [DenNgay] = @DenNgay, [GiaTri] = @GiaTri, [NgayTao] = @NgayTao WHERE [ID] = @ID";
                    using (SqlCommand myCommand = new SqlCommand(cmdText, myConnection))
                    {
                        myCommand.Parameters.AddWithValue("@MaVoucher", MaVoucher);
                        myCommand.Parameters.AddWithValue("@TenVoucher", TenVoucher);
                        myCommand.Parameters.AddWithValue("@TuNgay", TuNgay);
                        myCommand.Parameters.AddWithValue("@DenNgay", DenNgay);
                        myCommand.Parameters.AddWithValue("@GiaTri", GiaTri);
                        myCommand.Parameters.AddWithValue("@NgayTao", NgayTao);
                        myCommand.Parameters.AddWithValue("@ID", ID);
                        myCommand.ExecuteNonQuery();
                    }
                    myConnection.Close();
                }
                catch
                {
                    throw new Exception("Lỗi: Quá trình cập nhật dữ liệu gặp lỗi");
                }
            }
        }
        public void XoaTheVoucher_Temp()
        {
            using (SqlConnection myConnection = new SqlConnection(StaticContext.ConnectionString))
            {
                try
                {
                    myConnection.Open();
                    string strSQL = "DELETE [GPM_Temp_TheVoucher]";
                    using (SqlCommand myCommand = new SqlCommand(strSQL, myConnection))
                    {
                        myCommand.ExecuteNonQuery();
                    }
                }
                catch (Exception e)
                {
                    throw new Exception("Lỗi: Quá trình cập nhật dữ liệu gặp lỗi, hãy tải lại trang");
                }
            }
        }
        public void XoaTheVoucher_Temp_ID(int ID)
        {
            using (SqlConnection myConnection = new SqlConnection(StaticContext.ConnectionString))
            {
                try
                {
                    myConnection.Open();
                    string strSQL = "DELETE [GPM_Temp_TheVoucher] WHERE ID = @ID";
                    using (SqlCommand myCommand = new SqlCommand(strSQL, myConnection))
                    {
                        myCommand.Parameters.AddWithValue("@ID", ID);
                        myCommand.ExecuteNonQuery();
                    }
                }
                catch (Exception e)
                {
                    throw new Exception("Lỗi: Quá trình cập nhật dữ liệu gặp lỗi, hãy tải lại trang");
                }
            }
        }
        // News
        public DataTable LayDanhSachThevoucher()
        {
            using (SqlConnection con = new SqlConnection(StaticContext.ConnectionString))
            {
                con.Open();
                string cmdText = " SELECT * FROM [GPM_TheVoucher]";
                using (SqlCommand command = new SqlCommand(cmdText, con))
                using (SqlDataReader reader = command.ExecuteReader())
                {
                    DataTable tb = new DataTable();
                    tb.Load(reader);
                    return tb;
                }
            }
        }

        public void ThemTheVoucher(string MaVoucher, string TenVoucher, DateTime TuNgay, DateTime DenNgay, float GiaTri, DateTime NgayTao)
        {
            using (SqlConnection myConnection = new SqlConnection(StaticContext.ConnectionString))
            {
                try
                {
                    myConnection.Open();
                    string cmdText = "INSERT INTO [GPM_TheVoucher] ([MaVoucher],[TenVoucher],[TuNgay],[DenNgay],[GiaTri],[NgayTao]) VALUES (@MaVoucher,@TenVoucher,@TuNgay,@DenNgay,@GiaTri,@NgayTao)";
                    using (SqlCommand myCommand = new SqlCommand(cmdText, myConnection))
                    {
                        myCommand.Parameters.AddWithValue("@MaVoucher", MaVoucher);
                        myCommand.Parameters.AddWithValue("@TenVoucher", TenVoucher);
                        myCommand.Parameters.AddWithValue("@TuNgay", TuNgay);
                        myCommand.Parameters.AddWithValue("@DenNgay", DenNgay);
                        myCommand.Parameters.AddWithValue("@GiaTri", GiaTri);
                        myCommand.Parameters.AddWithValue("@NgayTao", NgayTao);
                        myCommand.ExecuteNonQuery();
                    }
                    myConnection.Close();
                }
                catch
                {
                    throw new Exception("Lỗi: Quá trình thêm dữ liệu gặp lỗi");
                }
            }
        }
        public void SuaTheVoucher(int ID, string MaVoucher, string TenVoucher, DateTime TuNgay, DateTime DenNgay, float GiaTri, DateTime NgayTao)
        {
            using (SqlConnection myConnection = new SqlConnection(StaticContext.ConnectionString))
            {
                try
                {
                    myConnection.Open();
                    string cmdText = "UPDATE [GPM_TheVoucher] SET [MaVoucher] = @MaVoucher, [TenVoucher] = @TenVoucher, [TuNgay] = @TuNgay, [DenNgay] = @DenNgay, [GiaTri] = @GiaTri, [NgayTao] = @NgayTao WHERE [ID] = @ID";
                    using (SqlCommand myCommand = new SqlCommand(cmdText, myConnection))
                    {
                        myCommand.Parameters.AddWithValue("@MaVoucher", MaVoucher);
                        myCommand.Parameters.AddWithValue("@TenVoucher", TenVoucher);
                        myCommand.Parameters.AddWithValue("@TuNgay", TuNgay);
                        myCommand.Parameters.AddWithValue("@DenNgay", DenNgay);
                        myCommand.Parameters.AddWithValue("@GiaTri", GiaTri);
                        myCommand.Parameters.AddWithValue("@NgayTao", NgayTao);
                        myCommand.Parameters.AddWithValue("@ID", ID);
                        myCommand.ExecuteNonQuery();
                    }
                    myConnection.Close();
                }
                catch
                {
                    throw new Exception("Lỗi: Quá trình cập nhật dữ liệu gặp lỗi");
                }
            }
        }
        public void XoaTheVoucher(int ID)
        {
            using (SqlConnection myConnection = new SqlConnection(StaticContext.ConnectionString))
            {
                try
                {
                    myConnection.Open();
                    string strSQL = "DELETE [GPM_TheVoucher] WHERE ID = @ID";
                    using (SqlCommand myCommand = new SqlCommand(strSQL, myConnection))
                    {
                        myCommand.Parameters.AddWithValue("@ID", ID);
                        myCommand.ExecuteNonQuery();
                    }
                }
                catch (Exception e)
                {
                    throw new Exception("Lỗi: Quá trình cập nhật dữ liệu gặp lỗi, hãy tải lại trang");
                }
            }
        }
        
    }
}