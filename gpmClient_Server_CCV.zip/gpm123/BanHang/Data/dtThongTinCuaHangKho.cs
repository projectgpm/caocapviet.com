﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace BanHang.Data
{
    public class dtThongTinCuaHangKho
    {
        public DataTable LayDanhSachCombo()
        {
            using (SqlConnection con = new SqlConnection(StaticContext.ConnectionString))
            {
                con.Open();
                string cmdText = " SELECT * FROM [GPM_ThongTinCuaHangKho] WHERE [DAXOA] = 0 AND ID !=" + dtSetting.LayIDKho();
                using (SqlCommand command = new SqlCommand(cmdText, con))
                using (SqlDataReader reader = command.ExecuteReader())
                {
                    DataTable tb = new DataTable();
                    tb.Load(reader);
                    return tb;
                }
            }
        }
        public DataTable LayDanhSach()
        {
            using (SqlConnection con = new SqlConnection(StaticContext.ConnectionString))
            {
                con.Open();
                string cmdText = " SELECT * FROM [GPM_ThongTinCuaHangKho] WHERE [DAXOA] = 0";
                using (SqlCommand command = new SqlCommand(cmdText, con))
                using (SqlDataReader reader = command.ExecuteReader())
                {
                    DataTable tb = new DataTable();
                    tb.Load(reader);
                    return tb;
                }
            }
        }

        public DataTable LayDanhSach_ID()
        {
            using (SqlConnection con = new SqlConnection(StaticContext.ConnectionString))
            {
                con.Open();
                string cmdText = " SELECT * FROM [GPM_ThongTinCuaHangKho] WHERE [DAXOA] = 0 AND ID = 1";
                using (SqlCommand command = new SqlCommand(cmdText, con))
                using (SqlDataReader reader = command.ExecuteReader())
                {
                    DataTable tb = new DataTable();
                    tb.Load(reader);
                    return tb;
                }
            }
        }
        public DataTable LayDanhSach_ID_2(int ID)
        {
            using (SqlConnection con = new SqlConnection(StaticContext.ConnectionString))
            {
                con.Open();
                string cmdText = " SELECT * FROM [GPM_ThongTinCuaHangKho] WHERE [DAXOA] = 0 AND ID = '" + ID+ "'";
                using (SqlCommand command = new SqlCommand(cmdText, con))
                using (SqlDataReader reader = command.ExecuteReader())
                {
                    DataTable tb = new DataTable();
                    tb.Load(reader);
                    return tb;
                }
            }
        }
        public object Them(string TenCuaHang, string SoSerial, string DiaChi, int IDQuan, int IDThanhPho, string DienThoai, string MaKho,DateTime NgayMo,int IDVung)
        {
            using (SqlConnection myConnection = new SqlConnection(StaticContext.ConnectionString))
            {
                try
                {
                    myConnection.Open();
                    object IDPhieuNhapSi = null;
                    string cmdText = "INSERT INTO [GPM_ThongTinCuaHangKho] ([TenCuaHang], [SoSerial], [DiaChi], [IDQuan] ,[IDThanhPho], [DienThoai], [NgayCapNhat],[MaKho],[IDVung])  OUTPUT INSERTED.ID  VALUES (@TenCuaHang, @SoSerial, @DiaChi, @IDQuan, @IDThanhPho ,@DienThoai, @NgayMo,@MaKho,@IDVung)";
                    using (SqlCommand myCommand = new SqlCommand(cmdText, myConnection))
                    {
                        myCommand.Parameters.AddWithValue("@TenCuaHang", TenCuaHang);
                        myCommand.Parameters.AddWithValue("@SoSerial", SoSerial);
                        myCommand.Parameters.AddWithValue("@DiaChi", DiaChi);
                        myCommand.Parameters.AddWithValue("@IDQuan", IDQuan);
                        myCommand.Parameters.AddWithValue("@IDThanhPho", IDThanhPho);
                        myCommand.Parameters.AddWithValue("@DienThoai", DienThoai);
                        myCommand.Parameters.AddWithValue("@MaKho", MaKho);
                        myCommand.Parameters.AddWithValue("@NgayMo", NgayMo);
                        myCommand.Parameters.AddWithValue("@IDVung", IDVung);
                        IDPhieuNhapSi = myCommand.ExecuteScalar();
                    }
                    myConnection.Close();
                    return IDPhieuNhapSi;
                }
                catch
                {
                    throw new Exception("Lỗi: Quá trình thêm dữ liệu gặp lỗi");
                }
            }
        }

        public object Them_Full(string TenCuaHang, string SoSerial, string DiaChi, int IDQuan, int IDThanhPho, string DienThoai, string MaKho, DateTime NgayMo, int IDVung, int DaXoa)
        {
            using (SqlConnection myConnection = new SqlConnection(StaticContext.ConnectionString))
            {
                try
                {
                    myConnection.Open();
                    object IDPhieuNhapSi = null;
                    string cmdText = "INSERT INTO [GPM_ThongTinCuaHangKho] ([TenCuaHang], [SoSerial], [DiaChi], [IDQuan] ,[IDThanhPho], [DienThoai], [NgayCapNhat],[DaXoa],[MaKho],[IDVung])  OUTPUT INSERTED.ID  VALUES (@TenCuaHang, @SoSerial, @DiaChi, @IDQuan, @IDThanhPho ,@DienThoai, @NgayMo,@DaXoa,@MaKho,@IDVung)";
                    using (SqlCommand myCommand = new SqlCommand(cmdText, myConnection))
                    {
                        myCommand.Parameters.AddWithValue("@TenCuaHang", TenCuaHang);
                        myCommand.Parameters.AddWithValue("@SoSerial", SoSerial);
                        myCommand.Parameters.AddWithValue("@DiaChi", DiaChi);
                        myCommand.Parameters.AddWithValue("@IDQuan", IDQuan);
                        myCommand.Parameters.AddWithValue("@IDThanhPho", IDThanhPho);
                        myCommand.Parameters.AddWithValue("@DienThoai", DienThoai);
                        myCommand.Parameters.AddWithValue("@DaXoa", DaXoa);
                        myCommand.Parameters.AddWithValue("@MaKho", MaKho);
                        myCommand.Parameters.AddWithValue("@NgayMo", NgayMo);
                        myCommand.Parameters.AddWithValue("@IDVung", IDVung);
                        IDPhieuNhapSi = myCommand.ExecuteScalar();
                    }
                    myConnection.Close();
                    return IDPhieuNhapSi;
                }
                catch
                {
                    throw new Exception("Lỗi: Quá trình thêm dữ liệu gặp lỗi");
                }
            }
        }
        public void Xoa(int ID)
        {
            using (SqlConnection myConnection = new SqlConnection(StaticContext.ConnectionString))
            {
                try
                {
                    myConnection.Open();
                    string strSQL = "UPDATE [GPM_ThongTinCuaHangKho] SET [DAXOA] =  1 WHERE [ID] = @ID";
                    using (SqlCommand myCommand = new SqlCommand(strSQL, myConnection))
                    {
                        myCommand.Parameters.AddWithValue("@ID", ID);
                        myCommand.ExecuteNonQuery();
                    }
                }
                catch (Exception e)
                {
                    throw new Exception("Lỗi: Quá trình Xóa dữ liệu gặp lỗi, hãy tải lại trang");
                }
            }
        }

        public void Sua(int ID, string TenCuaHang, string SoSerial, string DiaChi, int IDQuan, int IDThanhPho, string DienThoai, string MaKho, DateTime NgayMo, int IDVung)
        {
            using (SqlConnection myConnection = new SqlConnection(StaticContext.ConnectionString))
            {
                try
                {
                    myConnection.Open();
                    string strSQL = "UPDATE [GPM_ThongTinCuaHangKho] SET [TenCuaHang] = @TenCuaHang, [SoSerial] = @SoSerial, [DiaChi] = @DiaChi, [IDQuan] = @IDQuan, [IDThanhPho] = @IDThanhPho, [DienThoai] = @DienThoai, [NgayCapNhat] = @NgayMo,[IDVung] = @IDVung,[MaKho] = @MaKho WHERE [ID] = @ID";
                    using (SqlCommand myCommand = new SqlCommand(strSQL, myConnection))
                    {
                        myCommand.Parameters.AddWithValue("@ID", ID);
                        myCommand.Parameters.AddWithValue("@TenCuaHang", TenCuaHang);
                        myCommand.Parameters.AddWithValue("@SoSerial", SoSerial);
                        myCommand.Parameters.AddWithValue("@DiaChi", DiaChi);
                        myCommand.Parameters.AddWithValue("@IDQuan", IDQuan);
                        myCommand.Parameters.AddWithValue("@IDThanhPho", IDThanhPho);
                        myCommand.Parameters.AddWithValue("@DienThoai", DienThoai);
                        myCommand.Parameters.AddWithValue("@MaKho", MaKho);
                        myCommand.Parameters.AddWithValue("@NgayMo", NgayMo);
                        myCommand.Parameters.AddWithValue("@IDVung", IDVung);
                        myCommand.ExecuteNonQuery();
                    }
                }
                catch (Exception e)
                {
                    throw new Exception("Lỗi: Quá trình cập nhật dữ liệu gặp lỗi, hãy tải lại trang");
                }
            }
        }

        public void UpdateCapNhatNews()
        {
            using (SqlConnection myConnection = new SqlConnection(StaticContext.ConnectionString))
            {
                try
                {
                    myConnection.Open();
                    string strSQL = "UPDATE [GPM_ThongTinCuaHangKho] SET [CapNhatNews] = @CapNhatNews";
                    using (SqlCommand myCommand = new SqlCommand(strSQL, myConnection))
                    {
                        myCommand.Parameters.AddWithValue("@CapNhatNews", 1);
                        myCommand.ExecuteNonQuery();
                    }
                }
                catch (Exception e)
                {
                    throw new Exception("Lỗi: Quá trình cập nhật dữ liệu gặp lỗi, hãy tải lại trang");
                }
            }
        }

        public void Sua_Full(int ID, string TenCuaHang, string SoSerial, string DiaChi, int IDQuan, int IDThanhPho, DateTime NgayCapNhat, string DienThoai, int DaXoa, string MaKho, int IDVung)
        {
            using (SqlConnection myConnection = new SqlConnection(StaticContext.ConnectionString))
            {
                try
                {
                    myConnection.Open();
                    string strSQL = "UPDATE [GPM_ThongTinCuaHangKho] SET [TenCuaHang] = @TenCuaHang, [SoSerial] = @SoSerial,[MaKho] = @MaKho,[IDVung] = @IDVung, [DiaChi] = @DiaChi, [IDQuan] = @IDQuan, [IDThanhPho] = @IDThanhPho, [DienThoai] = @DienThoai, [NgayCapNhat] = @NgayCapNhat, [DaXoa] = @DaXoa WHERE [ID] = @ID";
                    using (SqlCommand myCommand = new SqlCommand(strSQL, myConnection))
                    {
                        myCommand.Parameters.AddWithValue("@ID", ID);
                        myCommand.Parameters.AddWithValue("@TenCuaHang", TenCuaHang);
                        myCommand.Parameters.AddWithValue("@SoSerial", SoSerial);
                        myCommand.Parameters.AddWithValue("@DiaChi", DiaChi);
                        myCommand.Parameters.AddWithValue("@IDQuan", IDQuan);
                        myCommand.Parameters.AddWithValue("@IDThanhPho", IDThanhPho);
                        myCommand.Parameters.AddWithValue("@DienThoai", DienThoai);
                        myCommand.Parameters.AddWithValue("@NgayCapNhat", NgayCapNhat);
                        myCommand.Parameters.AddWithValue("@DaXoa", DaXoa);
                        myCommand.Parameters.AddWithValue("@IDVung", IDVung);
                        myCommand.Parameters.AddWithValue("@MaKho", MaKho);
                        myCommand.ExecuteNonQuery();
                    }
                }
                catch (Exception e)
                {
                    throw new Exception("Lỗi: Quá trình cập nhật dữ liệu gặp lỗi, hãy tải lại trang");
                }
            }
        }
    }
}