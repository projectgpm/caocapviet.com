﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Net.NetworkInformation;
using System.Security.Cryptography;
using System.Web;

namespace BanHang.Data
{
    public class ActionCilent
    {
        public static PhysicalAddress GetMacAddress()
        {
            NetworkInterface[] nic1 = NetworkInterface.GetAllNetworkInterfaces();
            foreach (NetworkInterface nic in NetworkInterface.GetAllNetworkInterfaces())
            {
                if (nic.Name.ToString().CompareTo("Wi-Fi") == 0 || nic.Name.ToString().CompareTo("Ethernet") == 0)
                {
                    return nic.GetPhysicalAddress();
                }
            }
            return null;
        }

        // -----------
        public static string GetSHA1HashData(string data)
        {
            //create new instance of md5
            SHA1 sha1 = SHA1.Create();

            byte[] hashData = sha1.ComputeHash(System.Text.Encoding.UTF8.GetBytes(data + 123));

            System.Text.StringBuilder returnValue = new System.Text.StringBuilder();

            for (int i = 0; i < hashData.Length; i++)
            {
                returnValue.Append(hashData[i].ToString("x"));
            }

            return returnValue.ToString();
        }
        public static void setData_Setting(string keyCode, string user)
        {
            using (SqlConnection myConnection = new SqlConnection(StaticContext.ConnectionString))
            {
                try
                {
                    myConnection.Open();
                    string strSQL = "UPDATE [Setting] SET [KeyCode] = @KeyCode, [NguoiKichHoat] = @NguoiKichHoat";
                    using (SqlCommand myCommand = new SqlCommand(strSQL, myConnection))
                    {
                        myCommand.Parameters.AddWithValue("@KeyCode", keyCode);
                        myCommand.Parameters.AddWithValue("@NguoiKichHoat", user);
                        myCommand.ExecuteNonQuery();
                    }
                }
                catch (Exception e)
                {
                    throw new Exception("Lỗi: Quá trình cập nhật dữ liệu gặp lỗi, hãy tải lại trang");
                }
            }
        }
        public static DataTable getData_Setting()
        {
            using (SqlConnection con = new SqlConnection(StaticContext.ConnectionString))
            {
                try
                {
                    con.Open();
                    string cmdText = "SELECT KeyCode FROM [Setting]";
                    using (SqlCommand command = new SqlCommand(cmdText, con))
                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        DataTable tb = new DataTable();
                        tb.Load(reader);
                        return tb;
                    }
                }
                catch (Exception)
                {
                    return null;
                }
            }
        }

        // Key code..
        public static int setKeyCode(string Key, string user)
        {
            PhysicalAddress address = GetMacAddress();
            string strAddress = address.ToString();

            if (Key.CompareTo("1231123") == 0)
            {
                string sha1Address = GetSHA1HashData(strAddress);
                setData_Setting(sha1Address, user);
                return 1;
            }
            return -1;

        }
        public static int getKeyCode()
        {
            PhysicalAddress address = GetMacAddress();
            string strAddress = address.ToString();
            string sha1Address = GetSHA1HashData(strAddress);

            DataTable da = getData_Setting();
            if (da.Rows.Count != 0)
            {
                DataRow dr = da.Rows[0];
                string macAddress = dr["KeyCode"].ToString();
                if (macAddress.CompareTo(sha1Address) == 0)
                    return 1;
            }
            return -1;
        }

        // Check Data
        public static int CheckData_Update()
        {
            int IDKho = dtSetting.LayIDKho();
            using (SqlConnection con = new SqlConnection(StaticContext.ConnectionServer))
            {
                try
                {
                    con.Open();
                    string cmdText = "SELECT CapNhatNews FROM [GPM_ThongTinCuaHangKho] WHERE ID=" + IDKho;
                    using (SqlCommand command = new SqlCommand(cmdText, con))
                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        DataTable tb = new DataTable();
                        tb.Load(reader);
                        if (tb.Rows.Count != 0)
                        {
                            DataRow r = tb.Rows[0];
                            int kt = Int32.Parse(r["CapNhatNews"].ToString());
                            return kt;
                        }
                        else return -1;
                    }
                }
                catch (Exception)
                {
                    return -1;
                }
            }
        }
        public static void UpdateFinished()
        {
            int IDKho = dtSetting.LayIDKho();
            using (SqlConnection myConnection = new SqlConnection(StaticContext.ConnectionServer))
            {
                try
                {
                    myConnection.Open();
                    string cmdText = "UPDATE [GPM_ThongTinCuaHangKho] SET [CapNhatNews] = @CapNhatNews WHERE [ID] = @ID";
                    using (SqlCommand myCommand = new SqlCommand(cmdText, myConnection))
                    {
                        myCommand.Parameters.AddWithValue("@ID", IDKho);
                        myCommand.Parameters.AddWithValue("@CapNhatNews", 0);
                        myCommand.ExecuteNonQuery();
                    }
                    myConnection.Close();
                }
                catch
                {
                    throw new Exception("Lỗi: Quá trình thêm dữ liệu gặp lỗi");
                }
            }
        }

        public static void CapNhatClient()
        {
            //if (CheckUpdateDataServer() == -1)
            //{
            //    InsertData_Server();
            //    updateData_Server();
            //}
        }

        public static int CheckUpdateDataServer()
        {
            int kt = CheckData_Update();
            if (kt == 1)
            {
                updateData_Client();
                InsertData_Server();
                updateData_Server();

                UpdateFinished();
                return 1;
            }
            return -1;
        }

        // Cập nhật về Client.... một chiều....
        public static void updateData_Client()
        {
            updateNganhHang();
            updateNhomHang();
            updateHangHoa();
            updateBarcode();
            updateHangHoaCombo();
            updateHangHoaTonKho();
            updateDonViTinh();
            updateThongTinCuaHangKho();
            updateThongTinHangSanXuat();
            updateNhomKhachHang();
            updateVung();
            //updateQuan();
            //updateThanhPho();
            updateNhomNguoiDung();
            updateMenu();
            updatePhanQuyen();
            updateNhaCungCap();
            //updateData_DonDatHangDaDuyet_Client();
            insert_PhieuChuyenKho_Server_To_KhoXuat();
            insert_PhieuChuyenKho_Server_To_KhoNhap();
            //updateData_PhieuChuyenKho_KhoXuat_GD2_Client();
            //updateData_PhieuChuyenKho_KhoNhap_GD3_Client();
        }

        // Insert lên server.
        public static void InsertData_Server()
        {
            insertLichSuTruyCap();
            insertLichSuKho();
            insert_KhachHang();
            //insert_PhieuChuyenKho();
            insert_HoaDon();
            insert_ChiTietHoaDon();
            insert_DonDatHang();
            insert_ChiTietDonDatHang();
            insert_PhieuDoiHang();
            insert_ChiTietPhieuDoiHang();
        }

        // Cập nhật dữ liệu lên server.
        public static void updateData_Server()
        {
            update_HangHoaTonKho_Server();
            //update_DonDatHang_DaNhanHang_Server();
            //updateData_PhieuChuyenKho_XuatDuyet_Server();
            //updateData_PhieuChuyenKho_NhapDuyet();
        }

        //// ======================================================================//
        //// ======================================================================//
        //// ======================================================================//
        //// ======================================================================//

        //// Cập nhật dữ liệu lên server.
        //// -----------------
        // Hàng Hóa Tồn Kho
        public static DataTable getData_HangHoaTonKho()
        {
            int IDKho = dtSetting.LayIDKho();
            using (SqlConnection con = new SqlConnection(StaticContext.ConnectionString))
            {
                try
                {
                    con.Open();
                    string cmdText = " SELECT * FROM [GPM_HangHoaTonKho]";
                    using (SqlCommand command = new SqlCommand(cmdText, con))
                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        DataTable tb = new DataTable();
                        tb.Load(reader);
                        return tb;
                    }
                }
                catch (Exception) { return new DataTable(); }
            }
        }
        public static void update_HangHoaTonKho_Server(int IDKho, int IDHangHoa, DateTime NgayCapNhat, int SoLuongCon)
        {
            using (SqlConnection myConnection = new SqlConnection(StaticContext.ConnectionServer))
            {
                try
                {
                    myConnection.Open();
                    string cmdText = "UPDATE [GPM_HangHoaTonKho] SET [NgayCapNhat] = @NgayCapNhat, [SoLuongCon] = @SoLuongCon WHERE  [IDKho] = @IDKho AND [IDHangHoa] = @IDHangHoa";
                    using (SqlCommand myCommand = new SqlCommand(cmdText, myConnection))
                    {
                        myCommand.Parameters.AddWithValue("@IDKho", IDKho);
                        myCommand.Parameters.AddWithValue("@IDHangHoa", IDHangHoa);
                        myCommand.Parameters.AddWithValue("@NgayCapNhat", NgayCapNhat);
                        myCommand.Parameters.AddWithValue("@SoLuongCon", SoLuongCon);
                        myCommand.ExecuteNonQuery();
                    }
                    myConnection.Close();
                }
                catch
                {
                    //throw new Exception("Lỗi: Quá trình thêm dữ liệu gặp lỗi");
                }
            }
        }
        public static void update_HangHoaTonKho_Server()
        {
            int IDKho = dtSetting.LayIDKho();
            DataTable da = getData_HangHoaTonKho();
            if (da.Rows.Count != 0)
            {
                for (int i = 0; i < da.Rows.Count; i++)
                {
                    DataRow dr = da.Rows[i];
                    int ID = Int32.Parse(dr["ID"].ToString());
                    int IDHangHoa = Int32.Parse(dr["IDHangHoa"].ToString());
                    DateTime NgayCapNhat = DateTime.Parse(dr["NgayCapNhat"].ToString());
                    int SoLuongCon = Int32.Parse(dr["SoLuongCon"].ToString());
                    update_HangHoaTonKho_Server(IDKho, IDHangHoa, NgayCapNhat, SoLuongCon);
                }
            }
        }

        // Đơn đặt hàng. Đã nhận hàng
        public static DataTable getData_DonDatHang_DaNhanHang()
        {
            int IDKho = dtSetting.LayIDKho();
            using (SqlConnection con = new SqlConnection(StaticContext.ConnectionString))
            {
                try
                {
                    con.Open();
                    string cmdText = " SELECT * FROM [GPM_DonDatHang] WHERE TrangThai = 2";
                    using (SqlCommand command = new SqlCommand(cmdText, con))
                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        DataTable tb = new DataTable();
                        tb.Load(reader);
                        return tb;
                    }
                }
                catch (Exception) { return new DataTable(); }
            }
        }
        public static void update_DonDatHang_DaNhanHang_Server(int ID, int TrangThai)
        {
            using (SqlConnection myConnection = new SqlConnection(StaticContext.ConnectionServer))
            {
                try
                {
                    myConnection.Open();
                    string cmdText = "UPDATE [GPM_DonDatHang] SET [TrangThai] = @TrangThai WHERE [TrangThai] < @TrangThai AND [ID] = @ID";
                    using (SqlCommand myCommand = new SqlCommand(cmdText, myConnection))
                    {
                        myCommand.Parameters.AddWithValue("@ID", ID);
                        myCommand.Parameters.AddWithValue("@TrangThai", TrangThai);
                        myCommand.ExecuteNonQuery();
                    }
                    myConnection.Close();
                }
                catch
                {
                    //throw new Exception("Lỗi: Quá trình thêm dữ liệu gặp lỗi");
                }
            }
        }
        public static void update_DonDatHang_DaNhanHang_end(int ID)
        {
            using (SqlConnection myConnection = new SqlConnection(StaticContext.ConnectionString))
            {
                try
                {
                    myConnection.Open();
                    string cmdText = "UPDATE [GPM_DonDatHang] SET [TrangThai] = 3 WHERE  [ID] = @ID";
                    using (SqlCommand myCommand = new SqlCommand(cmdText, myConnection))
                    {
                        myCommand.Parameters.AddWithValue("@ID", ID);
                        myCommand.ExecuteNonQuery();
                    }
                    myConnection.Close();
                }
                catch
                {
                    //throw new Exception("Lỗi: Quá trình thêm dữ liệu gặp lỗi");
                }
            }
        }
        public static void update_DonDatHang_DaNhanHang_Server()
        {
            int IDKho = dtSetting.LayIDKho();
            DataTable da = getData_DonDatHang_DaNhanHang();
            if (da.Rows.Count != 0)
            {
                for (int i = 0; i < da.Rows.Count; i++)
                {
                    DataRow dr = da.Rows[i];
                    int ID = Int32.Parse(dr["ID"].ToString());
                    int IDServer = Int32.Parse(dr["IDServer"].ToString());
                    int TrangThai = Int32.Parse(dr["TrangThai"].ToString());
                    update_DonDatHang_DaNhanHang_Server(IDServer, TrangThai);
                    update_DonDatHang_DaNhanHang_end(ID);
                }
            }
        }
        
        //// -----------------
        // Cập nhật phiếu chuyển kho lên
        public static DataTable getData_PhieuChuyenKho_XuatDuyet()
        {
            int IDKhoXuat = dtSetting.LayIDKho();
            using (SqlConnection con = new SqlConnection(StaticContext.ConnectionString))
            {
                try
                {
                    con.Open();
                    string cmdText = " SELECT * FROM [GPM_PhieuChuyenKho] WHERE (TrangThai = 1 OR TrangThai = 3) AND IDKhoXuat = " + IDKhoXuat;
                    using (SqlCommand command = new SqlCommand(cmdText, con))
                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        DataTable tb = new DataTable();
                        tb.Load(reader);
                        return tb;
                    }
                }
                catch (Exception) { return new DataTable(); }
            }
        }
        public static DataTable update_PhieuChuyenKho_Duyet(int ID, int TrangThai)
        {
            int IDKho = dtSetting.LayIDKho();
            using (SqlConnection con = new SqlConnection(StaticContext.ConnectionServer))
            {
                try
                {
                    con.Open();
                    string cmdText = "UPDATE [GPM_PhieuChuyenKho] SET [TrangThai] = '" + TrangThai + "' WHERE ID = " + ID;
                    using (SqlCommand command = new SqlCommand(cmdText, con))
                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        DataTable tb = new DataTable();
                        tb.Load(reader);
                        return tb;
                    }
                }
                catch (Exception) { return new DataTable(); }
            }
        }
        public static void updateData_PhieuChuyenKho_XuatDuyet_Server()
        {
            DataTable da = getData_PhieuChuyenKho_XuatDuyet();
            if (da.Rows.Count != 0)
            {
                for (int i = 0; i < da.Rows.Count; i++)
                {
                    DataRow dr = da.Rows[i];
                    int ID = Int32.Parse(dr["ID"].ToString());
                    int IDServer = Int32.Parse(dr["IDServer"].ToString());
                    int TrangThai = Int32.Parse(dr["TrangThai"].ToString());
                    update_PhieuChuyenKho_Duyet(IDServer, TrangThai);
                }
            }
        }
        // Cập nhật phiếu chuyển kho lên
        public static DataTable getData_PhieuChuyenKho_NhapDuyet()
        {
            int IDKhoNhap = dtSetting.LayIDKho();
            using (SqlConnection con = new SqlConnection(StaticContext.ConnectionString))
            {
                try
                {
                    con.Open();
                    string cmdText = " SELECT * FROM [GPM_PhieuChuyenKho] WHERE TrangThai = 4 AND IDKhoNhap = " + IDKhoNhap;
                    using (SqlCommand command = new SqlCommand(cmdText, con))
                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        DataTable tb = new DataTable();
                        tb.Load(reader);
                        return tb;
                    }
                }
                catch (Exception) { return new DataTable(); }
            }
        }
        public static DataTable update_PhieuChuyenKho_Duyet_End(int ID, int TrangThai)
        {
            int IDKho = dtSetting.LayIDKho();
            using (SqlConnection con = new SqlConnection(StaticContext.ConnectionString))
            {
                try
                {
                    con.Open();
                    string cmdText = " UPDATE [GPM_PhieuChuyenKho] SET [TrangThai] = '" + TrangThai + "' WHERE ID = " + ID;
                    using (SqlCommand command = new SqlCommand(cmdText, con))
                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        DataTable tb = new DataTable();
                        tb.Load(reader);
                        return tb;
                    }
                }
                catch (Exception) { return new DataTable(); }
            }
        }
        public static void updateData_PhieuChuyenKho_NhapDuyet()
        {
            DataTable da = getData_PhieuChuyenKho_NhapDuyet();
            if (da.Rows.Count != 0)
            {
                for (int i = 0; i < da.Rows.Count; i++)
                {
                    DataRow dr = da.Rows[i];
                    int ID = Int32.Parse(dr["ID"].ToString());
                    int IDServer = Int32.Parse(dr["IDServer"].ToString());
                    int TrangThai = Int32.Parse(dr["TrangThai"].ToString());
                    update_PhieuChuyenKho_Duyet(IDServer, TrangThai);
                    update_PhieuChuyenKho_Duyet_End(ID,5);
                }
            }
        }
        
        // ======================================================================//
        // ======================================================================//
        // ======================================================================//
        // ======================================================================//

        // Insert dữ liệu lên server.
        // -----------------
        // Lịch sử truy cập.
        public static DataTable getData_LichSuTruyCap()
        {
            using (SqlConnection con = new SqlConnection(StaticContext.ConnectionString))
            {
                try
                {
                    con.Open();
                    string cmdText = "SELECT * FROM [GPM_LichSuTruyCap] WHERE InsertServer = 0";
                    using (SqlCommand command = new SqlCommand(cmdText, con))
                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        DataTable tb = new DataTable();
                        tb.Load(reader);
                        return tb;
                    }
                }
                catch (Exception)
                {
                    return new DataTable();
                }
            }
        }
        public static void updateData_LichSuTruyCap(int ID)
        {
            using (SqlConnection con = new SqlConnection(StaticContext.ConnectionString))
            {
                try
                {
                    con.Open();
                    string cmdText = "UPDATE [GPM_LichSuTruyCap] SET [InsertServer] = 1 WHERE ID = " + ID;
                    using (SqlCommand myCommand = new SqlCommand(cmdText, con))
                    {
                        myCommand.ExecuteNonQuery();
                    }
                }
                catch (Exception)
                {

                }
            }
        }
        public static void inserttLichSuTruyCap_Server(int IDKho, int IDNhanVien, int IDNhom, DateTime ThoiGian, string NoiDung, string TenMay, string TenChucNang, string HanhDong)
        {
            using (SqlConnection myConnection = new SqlConnection(StaticContext.ConnectionServer))
            {
                try
                {
                    myConnection.Open();
                    string cmdText = "INSERT INTO [GPM_LichSuTruyCap] ([IDKho],[IDNhanVien], [IDNhom], [ThoiGian], [NoiDung],[TenMay],[TenChucNang],[HanhDong]) VALUES (@IDKho,@IDNhanVien,@IDNhom,@ThoiGian,@NoiDung,@TenMay,@TenChucNang,@HanhDong)";
                    using (SqlCommand myCommand = new SqlCommand(cmdText, myConnection))
                    {
                        myCommand.Parameters.AddWithValue("@IDKho", IDKho);
                        myCommand.Parameters.AddWithValue("@IDNhanVien", IDNhanVien);
                        myCommand.Parameters.AddWithValue("@IDNhom", IDNhom);
                        myCommand.Parameters.AddWithValue("@ThoiGian", ThoiGian);
                        myCommand.Parameters.AddWithValue("@NoiDung", NoiDung);
                        myCommand.Parameters.AddWithValue("@TenMay", TenMay);
                        myCommand.Parameters.AddWithValue("@TenChucNang", TenChucNang);
                        myCommand.Parameters.AddWithValue("@HanhDong", HanhDong);
                        myCommand.ExecuteNonQuery();
                    }
                    myConnection.Close();
                }
                catch
                {
                    //throw new Exception("Lỗi: Quá trình thêm dữ liệu gặp lỗi");
                }
            }
        }
        public static void insertLichSuTruyCap()
        {
            DataTable data = getData_LichSuTruyCap();
            if (data.Rows.Count != 0)
            {
                for (int i = 0; i < data.Rows.Count; i++)
                {
                    DataRow dr = data.Rows[i];
                    int IDKho = dtSetting.LayIDKho();
                    int ID = Int32.Parse(dr["ID"].ToString());
                    int IDNhanVien = Int32.Parse(dr["IDNhanVien"].ToString());
                    int IDNhom = Int32.Parse(dr["IDNhom"].ToString());
                    DateTime ThoiGian = DateTime.Parse(dr["ThoiGian"].ToString());
                    string NoiDung = dr["NoiDung"].ToString();
                    string TenMay = dr["TenMay"].ToString();
                    string TenChucNang = dr["TenChucNang"].ToString();
                    string HanhDong = dr["HanhDong"].ToString();

                    inserttLichSuTruyCap_Server(IDKho,IDNhanVien,IDNhom,ThoiGian,NoiDung,TenMay,TenChucNang,HanhDong);
                    updateData_LichSuTruyCap(ID);
                }
            }
        }
        // -----------------
        // Lịch sử kho
        public static DataTable getData_LichSuKho()
        {
            using (SqlConnection con = new SqlConnection(StaticContext.ConnectionString))
            {
                try
                {
                    con.Open();
                    string cmdText = "SELECT * FROM [GPM_LichSuKho] WHERE InsertServer = 0";
                    using (SqlCommand command = new SqlCommand(cmdText, con))
                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        DataTable tb = new DataTable();
                        tb.Load(reader);
                        return tb;
                    }
                }
                catch (Exception)
                {
                    return new DataTable();
                }
            }
        }
        public static void updateData_LichSuKho(int ID)
        {
            using (SqlConnection con = new SqlConnection(StaticContext.ConnectionString))
            {
                try
                {
                    con.Open();
                    string cmdText = "UPDATE [GPM_LichSuKho] SET [InsertServer] = 1 WHERE ID = " + ID;
                    using (SqlCommand myCommand = new SqlCommand(cmdText, con))
                    {
                        myCommand.ExecuteNonQuery();
                    }
                }
                catch (Exception)
                {
                }
            }
        }
        public static void inserttLichSuKho_Server(int IDKho, int IDHangHoa, int IDNhanVien, int SoLuong, int SoLuongMoi, string NoiDung, DateTime NgayCapNhat, string TrangThai)
        {
            using (SqlConnection myConnection = new SqlConnection(StaticContext.ConnectionServer))
            {
                try
                {
                    myConnection.Open();
                    string cmdText = "INSERT INTO [GPM_LichSuKho] ([IDKho],[IDHangHoa], [IDNhanVien], [SoLuong], [SoLuongMoi],[NoiDung],[NgayCapNhat],[TrangThai]) VALUES (@IDKho,@IDHangHoa,@IDNhanVien,@SoLuong,@SoLuongMoi,@NoiDung,@NgayCapNhat,@TrangThai)";
                    using (SqlCommand myCommand = new SqlCommand(cmdText, myConnection))
                    {
                        myCommand.Parameters.AddWithValue("@IDKho", IDKho);
                        myCommand.Parameters.AddWithValue("@IDHangHoa", IDHangHoa);
                        myCommand.Parameters.AddWithValue("@IDNhanVien", IDNhanVien);
                        myCommand.Parameters.AddWithValue("@SoLuong", SoLuong);
                        myCommand.Parameters.AddWithValue("@SoLuongMoi", SoLuongMoi);
                        myCommand.Parameters.AddWithValue("@NoiDung", NoiDung);
                        myCommand.Parameters.AddWithValue("@NgayCapNhat", NgayCapNhat);
                        myCommand.Parameters.AddWithValue("@TrangThai", TrangThai);
                        myCommand.ExecuteNonQuery();
                    }
                    myConnection.Close();
                }
                catch
                {
                    //throw new Exception("Lỗi: Quá trình thêm dữ liệu gặp lỗi");
                }
            }
        }
        public static void insertLichSuKho()
        {
            DataTable data = getData_LichSuKho();
            if (data.Rows.Count != 0)
            {
                for (int i = 0; i < data.Rows.Count; i++)
                {
                    DataRow dr = data.Rows[i];
                    int IDKho = dtSetting.LayIDKho();
                    int ID = Int32.Parse(dr["ID"].ToString());
                    int IDHangHoa = Int32.Parse(dr["IDHangHoa"].ToString());
                    int IDNhanVien = Int32.Parse(dr["IDNhanVien"].ToString());
                    int SoLuong = Int32.Parse(dr["SoLuong"].ToString());
                    int SoLuongMoi = Int32.Parse(dr["SoLuongMoi"].ToString());
                    DateTime NgayCapNhat = DateTime.Parse(dr["NgayCapNhat"].ToString());
                    string NoiDung = dr["NoiDung"].ToString();
                    string TrangThai = dr["TrangThai"].ToString();

                    inserttLichSuKho_Server(IDKho, IDHangHoa, IDNhanVien, SoLuong, SoLuongMoi, NoiDung, NgayCapNhat, TrangThai);
                    updateData_LichSuKho(ID);
                }
            }
        }
        // -----------------
        // khách hàng
        public static DataTable getData_KhachHang()
        {
            using (SqlConnection con = new SqlConnection(StaticContext.ConnectionString))
            {
                try
                {
                    con.Open();
                    string cmdText = "SELECT * FROM [GPM_KhachHang] WHERE InsertServer = 0";
                    using (SqlCommand command = new SqlCommand(cmdText, con))
                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        DataTable tb = new DataTable();
                        tb.Load(reader);
                        return tb;
                    }
                }
                catch (Exception)
                {
                    return new DataTable();
                }
            }
        }
        public static void updateData_KhachHang(int ID, int IDServer)
        {
            using (SqlConnection con = new SqlConnection(StaticContext.ConnectionString))
            {
                try
                {
                    con.Open();
                    string cmdText = "UPDATE [GPM_KhachHang] SET [InsertServer] = 1, [IDServer] = '" + IDServer + "' WHERE ID = " + ID;
                    using (SqlCommand myCommand = new SqlCommand(cmdText, con))
                    {
                        myCommand.ExecuteNonQuery();
                    }
                }
                catch (Exception)
                {
                }
            }
        }
        public static object insert_KhachHang_Server(object IDKho, int IDNhomKhachHang, string MaKhachHang, string TenKhachHang, DateTime NgaySinh, string CMND, string DiaChi, int IDThanhPho, int IDQuan, string DienThoai, string Email, string Barcode, string GhiChu)
        {
            using (SqlConnection myConnection = new SqlConnection(StaticContext.ConnectionServer))
            {
                try
                {
                    object ID = null;
                    myConnection.Open();
                    string cmdText = "INSERT INTO [GPM_KHACHHANG] ([IDKho],[IDNhomKhachHang],[MaKhachHang], [TenKhachHang], [NgaySinh], [CMND], [DiaChi], [IDThanhPho], [IDQuan], [DienThoai], [Email], [Barcode], [GhiChu], [NgayCapNhat])  OUTPUT INSERTED.ID VALUES (@IDKho,@IDNhomKhachHang,@MaKhachHang, @TenKhachHang, @NgaySinh, @CMND, @DiaChi, @IDThanhPho, @IDQuan, @DienThoai, @Email, @Barcode, @GhiChu, getDATE())";
                    using (SqlCommand myCommand = new SqlCommand(cmdText, myConnection))
                    {
                        myCommand.Parameters.AddWithValue("@IDKho", IDKho);
                        myCommand.Parameters.AddWithValue("@IDNhomKhachHang", IDNhomKhachHang);
                        myCommand.Parameters.AddWithValue("@TenKhachHang", TenKhachHang);
                        myCommand.Parameters.AddWithValue("@NgaySinh", NgaySinh);
                        myCommand.Parameters.AddWithValue("@CMND", CMND);
                        myCommand.Parameters.AddWithValue("@DiaChi", DiaChi);
                        myCommand.Parameters.AddWithValue("@IDThanhPho", IDThanhPho);
                        myCommand.Parameters.AddWithValue("@IDQuan", IDQuan);
                        myCommand.Parameters.AddWithValue("@DienThoai", DienThoai);
                        myCommand.Parameters.AddWithValue("@Email", Email);
                        myCommand.Parameters.AddWithValue("@Barcode", Barcode);
                        myCommand.Parameters.AddWithValue("@GhiChu", GhiChu);
                        myCommand.Parameters.AddWithValue("@MaKhachHang", MaKhachHang);
                        // myCommand.ExecuteNonQuery();
                        ID = myCommand.ExecuteScalar();
                    }
                    myConnection.Close();
                    return ID;
                }
                catch
                {
                    return null;
                    //throw new Exception("Lỗi: Quá trình thêm dữ liệu gặp lỗi");
                }
            }
        }
        public static void insert_KhachHang()
        {
            DataTable data = getData_KhachHang();
            if (data.Rows.Count != 0)
            {
                for (int i = 0; i < data.Rows.Count; i++)
                {
                    DataRow dr = data.Rows[i];
                    int IDKho = dtSetting.LayIDKho();
                    int ID = Int32.Parse(dr["ID"].ToString());
                    int IDNhomKhachHang = Int32.Parse(dr["IDNhomKhachHang"].ToString());
                    string TenKhachHang = dr["TenKhachHang"] == null ? "" : dr["TenKhachHang"].ToString();
                    DateTime NgaySinh = DateTime.Parse(dr["NgaySinh"] == null ? "" : dr["NgaySinh"].ToString());
                    string CMND = dr["CMND"] == null ? "" : dr["CMND"].ToString();
                    string DiaChi = dr["DiaChi"] == null ? "" : dr["DiaChi"].ToString();
                    int IDThanhPho = Int32.Parse(dr["IDThanhPho"].ToString());
                    int IDQuan = Int32.Parse(dr["IDQuan"].ToString());
                    string DienThoai = dr["DienThoai"] == null ? "" : dr["DienThoai"].ToString();

                    string Email = dr["Email"] == null ? "" : dr["Email"].ToString();
                    string MaKh = "";
                    string Barcode = "";
                    string GhiChu = dr["GhiChu"] == null ? "" : dr["GhiChu"].ToString();

                    object IDServer = insert_KhachHang_Server(IDKho,IDNhomKhachHang, MaKh, TenKhachHang, NgaySinh, CMND, DiaChi, IDThanhPho, IDQuan, DienThoai, Email, Barcode, GhiChu);
                    updateData_KhachHang(ID, (int)IDServer);
                }
            }
        }
        // -----------------
        // Phiếu chuyển kho
        public static DataTable getData_PhieuChuyenKho()
        {
            using (SqlConnection con = new SqlConnection(StaticContext.ConnectionString))
            {
                try
                {
                    con.Open();
                    string cmdText = "SELECT * FROM [GPM_PhieuChuyenKho] WHERE InsertServer = 0 AND IDKhoNhap = " + dtSetting.LayIDKho();
                    using (SqlCommand command = new SqlCommand(cmdText, con))
                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        DataTable tb = new DataTable();
                        tb.Load(reader);
                        return tb;
                    }
                }
                catch (Exception)
                {
                    return new DataTable();
                }
            }
        }
        public static void updateData_PhieuChuyenKho(int ID, int IDServer)
        {
            using (SqlConnection con = new SqlConnection(StaticContext.ConnectionString))
            {
                try
                {
                    con.Open();
                    string cmdText = "UPDATE [GPM_PhieuChuyenKho] SET [InsertServer] = 1, [IDServer] = '" + IDServer + "' WHERE ID = " + ID;
                    using (SqlCommand myCommand = new SqlCommand(cmdText, con))
                    {
                        myCommand.ExecuteNonQuery();
                    }
                }
                catch (Exception)
                {
                }
            }
        }
        public static object insert_PhieuChuyenKho_Server(int IDKhoXuat, int IDKhoNhap, DateTime NgayLap, string GhiChu, int DaXoa)
        {
            using (SqlConnection myConnection = new SqlConnection(StaticContext.ConnectionServer))
            {
                try
                {
                    myConnection.Open();
                    object ID = null;
                    string cmdText = "INSERT INTO [GPM_PhieuChuyenKho] ([IDKhoXuat], [IDKhoNhap],[NgayLap],[GhiChu],[DaXoa]) OUTPUT INSERTED.ID VALUES (@IDKhoXuat,@IDKhoNhap,@NgayLap, @GhiChu,@DaXoa)";
                    using (SqlCommand myCommand = new SqlCommand(cmdText, myConnection))
                    {
                        myCommand.Parameters.AddWithValue("@IDKhoXuat", IDKhoXuat);
                        myCommand.Parameters.AddWithValue("@IDKhoNhap", IDKhoNhap);
                        myCommand.Parameters.AddWithValue("@NgayLap", NgayLap);
                        myCommand.Parameters.AddWithValue("@GhiChu", GhiChu);
                        myCommand.Parameters.AddWithValue("@DaXoa", DaXoa);
                        ID = myCommand.ExecuteScalar();
                    }
                    myConnection.Close();
                    return ID;
                }
                catch
                {
                    return (object)-1;
                    //throw new Exception("Lỗi: Quá trình thêm dữ liệu gặp lỗi");
                }
            }
        }
        public static DataTable getData_ChiTietPhieuChuyenKho(int ID)
        {
            using (SqlConnection con = new SqlConnection(StaticContext.ConnectionString))
            {
                try
                {
                    con.Open();
                    string cmdText = " SELECT * FROM [GPM_ChiTietPhieuChuyenKho] WHERE InsertServer = 0 AND IDPhieuChuyenKho = " + ID;
                    using (SqlCommand command = new SqlCommand(cmdText, con))
                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        DataTable tb = new DataTable();
                        tb.Load(reader);
                        return tb;
                    }
                }
                catch (Exception) { return new DataTable(); }
            }
        }
        public static DataTable updateData_ChiTietPhieuChuyenKho(int ID)
        {
            using (SqlConnection con = new SqlConnection(StaticContext.ConnectionString))
            {
                try
                {
                    con.Open();
                    string cmdText = " UPDATE [GPM_ChiTietPhieuChuyenKho] SET InsertServer = 1 WHERE ID = " + ID;
                    using (SqlCommand command = new SqlCommand(cmdText, con))
                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        DataTable tb = new DataTable();
                        tb.Load(reader);
                        return tb;
                    }
                }
                catch (Exception) { return new DataTable(); }
            }
        }
        public static void insert_ChiTietPhieuChuyenKho_Server(object IDPhieuChuyenKho, int IDHangHoa, int IDDonViTinh, int SoLuong, float DonGia, float ThanhTien, int DaXoa)
        {
            using (SqlConnection myConnection = new SqlConnection(StaticContext.ConnectionServer))
            {
                try
                {
                    myConnection.Open();
                    string cmdText = "INSERT INTO [GPM_ChiTietPhieuChuyenKho] ([IDPhieuChuyenKho], [IDHangHoa], [IDDonViTinh], [SoLuong], [DonGia],[ThanhTien],[DaXoa]) VALUES (@IDPhieuChuyenKho, @IDHangHoa,@IDDonViTinh, @SoLuong, @DonGia,@ThanhTien,@DaXoa)";
                    using (SqlCommand myCommand = new SqlCommand(cmdText, myConnection))
                    {
                        myCommand.Parameters.AddWithValue("@IDPhieuChuyenKho", IDPhieuChuyenKho);
                        myCommand.Parameters.AddWithValue("@IDHangHoa", IDHangHoa);
                        myCommand.Parameters.AddWithValue("@IDDonViTinh", IDDonViTinh);
                        myCommand.Parameters.AddWithValue("@SoLuong", SoLuong);
                        myCommand.Parameters.AddWithValue("@DonGia", DonGia);
                        myCommand.Parameters.AddWithValue("@ThanhTien", ThanhTien);
                        myCommand.Parameters.AddWithValue("@DaXoa", DaXoa);
                        myCommand.ExecuteNonQuery();
                    }
                    myConnection.Close();
                }
                catch
                {
                    //throw new Exception("Lỗi: Quá trình thêm dữ liệu gặp lỗi");
                }
            }
        }
        public static void insert_PhieuChuyenKho()
        {
            DataTable data = getData_PhieuChuyenKho();
            if (data.Rows.Count != 0)
            {
                for (int i = 0; i < data.Rows.Count; i++)
                {
                    DataRow dr = data.Rows[i];
                    int IDKhoXuat = Int32.Parse(dr["IDKhoXuat"].ToString());
                    int ID = Int32.Parse(dr["ID"].ToString());
                    int IDKhoNhap = Int32.Parse(dr["IDKhoNhap"].ToString());
                    DateTime NgayLap = DateTime.Parse(dr["NgayLap"].ToString());
                    string GhiChu = dr["GhiChu"].ToString();
                    int DaXoa = Int32.Parse(dr["DaXoa"].ToString());
                    object IDServer = insert_PhieuChuyenKho_Server(IDKhoXuat, IDKhoNhap, NgayLap, GhiChu, DaXoa);
                    if ((int)IDServer != -1)
                    {
                        updateData_PhieuChuyenKho(ID, (int)IDServer);
                        DataTable data1 = getData_ChiTietPhieuChuyenKho(ID);
                        if (data1.Rows.Count != 0)
                        {
                            for (int j = 0; j < data1.Rows.Count; j++)
                            {
                                DataRow dr1 = data1.Rows[j];

                                ID = Int32.Parse(dr1["ID"].ToString());
                                int IDHangHoa = Int32.Parse(dr1["IDHangHoa"].ToString());
                                int IDDonViTinh = Int32.Parse(dr1["IDDonViTinh"].ToString());
                                int SoLuong = int.Parse(dr1["SoLuong"].ToString());
                                float DonGia = float.Parse(dr1["DonGia"].ToString());
                                float ThanhTien = float.Parse(dr1["ThanhTien"].ToString());
                                DaXoa = Int32.Parse(dr1["DaXoa"].ToString());

                                insert_ChiTietPhieuChuyenKho_Server(IDServer, IDHangHoa, IDDonViTinh, SoLuong, DonGia, ThanhTien, DaXoa);
                                updateData_ChiTietPhieuChuyenKho(ID);
                            }
                        }
                    }
                }
            }
        }
        // -----------------
        // Hóa đơn
        public static DataTable getData_HoaDon()
        {
            using (SqlConnection con = new SqlConnection(StaticContext.ConnectionString))
            {
                try
                {
                    con.Open();
                    string cmdText = "SELECT * FROM [GPM_HoaDon] WHERE InsertServer = 0";
                    using (SqlCommand command = new SqlCommand(cmdText, con))
                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        DataTable tb = new DataTable();
                        tb.Load(reader);
                        return tb;
                    }
                }
                catch (Exception)
                {
                    return new DataTable();
                }
            }
        }
        public static DataTable getData_HoaDon_ID(int ID)
        {
            using (SqlConnection con = new SqlConnection(StaticContext.ConnectionString))
            {
                try
                {
                    con.Open();
                    string cmdText = "SELECT * FROM [GPM_HoaDon] WHERE ID = " + ID;
                    using (SqlCommand command = new SqlCommand(cmdText, con))
                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        DataTable tb = new DataTable();
                        tb.Load(reader);
                        return tb;
                    }
                }
                catch (Exception)
                {
                    return new DataTable();
                }
            }
        }
        public static void updateData_HoaDon(int ID, int IDServer)
        {
            using (SqlConnection con = new SqlConnection(StaticContext.ConnectionString))
            {
                try
                {
                    con.Open();
                    string cmdText = "UPDATE [GPM_HoaDon] SET [InsertServer] = 1, [IDServer] = '" + IDServer + "' WHERE ID = " + ID;
                    using (SqlCommand myCommand = new SqlCommand(cmdText, con))
                    {
                        myCommand.ExecuteNonQuery();
                    }
                }
                catch (Exception)
                {
                }
            }
        }
        public static object insert_HoaDon_Server(int IDKho, int IDKhachHang, int IDNhanVien, DateTime NgayBan, int SoLuongHang, float TongTien, float GiamGia, float KhachCanTra, float KhachThanhToan, int DaXoa)
        {
            using (SqlConnection myConnection = new SqlConnection(StaticContext.ConnectionServer))
            {
                try
                {
                    myConnection.Open();
                    object ID = null;
                    string cmdText = "INSERT INTO [GPM_HoaDon] ([IDKho], [IDKhachHang],[IDNhanVien],[NgayBan],[SoLuongHang], [TongTien], [GiamGia],[KhachCanTra],[KhachThanhToan],[DaXoa])  OUTPUT INSERTED.ID VALUES (@IDKho, @IDKhachHang,@IDNhanVien,@NgayBan,@SoLuongHang, @TongTien, @GiamGia,@KhachCanTra,@KhachThanhToan,@DaXoa)";
                    using (SqlCommand myCommand = new SqlCommand(cmdText, myConnection))
                    {
                        myCommand.Parameters.AddWithValue("@IDKho", IDKho);
                        myCommand.Parameters.AddWithValue("@IDKhachHang", IDKhachHang);
                        myCommand.Parameters.AddWithValue("@IDNhanVien", IDNhanVien);
                        myCommand.Parameters.AddWithValue("@NgayBan", NgayBan);
                        myCommand.Parameters.AddWithValue("@SoLuongHang", SoLuongHang);
                        myCommand.Parameters.AddWithValue("@TongTien", TongTien);
                        myCommand.Parameters.AddWithValue("@GiamGia", GiamGia);
                        myCommand.Parameters.AddWithValue("@KhachCanTra", KhachCanTra);
                        myCommand.Parameters.AddWithValue("@KhachThanhToan", KhachThanhToan);
                        myCommand.Parameters.AddWithValue("@DaXoa", DaXoa);
                        ID = myCommand.ExecuteScalar();
                    }
                    myConnection.Close();
                    return ID;
                }
                catch
                {
                    return (object)-1;
                    //throw new Exception("Lỗi: Quá trình thêm dữ liệu gặp lỗi");
                }
            }
        }
        public static void insert_HoaDon()
        {
            DataTable data = getData_HoaDon();
            if (data.Rows.Count != 0)
            {
                for (int i = 0; i < data.Rows.Count; i++)
                {
                    DataRow dr = data.Rows[i];
                    int IDKho = dtSetting.LayIDKho();
                    int ID = Int32.Parse(dr["ID"].ToString());
                    int IDKhachHang = Int32.Parse(dr["IDKhachHang"].ToString());
                    int IDNhanVien = Int32.Parse(dr["IDNhanVien"].ToString());
                    DateTime NgayBan = DateTime.Parse(dr["NgayBan"].ToString());
                    int SoLuongHang = Int32.Parse(dr["SoLuongHang"].ToString());
                    int TongTien = Int32.Parse(dr["TongTien"].ToString());
                    int GiamGia = Int32.Parse(dr["GiamGia"].ToString());
                    int KhachCanTra = Int32.Parse(dr["KhachCanTra"].ToString());
                    int KhachThanhToan = Int32.Parse(dr["KhachThanhToan"].ToString());
                    int DaXoa = Int32.Parse(dr["DaXoa"].ToString());
                    object IDServer = insert_HoaDon_Server(IDKho, IDKhachHang, IDNhanVien, NgayBan, SoLuongHang, TongTien, GiamGia, KhachCanTra, KhachThanhToan, DaXoa);
                    if ((int)IDServer != -1)
                        updateData_HoaDon(ID, (int)IDServer);
                }
            }
        }
        // -----------------
        // Chi tiết hóa đơn
        public static DataTable getData_ChiTietHoaDon()
        {
            using (SqlConnection con = new SqlConnection(StaticContext.ConnectionString))
            {
                try
                {
                    con.Open();
                    string cmdText = " SELECT * FROM [GPM_ChiTietHoaDon] WHERE InsertServer = 0";
                    using (SqlCommand command = new SqlCommand(cmdText, con))
                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        DataTable tb = new DataTable();
                        tb.Load(reader);
                        return tb;
                    }
                }
                catch (Exception) { return new DataTable(); }
            }
        }
        public static DataTable updateData_ChiTietHoaDono(int ID)
        {
            using (SqlConnection con = new SqlConnection(StaticContext.ConnectionString))
            {
                try
                {
                    con.Open();
                    string cmdText = " UPDATE [GPM_ChiTietHoaDon] SET InsertServer = 1 WHERE ID = " + ID;
                    using (SqlCommand command = new SqlCommand(cmdText, con))
                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        DataTable tb = new DataTable();
                        tb.Load(reader);
                        return tb;
                    }
                }
                catch (Exception) { return new DataTable(); }
            }
        }
        public static void insert_ChiTietHoaDon_Server(object IDHoaDon, int IDHangHoa, float GiaMua, float GiaBan, int SoLuong, string ChietKhau, float ThanhTien, int DaXoa)
        {
            using (SqlConnection myConnection = new SqlConnection(StaticContext.ConnectionServer))
            {
                try
                {
                    myConnection.Open();
                    string cmdText = "INSERT INTO [GPM_ChiTietHoaDon] ([IDHoaDon], [IDHangHoa], [GiaMua], [GiaBan], [SoLuong],[ChietKhau],[ThanhTien],[DaXoa]) VALUES (@IDHoaDon,@IDHangHoa,@GiaMua,@GiaBan,@SoLuong,@ChietKhau,@ThanhTien,@DaXoa)";
                    using (SqlCommand myCommand = new SqlCommand(cmdText, myConnection))
                    {
                        myCommand.Parameters.AddWithValue("@IDHoaDon", IDHoaDon);
                        myCommand.Parameters.AddWithValue("@IDHangHoa", IDHangHoa);
                        myCommand.Parameters.AddWithValue("@GiaMua", GiaMua);
                        myCommand.Parameters.AddWithValue("@GiaBan", GiaBan);
                        myCommand.Parameters.AddWithValue("@SoLuong", SoLuong);
                        myCommand.Parameters.AddWithValue("@ChietKhau", ChietKhau);
                        myCommand.Parameters.AddWithValue("@ThanhTien", ThanhTien);
                        myCommand.Parameters.AddWithValue("@DaXoa", DaXoa);
                        myCommand.ExecuteNonQuery();
                    }
                    myConnection.Close();
                }
                catch
                {
                    //throw new Exception("Lỗi: Quá trình thêm dữ liệu gặp lỗi");
                }
            }
        }
        public static void insert_ChiTietHoaDon()
        {
            DataTable data = getData_ChiTietHoaDon();
            if (data.Rows.Count != 0)
            {
                for (int i = 0; i < data.Rows.Count; i++)
                {
                    DataRow dr = data.Rows[i];
                    int IDHoaDon = Int32.Parse(dr["IDHoaDon"].ToString());
                    DataTable da = getData_HoaDon_ID(IDHoaDon);
                    if (da.Rows.Count != 0)
                    {
                        DataRow dr1 = da.Rows[0];
                        int IDServer = Int32.Parse(dr1["IDServer"].ToString());

                        int ID = Int32.Parse(dr["ID"].ToString());
                        int IDHangHoa = Int32.Parse(dr["IDHangHoa"].ToString());
                        float GiaMua = float.Parse(dr["GiaMua"].ToString());
                        float GiaBan = float.Parse(dr["GiaBan"].ToString());
                        int SoLuong = int.Parse(dr["SoLuong"].ToString());
                        string ChietKhau = dr["ChietKhau"].ToString();
                        float ThanhTien = float.Parse(dr["ThanhTien"].ToString());
                        int DaXoa = Int32.Parse(dr["DaXoa"].ToString());

                        insert_ChiTietHoaDon_Server(IDServer, IDHangHoa, GiaMua, GiaBan, SoLuong, ChietKhau, ThanhTien, DaXoa);
                        updateData_ChiTietHoaDono(ID); // Update Client....
                    }
                }
            }
        }
        // -----------------
        // Đơn đặt hàng
        public static DataTable getData_DonDatHang()
        {
            using (SqlConnection con = new SqlConnection(StaticContext.ConnectionString))
            {
                try
                {
                    con.Open();
                    string cmdText = "SELECT * FROM [GPM_DonDatHang] WHERE InsertServer = 0";
                    using (SqlCommand command = new SqlCommand(cmdText, con))
                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        DataTable tb = new DataTable();
                        tb.Load(reader);
                        return tb;
                    }
                }
                catch (Exception)
                {
                    return new DataTable();
                }
            }
        }
        public static DataTable getData_DonDatHang_ID(int ID)
        {
            using (SqlConnection con = new SqlConnection(StaticContext.ConnectionString))
            {
                try
                {
                    con.Open();
                    string cmdText = "SELECT * FROM [GPM_DonDatHang] WHERE ID = " + ID;
                    using (SqlCommand command = new SqlCommand(cmdText, con))
                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        DataTable tb = new DataTable();
                        tb.Load(reader);
                        return tb;
                    }
                }
                catch (Exception)
                {
                    return new DataTable();
                }
            }
        }
        public static void updateData_DonDatHang(int ID, int IDServer)
        {
            using (SqlConnection con = new SqlConnection(StaticContext.ConnectionString))
            {
                try
                {
                    con.Open();
                    string cmdText = "UPDATE [GPM_DonDatHang] SET [InsertServer] = 1, [IDServer] = '" + IDServer + "' WHERE ID = " + ID;
                    using (SqlCommand myCommand = new SqlCommand(cmdText, con))
                    {
                        myCommand.ExecuteNonQuery();
                    }
                }
                catch (Exception)
                {
                }
            }
        }
        public static object insert_DonDatHang_Server(int IDKho, int IDNguoiDung, DateTime NgayLap, float TongTien, string GhiChu, int DaXoa)
        {
            using (SqlConnection myConnection = new SqlConnection(StaticContext.ConnectionServer))
            {
                try
                {
                    myConnection.Open();
                    object ID = null;
                    string cmdText = "INSERT INTO [GPM_DonDatHang] ([IDKho], [IDNguoiDung],[NgayLap],[TongTien],[GhiChu],[DaXoa])  OUTPUT INSERTED.ID VALUES (@IDKho, @IDNguoiDung,@NgayLap,@TongTien,@GhiChu, @DaXoa)";
                    using (SqlCommand myCommand = new SqlCommand(cmdText, myConnection))
                    {
                        myCommand.Parameters.AddWithValue("@IDKho", IDKho);
                        myCommand.Parameters.AddWithValue("@IDNguoiDung", IDNguoiDung);
                        myCommand.Parameters.AddWithValue("@NgayLap", NgayLap);
                        myCommand.Parameters.AddWithValue("@TongTien", TongTien);
                        myCommand.Parameters.AddWithValue("@GhiChu", GhiChu);
                        myCommand.Parameters.AddWithValue("@DaXoa", DaXoa);
                        ID = myCommand.ExecuteScalar();
                    }
                    myConnection.Close();
                    return ID;
                }
                catch
                {
                    return (object)-1;
                    //throw new Exception("Lỗi: Quá trình thêm dữ liệu gặp lỗi");
                }
            }
        }
        public static void insert_DonDatHang()
        {
            DataTable data = getData_DonDatHang();
            if (data.Rows.Count != 0)
            {
                for (int i = 0; i < data.Rows.Count; i++)
                {
                    DataRow dr = data.Rows[i];
                    int IDKho = dtSetting.LayIDKho();
                    int ID = Int32.Parse(dr["ID"].ToString());
                    int IDNguoiDung = Int32.Parse(dr["IDNguoiDung"].ToString());
                    DateTime NgayLap = DateTime.Parse(dr["NgayLap"].ToString());
                    float TongTien = Int32.Parse(dr["TongTien"].ToString());
                    string GhiChu = dr["GhiChu"].ToString();
                    int DaXoa = Int32.Parse(dr["DaXoa"].ToString());
                    object IDServer = insert_DonDatHang_Server(IDKho, IDNguoiDung, NgayLap, TongTien, GhiChu, DaXoa);
                    if ((int)IDServer != -1)
                        updateData_DonDatHang(ID, (int)IDServer);
                }
            }
        }
        // -----------------
        // Chi tiết đơn đặt hàng
        public static DataTable getData_ChiTietDonDatHang()
        {
            using (SqlConnection con = new SqlConnection(StaticContext.ConnectionString))
            {
                try
                {
                    con.Open();
                    string cmdText = " SELECT * FROM [GPM_ChiTietDonHang] WHERE InsertServer = 0";
                    using (SqlCommand command = new SqlCommand(cmdText, con))
                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        DataTable tb = new DataTable();
                        tb.Load(reader);
                        return tb;
                    }
                }
                catch (Exception) { return new DataTable(); }
            }
        }
        public static DataTable updateData_ChiTietDonDatHang(int ID)
        {
            using (SqlConnection con = new SqlConnection(StaticContext.ConnectionString))
            {
                try
                {
                    con.Open();
                    string cmdText = " UPDATE [GPM_ChiTietDonHang] SET InsertServer = 1 WHERE ID = " + ID;
                    using (SqlCommand command = new SqlCommand(cmdText, con))
                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        DataTable tb = new DataTable();
                        tb.Load(reader);
                        return tb;
                    }
                }
                catch (Exception) { return new DataTable(); }
            }
        }
        public static void insert_ChiTietDonDatHang_Server(object IDDonDatHang, string MaHang, int IDHangHoa, int SoLuong, float DonGia, float ThanhTien, int DaXoa)
        {
            using (SqlConnection myConnection = new SqlConnection(StaticContext.ConnectionServer))
            {
                try
                {
                    myConnection.Open();
                    string cmdText = "INSERT INTO [GPM_ChiTietDonHang] ([IDDonDatHang], [MaHang], [IDHangHoa], [SoLuong], [DonGia],[ThanhTien],[DaXoa]) VALUES (@IDDonDatHang, @MaHang, @IDHangHoa, @SoLuong, @DonGia,@ThanhTien,@DaXoa)";
                    using (SqlCommand myCommand = new SqlCommand(cmdText, myConnection))
                    {
                        myCommand.Parameters.AddWithValue("@IDDonDatHang", IDDonDatHang);
                        myCommand.Parameters.AddWithValue("@MaHang", MaHang);
                        myCommand.Parameters.AddWithValue("@IDHangHoa", IDHangHoa);
                        myCommand.Parameters.AddWithValue("@SoLuong", SoLuong);
                        myCommand.Parameters.AddWithValue("@DonGia", DonGia);
                        myCommand.Parameters.AddWithValue("@ThanhTien", ThanhTien);
                        myCommand.Parameters.AddWithValue("@DaXoa", DaXoa);
                        myCommand.ExecuteNonQuery();
                    }
                    myConnection.Close();
                }
                catch
                {
                    //throw new Exception("Lỗi: Quá trình thêm dữ liệu gặp lỗi");
                }
            }
        }
        public static void insert_ChiTietDonDatHang()
        {
            DataTable data = getData_ChiTietDonDatHang();
            if (data.Rows.Count != 0)
            {
                for (int i = 0; i < data.Rows.Count; i++)
                {
                    DataRow dr = data.Rows[i];
                    int IDDonDatHang = Int32.Parse(dr["IDDonDatHang"].ToString());
                    DataTable da = getData_DonDatHang_ID(IDDonDatHang);
                    if (da.Rows.Count != 0)
                    {
                        DataRow dr1 = da.Rows[0];
                        int IDServer = Int32.Parse(dr1["IDServer"].ToString());

                        int ID = Int32.Parse(dr["ID"].ToString());
                        string MaHang = dr["MaHang"].ToString();
                        int IDHangHoa = Int32.Parse(dr["IDHangHoa"].ToString());
                        int SoLuong = int.Parse(dr["SoLuong"].ToString());
                        float DonGia = float.Parse(dr["DonGia"].ToString());
                        float ThanhTien = float.Parse(dr["ThanhTien"].ToString());
                        int DaXoa = Int32.Parse(dr["DaXoa"].ToString());

                        insert_ChiTietDonDatHang_Server(IDServer, MaHang, IDHangHoa, SoLuong, DonGia, ThanhTien, DaXoa);
                        updateData_ChiTietDonDatHang(ID); // Update Client....
                    }
                }
            }
        }
        // -----------------
        // Phiếu đổi hàng
        public static DataTable getData_PhieuDoiHang()
        {
            using (SqlConnection con = new SqlConnection(StaticContext.ConnectionString))
            {
                try
                {
                    con.Open();
                    string cmdText = "SELECT * FROM [GPM_PhieuDoiHang] WHERE InsertServer = 0";
                    using (SqlCommand command = new SqlCommand(cmdText, con))
                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        DataTable tb = new DataTable();
                        tb.Load(reader);
                        return tb;
                    }
                }
                catch (Exception)
                {
                    return new DataTable();
                }
            }
        }
        public static DataTable getData_PhieuDoiHang_ID(int ID)
        {
            using (SqlConnection con = new SqlConnection(StaticContext.ConnectionString))
            {
                try
                {
                    con.Open();
                    string cmdText = "SELECT * FROM [GPM_PhieuDoiHang] WHERE ID = " + ID;
                    using (SqlCommand command = new SqlCommand(cmdText, con))
                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        DataTable tb = new DataTable();
                        tb.Load(reader);
                        return tb;
                    }
                }
                catch (Exception)
                {
                    return new DataTable();
                }
            }
        }
        public static void updateData_PhieuDoiHang(int ID, int IDServer)
        {
            using (SqlConnection con = new SqlConnection(StaticContext.ConnectionString))
            {
                try
                {
                    con.Open();
                    string cmdText = "UPDATE [GPM_PhieuDoiHang] SET [InsertServer] = 1, [IDServer] = '" + IDServer + "' WHERE ID = " + ID;
                    using (SqlCommand myCommand = new SqlCommand(cmdText, con))
                    {
                        myCommand.ExecuteNonQuery();
                    }
                }
                catch (Exception)
                {
                }
            }
        }
        public static object insert_PhieuDoiHang_Server(int IDKho, int IDHoaDon, int IDNhanVienThuNgan, int IDKhachHang, DateTime NgayDoi, string LyDoDoi, float SoTienTra, int DaXoa)
        {
            using (SqlConnection myConnection = new SqlConnection(StaticContext.ConnectionServer))
            {
                try
                {
                    myConnection.Open();
                    object ID = null;
                    string cmdText = "INSERT INTO [GPM_PhieuDoiHang] ([IDKho], [IDHoaDon],[IDNhanVienThuNgan],[IDKhachHang],[NgayDoi],[LyDoDoi],[SoTienTra],[DaXoa])  OUTPUT INSERTED.ID VALUES (@IDKho, @IDHoaDon,@IDNhanVienThuNgan,@IDKhachHang,@NgayDoi,@LyDoDoi,@SoTienTra,@DaXoa)";
                    using (SqlCommand myCommand = new SqlCommand(cmdText, myConnection))
                    {
                        myCommand.Parameters.AddWithValue("@IDKho", IDKho);
                        myCommand.Parameters.AddWithValue("@IDHoaDon", IDHoaDon);
                        myCommand.Parameters.AddWithValue("@IDNhanVienThuNgan", IDNhanVienThuNgan);
                        myCommand.Parameters.AddWithValue("@IDKhachHang", IDKhachHang);
                        myCommand.Parameters.AddWithValue("@NgayDoi", NgayDoi);
                        myCommand.Parameters.AddWithValue("@LyDoDoi", LyDoDoi);
                        myCommand.Parameters.AddWithValue("@SoTienTra", SoTienTra);
                        myCommand.Parameters.AddWithValue("@DaXoa", DaXoa);
                        ID = myCommand.ExecuteScalar();
                    }
                    myConnection.Close();
                    return ID;
                }
                catch
                {
                    return (object)-1;
                    //throw new Exception("Lỗi: Quá trình thêm dữ liệu gặp lỗi");
                }
            }
        }
        public static void insert_PhieuDoiHang()
        {
            DataTable data = getData_PhieuDoiHang();
            if (data.Rows.Count != 0)
            {
                for (int i = 0; i < data.Rows.Count; i++)
                {
                    DataRow dr = data.Rows[i];
                    int IDKho = dtSetting.LayIDKho();
                    int ID = Int32.Parse(dr["ID"].ToString());
                    int IDHoaDon = Int32.Parse(dr["IDHoaDon"].ToString());
                    int IDNhanVienThuNgan = Int32.Parse(dr["IDNhanVienThuNgan"].ToString());
                    int IDKhachHang = Int32.Parse(dr["IDKhachHang"].ToString());
                    DateTime NgayDoi = DateTime.Parse(dr["NgayDoi"].ToString());
                    float SoTienTra = Int32.Parse(dr["SoTienTra"].ToString());
                    string LyDoDoi = dr["LyDoDoi"].ToString();
                    int DaXoa = Int32.Parse(dr["DaXoa"].ToString());
                    object IDServer = insert_PhieuDoiHang_Server(IDKho, IDHoaDon, IDNhanVienThuNgan, IDKhachHang, NgayDoi,LyDoDoi,SoTienTra, DaXoa);
                    if ((int)IDServer != -1)
                        updateData_PhieuDoiHang(ID, (int)IDServer);
                }
            }
        }
        // -----------------
        // Chi tiết hóa đơn
        public static DataTable getData_ChiTietPhieuDoiHang()
        {
            using (SqlConnection con = new SqlConnection(StaticContext.ConnectionString))
            {
                try
                {
                    con.Open();
                    string cmdText = " SELECT * FROM [GPM_PhieuDoiHang_HangHoaDoi] WHERE InsertServer = 0";
                    using (SqlCommand command = new SqlCommand(cmdText, con))
                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        DataTable tb = new DataTable();
                        tb.Load(reader);
                        return tb;
                    }
                }
                catch (Exception) { return new DataTable(); }
            }
        }
        public static DataTable updateData_ChiTietPhieuDoiHang(int ID)
        {
            using (SqlConnection con = new SqlConnection(StaticContext.ConnectionString))
            {
                try
                {
                    con.Open();
                    string cmdText = " UPDATE [GPM_PhieuDoiHang_HangHoaDoi] SET InsertServer = 1 WHERE ID = " + ID;
                    using (SqlCommand command = new SqlCommand(cmdText, con))
                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        DataTable tb = new DataTable();
                        tb.Load(reader);
                        return tb;
                    }
                }
                catch (Exception) { return new DataTable(); }
            }
        }
        public static void insert_ChiTietPhieuDoiHang_Server(object IDPhieuDoiHang, int IDHangHoa, int IDDonViTinh, float GiaMua, int SoLuong, float ThanhTien, int DaXoa)
        {
            using (SqlConnection myConnection = new SqlConnection(StaticContext.ConnectionServer))
            {
                try
                {
                    myConnection.Open();
                    string cmdText = "INSERT INTO [GPM_PhieuDoiHang_HangHoaDoi] ([IDPhieuDoiHang], [IDHangHoa], [IDDonViTinh], [GiaMua], [SoLuong],[ThanhTien],[DaXoa]) VALUES (@IDPhieuDoiHang, @IDHangHoa, @IDDonViTinh, @GiaMua, @SoLuong,@ThanhTien,@DaXoa)";
                    using (SqlCommand myCommand = new SqlCommand(cmdText, myConnection))
                    {
                        myCommand.Parameters.AddWithValue("@IDPhieuDoiHang", IDPhieuDoiHang);
                        myCommand.Parameters.AddWithValue("@IDHangHoa", IDHangHoa);
                        myCommand.Parameters.AddWithValue("@IDDonViTinh", IDDonViTinh);
                        myCommand.Parameters.AddWithValue("@GiaMua", GiaMua);
                        myCommand.Parameters.AddWithValue("@SoLuong", SoLuong);
                        myCommand.Parameters.AddWithValue("@ThanhTien", ThanhTien);
                        myCommand.Parameters.AddWithValue("@DaXoa", DaXoa);
                        myCommand.ExecuteNonQuery();
                    }
                    myConnection.Close();
                }
                catch
                {
                    //throw new Exception("Lỗi: Quá trình thêm dữ liệu gặp lỗi");
                }
            }
        }
        public static void insert_ChiTietPhieuDoiHang()
        {
            DataTable data = getData_ChiTietPhieuDoiHang();
            if (data.Rows.Count != 0)
            {
                for (int i = 0; i < data.Rows.Count; i++)
                {
                    DataRow dr = data.Rows[i];
                    int IDPhieuDoiHang = Int32.Parse(dr["IDPhieuDoiHang"].ToString());
                    DataTable da = getData_PhieuDoiHang_ID(IDPhieuDoiHang);
                    if (da.Rows.Count != 0)
                    {
                        DataRow dr1 = da.Rows[0];
                        int IDServer = Int32.Parse(dr1["IDServer"].ToString());

                        int ID = Int32.Parse(dr["ID"].ToString());
                        int IDHangHoa = Int32.Parse(dr["IDHangHoa"].ToString());
                        int IDDonViTinh = Int32.Parse(dr["IDDonViTinh"].ToString());
                        float GiaMua = float.Parse(dr["GiaMua"].ToString());
                        int SoLuong = int.Parse(dr["SoLuong"].ToString());
                        float ThanhTien = float.Parse(dr["ThanhTien"].ToString());
                        int DaXoa = Int32.Parse(dr["DaXoa"].ToString());

                        insert_ChiTietPhieuDoiHang_Server(IDServer, IDHangHoa, IDDonViTinh, GiaMua, SoLuong, ThanhTien, DaXoa);
                        updateData_ChiTietPhieuDoiHang(ID); // Update Client....
                    }
                }
            }
        }

        // ======================================================================//
        // ======================================================================//
        // ======================================================================//
        // ======================================================================//

        // Cập nhật về Client
        ///-----
        // ----------------------
        // Lấy thông tin ngành hàng...
        public static DataTable getData_NganhHang_Server()
        {
            using (SqlConnection con = new SqlConnection(StaticContext.ConnectionServer))
            {
                try
                {
                    con.Open();
                    string cmdText = "SELECT * FROM [GPM_NganhHang]";
                    using (SqlCommand command = new SqlCommand(cmdText, con))
                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        DataTable tb = new DataTable();
                        tb.Load(reader);
                        return tb;
                    }
                }
                catch (Exception)
                {
                    return new DataTable();
                }
            }
        }
        public static DataTable getData_NganhHang_Client()
        {
            using (SqlConnection con = new SqlConnection(StaticContext.ConnectionString))
            {
                try
                {
                    con.Open();
                    string cmdText = "SELECT * FROM [GPM_NganhHang]";
                    using (SqlCommand command = new SqlCommand(cmdText, con))
                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        DataTable tb = new DataTable();
                        tb.Load(reader);
                        return tb;
                    }
                }
                catch (Exception)
                {
                    return new DataTable();
                }
            }
        }
        public static void updateNganhHang()
        {
            // Ngành Hàng
            DataTable dataServer = getData_NganhHang_Server();
            DataTable dataClient = getData_NganhHang_Client();
            for (int i = 0; i < dataServer.Rows.Count; i++)
            {
                DataRow drServer = dataServer.Rows[i];
                if (dataClient.Rows.Count > i)
                {
                    DataRow drClient = dataClient.Rows[i];
                    if (drServer["ID"].ToString().CompareTo(drClient["ID"].ToString()) != 0 ||
                        drServer["MaNganh"].ToString().CompareTo(drClient["MaNganh"].ToString()) != 0 ||
                        drServer["TenNganhHang"].ToString().CompareTo(drClient["TenNganhHang"].ToString()) != 0 ||
                        drServer["GhiChu"].ToString().CompareTo(drClient["GhiChu"].ToString()) != 0 ||
                        drServer["DaXoa"].ToString().CompareTo(drClient["DaXoa"].ToString()) != 0)
                    {
                        dataNganhHang da = new dataNganhHang();
                        da.updateNganhHang_Full(Int32.Parse(drServer["ID"].ToString()), drServer["MaNganh"].ToString(), drServer["TenNganhHang"].ToString(), drServer["GhiChu"].ToString(), Int32.Parse(drServer["DaXoa"].ToString()));
                    }
                }
                else
                {
                    dataNganhHang da = new dataNganhHang();
                    da.insertNganhHang_Full(drServer["MaNganh"].ToString(), drServer["TenNganhHang"].ToString(), drServer["GhiChu"].ToString(), Int32.Parse(drServer["DaXoa"].ToString()));
                }
            }
        }
        // ----------------------
        // Lấy thông tin nhóm hàng...
        public static DataTable getData_NhomHang_Server()
        {
            using (SqlConnection con = new SqlConnection(StaticContext.ConnectionServer))
            {
                try
                {
                    con.Open();
                    string cmdText = "SELECT * FROM [GPM_NhomHang]";
                    using (SqlCommand command = new SqlCommand(cmdText, con))
                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        DataTable tb = new DataTable();
                        tb.Load(reader);
                        return tb;
                    }
                }
                catch (Exception)
                {
                    return new DataTable();
                }
            }
        }
        public static DataTable getData_NhomHang_Client()
        {
            using (SqlConnection con = new SqlConnection(StaticContext.ConnectionString))
            {
                try
                {
                    con.Open();
                    string cmdText = "SELECT * FROM [GPM_NhomHang]";
                    using (SqlCommand command = new SqlCommand(cmdText, con))
                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        DataTable tb = new DataTable();
                        tb.Load(reader);
                        return tb;
                    }
                }
                catch (Exception)
                {
                    return new DataTable();
                }
            }
        }
        public static void updateNhomHang()
        {
            // Nhóm Hàng
            DataTable dataServer = getData_NhomHang_Server();
            DataTable dataClient = getData_NhomHang_Client();
            for (int i = 0; i < dataServer.Rows.Count; i++)
            {
                DataRow drServer = dataServer.Rows[i];
                if (dataClient.Rows.Count > i)
                {
                    DataRow drClient = dataClient.Rows[i];
                    if (drServer["ID"].ToString().CompareTo(drClient["ID"].ToString()) != 0 ||
                        drServer["IDNganhHang"].ToString().CompareTo(drClient["IDNganhHang"].ToString()) != 0 ||
                        drServer["TenNhomHang"].ToString().CompareTo(drClient["TenNhomHang"].ToString()) != 0 ||
                        drServer["GhiChu"].ToString().CompareTo(drClient["GhiChu"].ToString()) != 0 ||
                        drServer["DaXoa"].ToString().CompareTo(drClient["DaXoa"].ToString()) != 0)
                    {
                        dataNhomHang da = new dataNhomHang();
                        da.updateNhomHang_Full(Int32.Parse(drServer["ID"].ToString()), Int32.Parse(drServer["IDNganhHang"].ToString()), drServer["MaNhom"].ToString(), drServer["TenNhomHang"].ToString(), drServer["GhiChu"].ToString(), Int32.Parse(drServer["DaXoa"].ToString()));
                    }
                }
                else
                {
                    dataNhomHang da = new dataNhomHang();
                    da.insertNhomHang_Full(Int32.Parse(drServer["IDNganhHang"].ToString()), drServer["MaNhom"].ToString(), drServer["TenNhomHang"].ToString(), drServer["GhiChu"].ToString(), Int32.Parse(drServer["DaXoa"].ToString()));
                }
            }
        }
        // ----------------------
        // Lấy thông tin Hàng hóa...
        public static DataTable getData_HangHoa_Server()
        {
            using (SqlConnection con = new SqlConnection(StaticContext.ConnectionServer))
            {
                try
                {
                    con.Open();
                    string cmdText = "SELECT * FROM [GPM_HangHoa]";
                    using (SqlCommand command = new SqlCommand(cmdText, con))
                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        DataTable tb = new DataTable();
                        tb.Load(reader);
                        return tb;
                    }
                }
                catch (Exception)
                {
                    return new DataTable();
                }
            }
        }
        public static DataTable getData_HangHoa_Client()
        {
            using (SqlConnection con = new SqlConnection(StaticContext.ConnectionString))
            {
                try
                {
                    con.Open();
                    string cmdText = "SELECT * FROM [GPM_HangHoa]";
                    using (SqlCommand command = new SqlCommand(cmdText, con))
                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        DataTable tb = new DataTable();
                        tb.Load(reader);
                        return tb;
                    }
                }
                catch (Exception)
                {
                    return new DataTable();
                }
            }
        }
        public static void updateHangHoa()
        {
            // Hàng hóa
            DataTable dataServer = getData_HangHoa_Server();
            DataTable dataClient = getData_HangHoa_Client();
            for (int i = 0; i < dataServer.Rows.Count; i++)
            {
                DataRow drServer = dataServer.Rows[i];
                if (dataClient.Rows.Count > i)
                {
                    DataRow drClient = dataClient.Rows[i];
                    if (drServer["ID"].ToString().CompareTo(drClient["ID"].ToString()) != 0 ||
                        drServer["IDNhomHang"].ToString().CompareTo(drClient["IDNhomHang"].ToString()) != 0 ||
                        drServer["MaHang"].ToString().CompareTo(drClient["MaHang"].ToString()) != 0 ||
                        drServer["TenHangHoa"].ToString().CompareTo(drClient["TenHangHoa"].ToString()) != 0 ||
                        drServer["IDDonViTinh"].ToString().CompareTo(drClient["IDDonViTinh"].ToString()) != 0 ||
                        drServer["IDNhaSanXuat"].ToString().CompareTo(drClient["IDNhaSanXuat"].ToString()) != 0 ||
                        drServer["GiaMua"].ToString().CompareTo(drClient["GiaMua"].ToString()) != 0 ||
                        drServer["GiaBan1"].ToString().CompareTo(drClient["GiaBan1"].ToString()) != 0 ||
                        drServer["GiaBan2"].ToString().CompareTo(drClient["GiaBan2"].ToString()) != 0 ||
                        drServer["GiaBan3"].ToString().CompareTo(drClient["GiaBan3"].ToString()) != 0 ||
                        drServer["GiaBan4"].ToString().CompareTo(drClient["GiaBan4"].ToString()) != 0 ||
                        drServer["GiaBan5"].ToString().CompareTo(drClient["GiaBan5"].ToString()) != 0 ||
                        drServer["TrangThai"].ToString().CompareTo(drClient["TrangThai"].ToString()) != 0 ||
                        drServer["GhiChu"].ToString().CompareTo(drClient["GhiChu"].ToString()) != 0 ||
                        drServer["DaXoa"].ToString().CompareTo(drClient["DaXoa"].ToString()) != 0)
                    {
                        int ID = Int32.Parse(drServer["ID"].ToString());
                        int IDNhomHang = Int32.Parse(drServer["IDNhomHang"].ToString());
                        string MaHang = drServer["MaHang"].ToString();
                        string TenHangHoa = drServer["TenHangHoa"].ToString();
                        int IDDonViTinh = Int32.Parse(drServer["IDDonViTinh"].ToString());
                        int IDNhaSanXuat = Int32.Parse(drServer["IDNhaSanXuat"].ToString());
                        float GiaMua = float.Parse(drServer["GiaMua"].ToString());
                        float GiaBan1 = float.Parse(drServer["GiaBan1"].ToString());

                        float GiaBan2 = float.Parse(drServer["GiaBan2"].ToString());
                        float GiaBan3 = float.Parse(drServer["GiaBan3"].ToString());
                        float GiaBan4 = float.Parse(drServer["GiaBan4"].ToString());
                        float GiaBan5 = float.Parse(drServer["GiaBan5"].ToString());
                        string GhiChu = drServer["TrangThai"].ToString();
                        int DaXoa = int.Parse(drServer["DaXoa"].ToString());

                        dataHangHoa da = new dataHangHoa();
                        da.SuaThongTinHangHoa_Full(ID, IDNhomHang, MaHang, TenHangHoa, IDDonViTinh, IDNhaSanXuat, GiaMua, GiaBan1, GiaBan2, GiaBan3, GiaBan4, GiaBan5, 0, GhiChu, DaXoa);
                    }
                }
                else
                {
                    int IDNhomHang = Int32.Parse(drServer["IDNhomHang"].ToString());
                    string MaHang = drServer["MaHang"].ToString();
                    string TenHangHoa = drServer["TenHangHoa"].ToString();
                    int IDDonViTinh = Int32.Parse(drServer["IDDonViTinh"].ToString());
                    int IDNhaSanXuat = Int32.Parse(drServer["IDNhaSanXuat"].ToString());
                    float GiaMua = float.Parse(drServer["GiaMua"].ToString());
                    float GiaBan1 = float.Parse(drServer["GiaBan1"].ToString());
                    float GiaBan2 = float.Parse(drServer["GiaBan2"].ToString());
                    float GiaBan3 = float.Parse(drServer["GiaBan3"].ToString());
                    float GiaBan4 = float.Parse(drServer["GiaBan4"].ToString());
                    float GiaBan5 = float.Parse(drServer["GiaBan5"].ToString());
                    string GhiChu = drServer["TrangThai"].ToString();
                    int DaXoa = int.Parse(drServer["DaXoa"].ToString());

                    dataHangHoa da = new dataHangHoa();
                    da.insertHangHoa_Full(IDNhomHang, MaHang, TenHangHoa, IDDonViTinh, IDNhaSanXuat, GiaMua, GiaBan1, GiaBan2, GiaBan3, GiaBan4, GiaBan5, 0, GhiChu, DaXoa);
                }
            }
        }
        // ----------------------
        // Lấy thông tin hàng hóa barcode
        public static DataTable getData_HangHoaBarcode_Server()
        {
            using (SqlConnection con = new SqlConnection(StaticContext.ConnectionServer))
            {
                try
                {
                    con.Open();
                    string cmdText = "SELECT * FROM [GPM_HangHoa_Barcode]";
                    using (SqlCommand command = new SqlCommand(cmdText, con))
                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        DataTable tb = new DataTable();
                        tb.Load(reader);
                        return tb;
                    }
                }
                catch (Exception)
                {
                    return new DataTable();
                }
            }
        }
        public static DataTable getData_HangHoaBarcode_Client()
        {
            using (SqlConnection con = new SqlConnection(StaticContext.ConnectionString))
            {
                try
                {
                    con.Open();
                    string cmdText = "SELECT * FROM [GPM_HangHoa_Barcode]";
                    using (SqlCommand command = new SqlCommand(cmdText, con))
                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        DataTable tb = new DataTable();
                        tb.Load(reader);
                        return tb;
                    }
                }
                catch (Exception)
                {
                    return new DataTable();
                }
            }
        }
        public static void updateBarcode()
        {
            // Hàng hóa
            DataTable dataServer = getData_HangHoaBarcode_Server();
            DataTable dataClient = getData_HangHoaBarcode_Client();
            for (int i = 0; i < dataServer.Rows.Count; i++)
            {
                DataRow drServer = dataServer.Rows[i];
                if (dataClient.Rows.Count > i)
                {
                    DataRow drClient = dataClient.Rows[i];
                    if (drServer["ID"].ToString().CompareTo(drClient["ID"].ToString()) != 0 ||
                        drServer["IDHangHoa"].ToString().CompareTo(drClient["IDHangHoa"].ToString()) != 0 ||
                        drServer["Barcode"].ToString().CompareTo(drClient["Barcode"].ToString()) != 0 ||
                        drServer["DaXoa"].ToString().CompareTo(drClient["DaXoa"].ToString()) != 0)
                    {
                        int ID = Int32.Parse(drServer["ID"].ToString());
                        int IDHangHoa = Int32.Parse(drServer["IDHangHoa"].ToString());
                        string Barcode = drServer["Barcode"].ToString();
                        int DaXoa = int.Parse(drServer["DaXoa"].ToString());

                        dataHangHoa da = new dataHangHoa();
                        da.CapNhatBarCode_Full(ID, IDHangHoa, Barcode, DaXoa);
                    }
                }
                else
                {
                    int IDHangHoa = Int32.Parse(drServer["IDHangHoa"].ToString());
                    string Barcode = drServer["Barcode"].ToString();
                    int DaXoa = int.Parse(drServer["DaXoa"].ToString());
                    dataHangHoa da = new dataHangHoa();
                    da.ThemBarCode_Full(IDHangHoa, Barcode, DaXoa);
                }
            }
        }
        // ----------------------
        // Lấy thông tin hàng hóa Combo
        public static DataTable getData_HangHoaCombo_Server()
        {
            using (SqlConnection con = new SqlConnection(StaticContext.ConnectionServer))
            {
                try
                {
                    con.Open();
                    string cmdText = "SELECT * FROM [GPM_HangHoa_Combo]";
                    using (SqlCommand command = new SqlCommand(cmdText, con))
                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        DataTable tb = new DataTable();
                        tb.Load(reader);
                        return tb;
                    }
                }
                catch (Exception)
                {
                    return new DataTable();
                }
            }
        }
        public static DataTable getData_HangHoaCombo_Client()
        {
            using (SqlConnection con = new SqlConnection(StaticContext.ConnectionString))
            {
                try
                {
                    con.Open();
                    string cmdText = "SELECT * FROM [GPM_HangHoa_Combo]";
                    using (SqlCommand command = new SqlCommand(cmdText, con))
                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        DataTable tb = new DataTable();
                        tb.Load(reader);
                        return tb;
                    }
                }
                catch (Exception)
                {
                    return new DataTable();
                }
            }
        }
        public static void updateHangHoaCombo()
        {
            // Hàng hóa
            DataTable dataServer = getData_HangHoaCombo_Server();
            DataTable dataClient = getData_HangHoaCombo_Client();
            for (int i = 0; i < dataServer.Rows.Count; i++)
            {
                DataRow drServer = dataServer.Rows[i];
                if (dataClient.Rows.Count > i)
                {
                    DataRow drClient = dataClient.Rows[i];
                    if (drServer["ID"].ToString().CompareTo(drClient["ID"].ToString()) != 0 ||
                        drServer["IDHangHoaCombo"].ToString().CompareTo(drClient["IDHangHoaCombo"].ToString()) != 0 ||
                        drServer["IDHangHoa"].ToString().CompareTo(drClient["IDHangHoa"].ToString()) != 0 ||
                        drServer["SoLuong"].ToString().CompareTo(drClient["SoLuong"].ToString()) != 0 ||
                        drServer["GiaBan"].ToString().CompareTo(drClient["GiaBan"].ToString()) != 0 ||
                        drServer["ThanhTien"].ToString().CompareTo(drClient["ThanhTien"].ToString()) != 0 ||
                        drServer["DaXoa"].ToString().CompareTo(drClient["DaXoa"].ToString()) != 0)
                    {
                        int ID = Int32.Parse(drServer["ID"].ToString());
                        int IDHangHoaCombo = Int32.Parse(drServer["IDHangHoaCombo"].ToString());
                        int IDHangHoa = Int32.Parse(drServer["IDHangHoa"].ToString());
                        int SoLuong = Int32.Parse(drServer["SoLuong"].ToString());
                        float GiaBan = float.Parse(drServer["GiaBan"].ToString());
                        float ThanhTien = float.Parse(drServer["ThanhTien"].ToString());
                        int DaXoa = int.Parse(drServer["DaXoa"].ToString());

                        dtHangCombo da = new dtHangCombo();
                        da.CapNhatHangHoa_Combo_Full(ID, IDHangHoaCombo, IDHangHoa, SoLuong, GiaBan, ThanhTien,DaXoa);
                    }
                }
                else
                {
                    int IDHangHoaCombo = Int32.Parse(drServer["IDHangHoaCombo"].ToString());
                    int IDHangHoa = Int32.Parse(drServer["IDHangHoa"].ToString());
                    int SoLuong = Int32.Parse(drServer["SoLuong"].ToString());
                    float GiaBan = float.Parse(drServer["GiaBan"].ToString());
                    float ThanhTien = float.Parse(drServer["ThanhTien"].ToString());
                    int DaXoa = int.Parse(drServer["DaXoa"].ToString());

                    dtHangCombo da = new dtHangCombo();
                    da.ThemHangHoa_Combo_Full(IDHangHoaCombo, IDHangHoa, SoLuong, GiaBan, ThanhTien, DaXoa);
                }
            }
        }
        // ----------------------
        // Lấy thông tin hàng hóa tồn kho...
        public static DataTable getData_HangHoaTonKho_Server()
        {
            using (SqlConnection con = new SqlConnection(StaticContext.ConnectionServer))
            {
                try
                {
                    con.Open();
                    string cmdText = "SELECT * FROM [GPM_HangHoaTonKho] WHERE IDKho = " + dtSetting.LayIDKho();
                    using (SqlCommand command = new SqlCommand(cmdText, con))
                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        DataTable tb = new DataTable();
                        tb.Load(reader);
                        return tb;
                    }
                }
                catch (Exception)
                {
                    return new DataTable();
                }
            }
        }
        public static DataTable getData_HangHoaTonKho_Client()
        {
            using (SqlConnection con = new SqlConnection(StaticContext.ConnectionString))
            {
                try
                {
                    con.Open();
                    string cmdText = "SELECT * FROM [GPM_HangHoaTonKho] WHERE IDKho = " + dtSetting.LayIDKho();
                    using (SqlCommand command = new SqlCommand(cmdText, con))
                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        DataTable tb = new DataTable();
                        tb.Load(reader);
                        return tb;
                    }
                }
                catch (Exception)
                {
                    return new DataTable();
                }
            }
        }
        public static void updateHangHoaTonKho()
        {
            // Hàng hóa
            DataTable dataServer = getData_HangHoaTonKho_Server();
            DataTable dataClient = getData_HangHoaTonKho_Client();
            for (int i = 0; i < dataServer.Rows.Count; i++)
            {
                DataRow drServer = dataServer.Rows[i];
                if (dataClient.Rows.Count > i)
                {
                    DataRow drClient = dataClient.Rows[i];
                    if (drServer["IDHangHoa"].ToString().CompareTo(drClient["IDHangHoa"].ToString()) != 0 ||
                        drServer["GiaBan"].ToString().CompareTo(drClient["GiaBan"].ToString()) != 0 ||
                        drServer["DaXoa"].ToString().CompareTo(drClient["DaXoa"].ToString()) != 0)
                    {
                        int IDHangHoa = Int32.Parse(drServer["IDHangHoa"].ToString());
                        float GiaBan = float.Parse(drServer["GiaBan"].ToString());
                        int DaXoa = int.Parse(drServer["DaXoa"].ToString());

                        dtKhoHang da = new dtKhoHang();
                        da.Update_HangHoaTonKho(IDHangHoa, DaXoa, GiaBan);
                    }
                }
                else
                {
                    int IDHangHoa = Int32.Parse(drServer["IDHangHoa"].ToString());
                    float GiaBan = float.Parse(drServer["GiaBan"].ToString());
                    int DaXoa = int.Parse(drServer["DaXoa"].ToString());

                    dtKhoHang da = new dtKhoHang();
                    da.ThemHang_Full(IDHangHoa, 0, GiaBan, DaXoa,dtSetting.LayIDKho());
                }
            }
           
        }
        // ----------------------
        // Lấy thông tin đơn vị tính
        public static DataTable getData_DonViTinh_Server()
        {
            using (SqlConnection con = new SqlConnection(StaticContext.ConnectionServer))
            {
                try
                {
                    con.Open();
                    string cmdText = "SELECT * FROM [GPM_DonViTinh]";
                    using (SqlCommand command = new SqlCommand(cmdText, con))
                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        DataTable tb = new DataTable();
                        tb.Load(reader);
                        return tb;
                    }
                }
                catch (Exception)
                {
                    return new DataTable();
                }
            }
        }
        public static DataTable getData_DonViTinh_Client()
        {
            using (SqlConnection con = new SqlConnection(StaticContext.ConnectionString))
            {
                try
                {
                    con.Open();
                    string cmdText = "SELECT * FROM [GPM_DonViTinh]";
                    using (SqlCommand command = new SqlCommand(cmdText, con))
                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        DataTable tb = new DataTable();
                        tb.Load(reader);
                        return tb;
                    }
                }
                catch (Exception)
                {
                    return new DataTable();
                }
            }
        }
        public static void updateDonViTinh()
        {
            // đơn vị tính
            DataTable dataServer = getData_DonViTinh_Server();
            DataTable dataClient = getData_DonViTinh_Client();
            for (int i = 0; i < dataServer.Rows.Count; i++)
            {
                DataRow drServer = dataServer.Rows[i];
                if (dataClient.Rows.Count > i)
                {
                    DataRow drClient = dataClient.Rows[i];
                    if (drServer["ID"].ToString().CompareTo(drClient["ID"].ToString()) != 0 ||
                        drServer["TenDonViTinh"].ToString().CompareTo(drClient["TenDonViTinh"].ToString()) != 0 ||
                        drServer["MoTa"].ToString().CompareTo(drClient["MoTa"].ToString()) != 0 ||
                        drServer["HeSo"].ToString().CompareTo(drClient["HeSo"].ToString()) != 0 ||
                        drServer["DaXoa"].ToString().CompareTo(drClient["DaXoa"].ToString()) != 0)
                    {
                        dtDonViTinh da = new dtDonViTinh();
                        da.SuaThongTinDonViTinh_Full(Int32.Parse(drServer["ID"].ToString()), drServer["TenDonViTinh"].ToString(), drServer["MoTa"].ToString(), Int32.Parse(drServer["HeSo"].ToString()), Int32.Parse(drServer["DaXoa"].ToString()));
                    }
                }
                else
                {
                    dtDonViTinh da = new dtDonViTinh();
                    da.ThemDonViTinh_Full(drServer["TenDonViTinh"].ToString(), drServer["MoTa"].ToString(), Int32.Parse(drServer["HeSo"].ToString()), Int32.Parse(drServer["DaXoa"].ToString()));
                }
            }

        }
        // ----------------------
        // Lấy thông tin cửa hàng kho
        public static DataTable getData_ThongTinCuaHangKho_Server()
        {
            using (SqlConnection con = new SqlConnection(StaticContext.ConnectionServer))
            {
                try
                {
                    con.Open();
                    string cmdText = "SELECT * FROM [GPM_ThongTinCuaHangKho]";
                    using (SqlCommand command = new SqlCommand(cmdText, con))
                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        DataTable tb = new DataTable();
                        tb.Load(reader);
                        return tb;
                    }
                }
                catch (Exception)
                {
                    return new DataTable();
                }
            }
        }
        public static DataTable getData_ThongTinCuaHangKho_Client()
        {
            using (SqlConnection con = new SqlConnection(StaticContext.ConnectionString))
            {
                try
                {
                    con.Open();
                    string cmdText = "SELECT * FROM [GPM_ThongTinCuaHangKho]";
                    using (SqlCommand command = new SqlCommand(cmdText, con))
                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        DataTable tb = new DataTable();
                        tb.Load(reader);
                        return tb;
                    }
                }
                catch (Exception)
                {
                    return new DataTable();
                }
            }
        }
        public static void updateThongTinCuaHangKho()
        {
            // đơn vị tính
            DataTable dataServer = getData_ThongTinCuaHangKho_Server();
            DataTable dataClient = getData_ThongTinCuaHangKho_Client();
            for (int i = 0; i < dataServer.Rows.Count; i++)
            {
                DataRow drServer = dataServer.Rows[i];
                if (dataClient.Rows.Count > i)
                {
                    DataRow drClient = dataClient.Rows[i];
                    if (drServer["ID"].ToString().CompareTo(drClient["ID"].ToString()) != 0 ||
                        drServer["TenCuaHang"].ToString().CompareTo(drClient["TenCuaHang"].ToString()) != 0 ||
                        drServer["MaKho"].ToString().CompareTo(drClient["MaKho"].ToString()) != 0 ||
                        drServer["IDVung"].ToString().CompareTo(drClient["IDVung"].ToString()) != 0 ||
                        drServer["SoSerial"].ToString().CompareTo(drClient["SoSerial"].ToString()) != 0 ||
                        drServer["DiaChi"].ToString().CompareTo(drClient["DiaChi"].ToString()) != 0 ||
                        drServer["IDQuan"].ToString().CompareTo(drClient["IDQuan"].ToString()) != 0 ||
                        drServer["IDThanhPho"].ToString().CompareTo(drClient["IDThanhPho"].ToString()) != 0 ||
                        drServer["DienThoai"].ToString().CompareTo(drClient["DienThoai"].ToString()) != 0 ||
                        drServer["NgayCapNhat"].ToString().CompareTo(drClient["NgayCapNhat"].ToString()) != 0 ||
                        drServer["DaXoa"].ToString().CompareTo(drClient["DaXoa"].ToString()) != 0)
                    {
                        dtThongTinCuaHangKho da = new dtThongTinCuaHangKho();
                        da.Sua_Full(Int32.Parse(drServer["ID"].ToString()), drServer["TenCuaHang"].ToString(), drServer["SoSerial"].ToString(), drServer["DiaChi"].ToString(),
                            Int32.Parse(drServer["IDQuan"].ToString()), Int32.Parse(drServer["IDThanhPho"].ToString()), DateTime.Parse(drServer["NgayCapNhat"].ToString()), drServer["DienThoai"].ToString(),
                            Int32.Parse(drServer["DaXoa"].ToString()), drServer["MaKho"].ToString(), Int32.Parse(drServer["IDVung"].ToString()));
                    }
                }
                else
                {
                    dtThongTinCuaHangKho da = new dtThongTinCuaHangKho();
                    da.Them_Full(drServer["TenCuaHang"].ToString(), drServer["SoSerial"].ToString(), drServer["DiaChi"].ToString(),
                        Int32.Parse(drServer["IDQuan"].ToString()), Int32.Parse(drServer["IDThanhPho"].ToString()), drServer["DienThoai"].ToString(), drServer["MaKho"].ToString(),DateTime.Parse(drServer["NgayCapNhat"].ToString()), Int32.Parse(drServer["IDVung"].ToString()), Int32.Parse(drServer["DaXoa"].ToString()));
                }
            }

        }
        // ----------------------
        // Lấy thông tin hãng sản xuất
        public static DataTable getData_ThongTinHangSanXuat_Server()
        {
            using (SqlConnection con = new SqlConnection(StaticContext.ConnectionServer))
            {
                try
                {
                    con.Open();
                    string cmdText = "SELECT * FROM [GPM_HangSanXuat]";
                    using (SqlCommand command = new SqlCommand(cmdText, con))
                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        DataTable tb = new DataTable();
                        tb.Load(reader);
                        return tb;
                    }
                }
                catch (Exception)
                {
                    return new DataTable();
                }
            }
        }
        public static DataTable getData_ThongTinHangSanXuat_Client()
        {
            using (SqlConnection con = new SqlConnection(StaticContext.ConnectionString))
            {
                try
                {
                    con.Open();
                    string cmdText = "SELECT * FROM [GPM_HangSanXuat]";
                    using (SqlCommand command = new SqlCommand(cmdText, con))
                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        DataTable tb = new DataTable();
                        tb.Load(reader);
                        return tb;
                    }
                }
                catch (Exception)
                {
                    return new DataTable();
                }
            }
        }
        public static void updateThongTinHangSanXuat()
        {
            // Hãng SX
            DataTable dataServer = getData_ThongTinHangSanXuat_Server();
            DataTable dataClient = getData_ThongTinHangSanXuat_Client();
            for (int i = 0; i < dataServer.Rows.Count; i++)
            {
                DataRow drServer = dataServer.Rows[i];
                if (dataClient.Rows.Count > i)
                {
                    DataRow drClient = dataClient.Rows[i];
                    if (drServer["ID"].ToString().CompareTo(drClient["ID"].ToString()) != 0 ||
                        drServer["TenNhanHang"].ToString().CompareTo(drClient["TenNhanHang"].ToString()) != 0 ||
                        drServer["SDT"].ToString().CompareTo(drClient["SDT"].ToString()) != 0 ||
                        drServer["DiaChi"].ToString().CompareTo(drClient["DiaChi"].ToString()) != 0 ||
                        drServer["IDQuan"].ToString().CompareTo(drClient["IDQuan"].ToString()) != 0 ||
                        drServer["IDThanhPho"].ToString().CompareTo(drClient["IDThanhPho"].ToString()) != 0 ||
                        drServer["Email"].ToString().CompareTo(drClient["Email"].ToString()) != 0 ||
                        drServer["GhiChu"].ToString().CompareTo(drClient["GhiChu"].ToString()) != 0 ||
                        drServer["DaXoa"].ToString().CompareTo(drClient["DaXoa"].ToString()) != 0)
                    {
                        dataHangSanXuat da = new dataHangSanXuat();
                        da.updateHangSX_Full(Int32.Parse(drServer["ID"].ToString()), drServer["TenNhanHang"].ToString(), drServer["SDT"].ToString(), drServer["DiaChi"].ToString(),
                            Int32.Parse(drServer["IDQuan"].ToString()), Int32.Parse(drServer["IDThanhPho"].ToString()), drServer["Email"].ToString(),drServer["GhiChu"].ToString(), Int32.Parse(drServer["DaXoa"].ToString()));
                    }
                }
                else
                {
                    dataHangSanXuat da = new dataHangSanXuat();
                    da.insertHangSX_Full(drServer["TenNhanHang"].ToString(), drServer["SDT"].ToString(), drServer["DiaChi"].ToString(),
                        Int32.Parse(drServer["IDQuan"].ToString()), Int32.Parse(drServer["IDThanhPho"].ToString()), drServer["Email"].ToString(), drServer["GhiChu"].ToString(), Int32.Parse(drServer["DaXoa"].ToString()));
                }
            }

        }
        // ----------------------
        // Lấy thông tin nhóm khách hàng
        public static DataTable getData_NhomKhachHang_Server()
        {
            using (SqlConnection con = new SqlConnection(StaticContext.ConnectionServer))
            {
                try
                {
                    con.Open();
                    string cmdText = "SELECT * FROM [GPM_NhomKhachHang]";
                    using (SqlCommand command = new SqlCommand(cmdText, con))
                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        DataTable tb = new DataTable();
                        tb.Load(reader);
                        return tb;
                    }
                }
                catch (Exception)
                {
                    return new DataTable();
                }
            }
        }
        public static DataTable getData_NhomKhachHang_Client()
        {
            using (SqlConnection con = new SqlConnection(StaticContext.ConnectionString))
            {
                try
                {
                    con.Open();
                    string cmdText = "SELECT * FROM [GPM_NhomKhachHang]";
                    using (SqlCommand command = new SqlCommand(cmdText, con))
                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        DataTable tb = new DataTable();
                        tb.Load(reader);
                        return tb;
                    }
                }
                catch (Exception)
                {
                    return new DataTable();
                }
            }
        }
        public static void updateNhomKhachHang()
        {
            // Hãng SX
            DataTable dataServer = getData_NhomKhachHang_Server();
            DataTable dataClient = getData_NhomKhachHang_Client();
            for (int i = 0; i < dataServer.Rows.Count; i++)
            {
                DataRow drServer = dataServer.Rows[i];
                if (dataClient.Rows.Count > i)
                {
                    DataRow drClient = dataClient.Rows[i];
                    if (drServer["ID"].ToString().CompareTo(drClient["ID"].ToString()) != 0 ||
                        drServer["TenNhomKhachHang"].ToString().CompareTo(drClient["TenNhomKhachHang"].ToString()) != 0 ||
                        drServer["LoaiKhachHang"].ToString().CompareTo(drClient["LoaiKhachHang"].ToString()) != 0 ||
                        drServer["GhiChu"].ToString().CompareTo(drClient["GhiChu"].ToString()) != 0 ||
                        drServer["DaXoa"].ToString().CompareTo(drClient["DaXoa"].ToString()) != 0)
                    {
                        dtNhomKhachHang da = new dtNhomKhachHang();
                        da.SuaThongTinNhomKhachHang_Full(Int32.Parse(drServer["ID"].ToString()), drServer["TenNhomKhachHang"].ToString(), drServer["LoaiKhachHang"].ToString(), drServer["GhiChu"].ToString(),Int32.Parse(drServer["DaXoa"].ToString()));
                    }
                }
                else
                {
                    dtNhomKhachHang da = new dtNhomKhachHang();
                    da.ThemNhomNhomHangMoi_Full(drServer["TenNhomKhachHang"].ToString(), drServer["LoaiKhachHang"].ToString(), drServer["GhiChu"].ToString(), Int32.Parse(drServer["DaXoa"].ToString()));
                }
            }

        }
        // ----------------------
        // Lấy thông tin vùng
        public static DataTable getData_Vung_Server()
        {
            using (SqlConnection con = new SqlConnection(StaticContext.ConnectionServer))
            {
                try
                {
                    con.Open();
                    string cmdText = "SELECT * FROM [GPM_Vung]";
                    using (SqlCommand command = new SqlCommand(cmdText, con))
                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        DataTable tb = new DataTable();
                        tb.Load(reader);
                        return tb;
                    }
                }
                catch (Exception)
                {
                    return new DataTable();
                }
            }
        }
        public static DataTable getData_Vung_Client()
        {
            using (SqlConnection con = new SqlConnection(StaticContext.ConnectionString))
            {
                try
                {
                    con.Open();
                    string cmdText = "SELECT * FROM [GPM_Vung]";
                    using (SqlCommand command = new SqlCommand(cmdText, con))
                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        DataTable tb = new DataTable();
                        tb.Load(reader);
                        return tb;
                    }
                }
                catch (Exception)
                {
                    return new DataTable();
                }
            }
        }
        public static void updateVung()
        {
            // Hãng SX
            DataTable dataServer = getData_Vung_Server();
            DataTable dataClient = getData_Vung_Client();
            for (int i = 0; i < dataServer.Rows.Count; i++)
            {
                DataRow drServer = dataServer.Rows[i];
                if (dataClient.Rows.Count > i)
                {
                    DataRow drClient = dataClient.Rows[i];
                    if (drServer["ID"].ToString().CompareTo(drClient["ID"].ToString()) != 0 ||
                        drServer["MaVung"].ToString().CompareTo(drClient["MaVung"].ToString()) != 0 ||
                        drServer["TenVung"].ToString().CompareTo(drClient["TenVung"].ToString()) != 0 ||
                        drServer["DaXoa"].ToString().CompareTo(drClient["DaXoa"].ToString()) != 0)
                    {
                        dtVung da = new dtVung();
                        da.Sua_Full(Int32.Parse(drServer["ID"].ToString()), drServer["MaVung"].ToString(), drServer["TenVung"].ToString(), Int32.Parse(drServer["DaXoa"].ToString()));
                    }
                }
                else
                {
                    dtVung da = new dtVung();
                    da.Them_Full(drServer["MaVung"].ToString(), drServer["TenVung"].ToString(), Int32.Parse(drServer["DaXoa"].ToString()));
                }
            }

        }
        // ----------------------
        // Lấy thông tin quận
        public static DataTable getData_Quan_Server()
        {
            using (SqlConnection con = new SqlConnection(StaticContext.ConnectionServer))
            {
                try
                {
                    con.Open();
                    string cmdText = "SELECT * FROM [GPM_district]";
                    using (SqlCommand command = new SqlCommand(cmdText, con))
                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        DataTable tb = new DataTable();
                        tb.Load(reader);
                        return tb;
                    }
                }
                catch (Exception)
                {
                    return new DataTable();
                }
            }
        }
        public static DataTable getData_Quan_Client()
        {
            using (SqlConnection con = new SqlConnection(StaticContext.ConnectionString))
            {
                try
                {
                    con.Open();
                    string cmdText = "SELECT * FROM [GPM_district]";
                    using (SqlCommand command = new SqlCommand(cmdText, con))
                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        DataTable tb = new DataTable();
                        tb.Load(reader);
                        return tb;
                    }
                }
                catch (Exception)
                {
                    return new DataTable();
                }
            }
        }
        public static void updateQuan()
        {
            // Hãng SX
            DataTable dataServer = getData_Quan_Server();
            DataTable dataClient = getData_Quan_Client();
            for (int i = 0; i < dataServer.Rows.Count; i++)
            {
                DataRow drServer = dataServer.Rows[i];
                if (dataClient.Rows.Count > i)
                {
                    DataRow drClient = dataClient.Rows[i];
                    if (drServer["districtid"].ToString().CompareTo(drClient["districtid"].ToString()) != 0 ||
                        drServer["name"].ToString().CompareTo(drClient["name"].ToString()) != 0 ||
                        drServer["type"].ToString().CompareTo(drClient["type"].ToString()) != 0 ||
                        drServer["provinceid"].ToString().CompareTo(drClient["provinceid"].ToString()) != 0)
                    {
                        dtQuan da = new dtQuan();
                        da.SuaQuan(drServer["districtid"].ToString(), drServer["name"].ToString(), drServer["type"].ToString(), drServer["provinceid"].ToString());
                    }
                }
                else
                {
                    dtQuan da = new dtQuan();
                    da.ThemQuan(drServer["districtid"].ToString(), drServer["name"].ToString(), drServer["type"].ToString(), drServer["provinceid"].ToString());
                }
            }

        }
        // ----------------------
        // Lấy thông tin thành phố
        public static DataTable getData_ThanhPho_Server()
        {
            using (SqlConnection con = new SqlConnection(StaticContext.ConnectionServer))
            {
                try
                {
                    con.Open();
                    string cmdText = "SELECT * FROM [GPM_province]";
                    using (SqlCommand command = new SqlCommand(cmdText, con))
                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        DataTable tb = new DataTable();
                        tb.Load(reader);
                        return tb;
                    }
                }
                catch (Exception)
                {
                    return new DataTable();
                }
            }
        }
        public static DataTable getData_ThanhPho_Client()
        {
            using (SqlConnection con = new SqlConnection(StaticContext.ConnectionString))
            {
                try
                {
                    con.Open();
                    string cmdText = "SELECT * FROM [GPM_province]";
                    using (SqlCommand command = new SqlCommand(cmdText, con))
                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        DataTable tb = new DataTable();
                        tb.Load(reader);
                        return tb;
                    }
                }
                catch (Exception)
                {
                    return new DataTable();
                }
            }
        }
        public static void updateThanhPho()
        {
            // Hãng SX
            DataTable dataServer = getData_Quan_Server();
            DataTable dataClient = getData_Quan_Client();
            for (int i = 0; i < dataServer.Rows.Count; i++)
            {
                DataRow drServer = dataServer.Rows[i];
                if (dataClient.Rows.Count > i)
                {
                    DataRow drClient = dataClient.Rows[i];
                    if (drServer["provinceid"].ToString().CompareTo(drClient["provinceid"].ToString()) != 0 ||
                        drServer["name"].ToString().CompareTo(drClient["name"].ToString()) != 0 ||
                        drServer["type"].ToString().CompareTo(drClient["type"].ToString()) != 0)
                    {
                        dtThanhPho da = new dtThanhPho();
                        da.SuaThanhPho(drServer["provinceid"].ToString(), drServer["name"].ToString(), drServer["type"].ToString());
                    }
                }
                else
                {
                    dtThanhPho da = new dtThanhPho();
                    da.ThemThanhPho(drServer["provinceid"].ToString(), drServer["name"].ToString(), drServer["type"].ToString());
                }
            }

        }
        // ----------------------
        // Lấy thông tin nhóm người dùng
        public static DataTable getData_NhomNguoiDung_Server()
        {
            using (SqlConnection con = new SqlConnection(StaticContext.ConnectionServer))
            {
                try
                {
                    con.Open();
                    string cmdText = "SELECT * FROM [GPM_NhomNguoiDung]";
                    using (SqlCommand command = new SqlCommand(cmdText, con))
                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        DataTable tb = new DataTable();
                        tb.Load(reader);
                        return tb;
                    }
                }
                catch (Exception)
                {
                    return new DataTable();
                }
            }
        }
        public static DataTable getData_NhomNguoiDung_Client()
        {
            using (SqlConnection con = new SqlConnection(StaticContext.ConnectionString))
            {
                try
                {
                    con.Open();
                    string cmdText = "SELECT * FROM [GPM_NhomNguoiDung]";
                    using (SqlCommand command = new SqlCommand(cmdText, con))
                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        DataTable tb = new DataTable();
                        tb.Load(reader);
                        return tb;
                    }
                }
                catch (Exception)
                {
                    return new DataTable();
                }
            }
        }
        public static void updateNhomNguoiDung()
        {
            // Hãng SX
            DataTable dataServer = getData_NhomNguoiDung_Server();
            DataTable dataClient = getData_NhomNguoiDung_Client();
            for (int i = 0; i < dataServer.Rows.Count; i++)
            {
                DataRow drServer = dataServer.Rows[i];
                if (dataClient.Rows.Count > i)
                {
                    DataRow drClient = dataClient.Rows[i];
                    if (drServer["ID"].ToString().CompareTo(drClient["ID"].ToString()) != 0 ||
                        drServer["TenNhom"].ToString().CompareTo(drClient["TenNhom"].ToString()) != 0)
                    {
                        dtNhomNguoiDung da = new dtNhomNguoiDung();
                        da.SuaThongTinNhomNguoiDung(Int32.Parse(drServer["ID"].ToString()), drServer["TenNhom"].ToString(), DateTime.Parse(drServer["NgayCapNhat"].ToString()));
                    }
                }
                else
                {
                    dtNhomNguoiDung da = new dtNhomNguoiDung();
                    da.ThemNhomNguoiDung(drServer["TenNhom"].ToString(), DateTime.Parse(drServer["NgayCapNhat"].ToString()));
                }
            }

        }

        // ----------------------
        // Lấy thông tin menu.
        public static DataTable getData_Menu_Server()
        {
            using (SqlConnection con = new SqlConnection(StaticContext.ConnectionServer))
            {
                try
                {
                    con.Open();
                    string cmdText = "SELECT * FROM [GPM_Menu]";
                    using (SqlCommand command = new SqlCommand(cmdText, con))
                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        DataTable tb = new DataTable();
                        tb.Load(reader);
                        return tb;
                    }
                }
                catch (Exception)
                {
                    return new DataTable();
                }
            }
        }
        public static DataTable getData_Menu_Client()
        {
            using (SqlConnection con = new SqlConnection(StaticContext.ConnectionString))
            {
                try
                {
                    con.Open();
                    string cmdText = "SELECT * FROM [GPM_Menu]";
                    using (SqlCommand command = new SqlCommand(cmdText, con))
                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        DataTable tb = new DataTable();
                        tb.Load(reader);
                        return tb;
                    }
                }
                catch (Exception)
                {
                    return new DataTable();
                }
            }
        }
        public static void updateMenu()
        {
            // Hãng SX
            DataTable dataServer = getData_Menu_Server();
            DataTable dataClient = getData_Menu_Client();
            for (int i = 0; i < dataServer.Rows.Count; i++)
            {
                DataRow drServer = dataServer.Rows[i];
                if (dataClient.Rows.Count > i)
                {
                    DataRow drClient = dataClient.Rows[i];
                    if (drServer["ID"].ToString().CompareTo(drClient["ID"].ToString()) != 0 ||
                        drServer["TenDanhMuc"].ToString().CompareTo(drClient["TenDanhMuc"].ToString()) != 0)
                    {
                        dtSetting da = new dtSetting();
                        da.updateMenu(Int32.Parse(drServer["ID"].ToString()), drServer["TenDanhMuc"].ToString());
                    }
                }
                else
                {
                    dtSetting da = new dtSetting();
                    da.insertMenu(Int32.Parse(drServer["ID"].ToString()), drServer["TenDanhMuc"].ToString());
                }
            }

        }

        // ----------------------
        // Lấy thông tin phân quyền
        public static DataTable getData_PhanQuyen_Server()
        {
            using (SqlConnection con = new SqlConnection(StaticContext.ConnectionServer))
            {
                try
                {
                    con.Open();
                    string cmdText = "SELECT * FROM [GPM_PhanQuyen]";
                    using (SqlCommand command = new SqlCommand(cmdText, con))
                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        DataTable tb = new DataTable();
                        tb.Load(reader);
                        return tb;
                    }
                }
                catch (Exception)
                {
                    return new DataTable();
                }
            }
        }
        public static DataTable getData_PhanQuyen_Client()
        {
            using (SqlConnection con = new SqlConnection(StaticContext.ConnectionString))
            {
                try
                {
                    con.Open();
                    string cmdText = "SELECT * FROM [GPM_PhanQuyen]";
                    using (SqlCommand command = new SqlCommand(cmdText, con))
                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        DataTable tb = new DataTable();
                        tb.Load(reader);
                        return tb;
                    }
                }
                catch (Exception)
                {
                    return new DataTable();
                }
            }
        }
        public static void updatePhanQuyen()
        {
            // Hãng SX
            DataTable dataServer = getData_PhanQuyen_Server();
            DataTable dataClient = getData_PhanQuyen_Client();
            for (int i = 0; i < dataServer.Rows.Count; i++)
            {
                DataRow drServer = dataServer.Rows[i];
                if (dataClient.Rows.Count > i)
                {
                    DataRow drClient = dataClient.Rows[i];
                    if (drServer["ID"].ToString().CompareTo(drClient["ID"].ToString()) != 0 ||
                        drServer["IDNhomNguoiDung"].ToString().CompareTo(drClient["IDNhomNguoiDung"].ToString()) != 0 ||
                        drServer["IDMenu"].ToString().CompareTo(drClient["IDMenu"].ToString()) != 0 ||
                        drServer["TrangThai"].ToString().CompareTo(drClient["TrangThai"].ToString()) != 0 ||
                        drServer["NgayCapNhat"].ToString().CompareTo(drClient["NgayCapNhat"].ToString()) != 0 ||
                        drServer["ChucNang"].ToString().CompareTo(drClient["ChucNang"].ToString()) != 0)
                    {
                        dtPhanQuyen da = new dtPhanQuyen();
                        da.CapNhatQuyen_Full(Int32.Parse(drServer["ID"].ToString()), Int32.Parse(drServer["IDNhomNguoiDung"].ToString()), Int32.Parse(drServer["IDMenu"].ToString()), Int32.Parse(drServer["TrangThai"].ToString()), Int32.Parse(drServer["ChucNang"].ToString()));
                    }
                }
                else
                {
                    dtPhanQuyen da = new dtPhanQuyen();
                    da.Insert_Full(Int32.Parse(drServer["ID"].ToString()), Int32.Parse(drServer["IDNhomNguoiDung"].ToString()), Int32.Parse(drServer["IDMenu"].ToString()), Int32.Parse(drServer["TrangThai"].ToString()), Int32.Parse(drServer["ChucNang"].ToString()));
                }
            }

        }

        // ----------------------
        // Lấy thông tin nhà cung cấp
        public static DataTable getData_NhaCungCap_Server()
        {
            using (SqlConnection con = new SqlConnection(StaticContext.ConnectionServer))
            {
                try
                {
                    con.Open();
                    string cmdText = "SELECT * FROM [GPM_NhaCungCap]";
                    using (SqlCommand command = new SqlCommand(cmdText, con))
                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        DataTable tb = new DataTable();
                        tb.Load(reader);
                        return tb;
                    }
                }
                catch (Exception)
                {
                    return new DataTable();
                }
            }
        }
        public static DataTable getData_NhaCungCap_Client()
        {
            using (SqlConnection con = new SqlConnection(StaticContext.ConnectionString))
            {
                try
                {
                    con.Open();
                    string cmdText = "SELECT * FROM [GPM_NhaCungCap]";
                    using (SqlCommand command = new SqlCommand(cmdText, con))
                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        DataTable tb = new DataTable();
                        tb.Load(reader);
                        return tb;
                    }
                }
                catch (Exception)
                {
                    return new DataTable();
                }
            }
        }
        public static void updateNhaCungCap()
        {
            // Hãng SX
            DataTable dataServer = getData_NhaCungCap_Server();
            DataTable dataClient = getData_NhaCungCap_Client();
            for (int i = 0; i < dataServer.Rows.Count; i++)
            {
                DataRow drServer = dataServer.Rows[i];
                if (dataClient.Rows.Count > i)
                {
                    DataRow drClient = dataClient.Rows[i];
                    if (drServer["ID"].ToString().CompareTo(drClient["ID"].ToString()) != 0 ||
                            drServer["TenNhaCungCap"].ToString().CompareTo(drClient["TenNhaCungCap"].ToString()) != 0 ||
                            drServer["DienThoai"].ToString().CompareTo(drClient["DienThoai"].ToString()) != 0 ||
                            drServer["Fax"].ToString().CompareTo(drClient["Fax"].ToString()) != 0 ||
                            drServer["Email"].ToString().CompareTo(drClient["Email"].ToString()) != 0 ||
                            drServer["DiaChi"].ToString().CompareTo(drClient["DiaChi"].ToString()) != 0 ||
                            drServer["NguoiLienHe"].ToString().CompareTo(drClient["NguoiLienHe"].ToString()) != 0 ||
                            drServer["MaSoThue"].ToString().CompareTo(drClient["MaSoThue"].ToString()) != 0 ||
                            drServer["LinhVucKinhDoanh"].ToString().CompareTo(drClient["LinhVucKinhDoanh"].ToString()) != 0 ||
                            drServer["NgayCapNhat"].ToString().CompareTo(drClient["NgayCapNhat"].ToString()) != 0 ||
                            drServer["GhiChu"].ToString().CompareTo(drClient["GhiChu"].ToString()) != 0 ||
                            drServer["DaXoa"].ToString().CompareTo(drClient["DaXoa"].ToString()) != 0)
                    {
                        dtNhaCungCap da = new dtNhaCungCap();
                        da.SuaThongTinNhaCungCap_Full(Int32.Parse(drServer["ID"].ToString()), drServer["TenNhaCungCap"].ToString(), drServer["DienThoai"].ToString(), drServer["Fax"].ToString(),
                            drServer["Email"].ToString(), drServer["DiaChi"].ToString(), drServer["NguoiLienHe"].ToString(), drServer["MaSoThue"].ToString(),
                            drServer["LinhVucKinhDoanh"].ToString(), DateTime.Parse(drServer["NgayCapNhat"].ToString()), drServer["GhiChu"].ToString(), Int32.Parse(drServer["DaXoa"].ToString()));
                    }
                }
                else
                {
                    dtNhaCungCap da = new dtNhaCungCap();
                    da.ThemNhaCungCap_Full(drServer["TenNhaCungCap"].ToString(), drServer["DienThoai"].ToString(), drServer["Fax"].ToString(),
                        drServer["Email"].ToString(), drServer["DiaChi"].ToString(), drServer["NguoiLienHe"].ToString(), drServer["MaSoThue"].ToString(),
                        drServer["LinhVucKinhDoanh"].ToString(), DateTime.Parse(drServer["NgayCapNhat"].ToString()), drServer["GhiChu"].ToString(), Int32.Parse(drServer["DaXoa"].ToString()));
                }
            }

        }

        // Cập nhật đơn đặt hàng khi server đã duyệt.
        public static DataTable getData_DonDatHangDaDuyet_Server()
        {
            int IDKho = dtSetting.LayIDKho();
            using (SqlConnection con = new SqlConnection(StaticContext.ConnectionServer))
            {
                try
                {
                    con.Open();
                    string cmdText = " SELECT * FROM [GPM_DonDatHang] WHERE (TrangThai = 1 OR DaXoa = 1) AND IDKho = " + IDKho;
                    using (SqlCommand command = new SqlCommand(cmdText, con))
                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        DataTable tb = new DataTable();
                        tb.Load(reader);
                        return tb;
                    }
                }
                catch (Exception) { return new DataTable(); }
            }
        }
        public static void update_DonDatHangDaDuyet_Client(int IDServer, int TrangThai, int DaXoa, string GhiChu)
        {
            int IDKho = dtSetting.LayIDKho();
            using (SqlConnection con = new SqlConnection(StaticContext.ConnectionString))
            {
                try
                {
                    con.Open();
                    string cmdText = "UPDATE [GPM_DonDatHang] SET TrangThai = '" + TrangThai + "', DaXoa = '" + DaXoa + "',GhiChu = '" + GhiChu + "' WHERE IDServer = '" + IDServer + "' AND TrangThai < '" + TrangThai + "'";
                    using (SqlCommand myCommand = new SqlCommand(cmdText, con))
                    {
                        myCommand.ExecuteNonQuery();
                    }
                }
                catch (Exception) {}
            }
        }
        public static void updateData_DonDatHangDaDuyet_Client()
        {
            DataTable da = getData_DonDatHangDaDuyet_Server();
            if (da.Rows.Count != 0)
            {
                for (int i = 0; i < da.Rows.Count; i++)
                {
                    DataRow dr = da.Rows[i];
                    int ID = Int32.Parse(dr["ID"].ToString());
                    int TrangThai = Int32.Parse(dr["TrangThai"].ToString());
                    int DaXoa = Int32.Parse(dr["DaXoa"].ToString());
                    string GhiChu = dr["GhiChu"].ToString();
                    update_DonDatHangDaDuyet_Client(ID, TrangThai, DaXoa, GhiChu);
                }
            }
        }

        // Cập nhật phiếu chuyển kho.
        public static DataTable getData_PhieuChuyenKho_Server_To_KhoXuat()
        {
            int IDKho = dtSetting.LayIDKho();
            using (SqlConnection con = new SqlConnection(StaticContext.ConnectionServer))
            {
                try
                {
                    con.Open();
                    string cmdText = " SELECT * FROM [GPM_PhieuChuyenKho] WHERE TrangThai = 0 AND InsertServer = 0 AND IDKhoXuat = '" + IDKho + "'";
                    using (SqlCommand command = new SqlCommand(cmdText, con))
                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        DataTable tb = new DataTable();
                        tb.Load(reader);
                        return tb;
                    }
                }
                catch (Exception) { return new DataTable(); }
            }
        }
        public static DataTable getData_ChiTietPhieuChuyenKho_Server_To_KhoXuat(int ID)
        {
            using (SqlConnection con = new SqlConnection(StaticContext.ConnectionServer))
            {
                try
                {
                    con.Open();
                    string cmdText = " SELECT * FROM [GPM_ChiTietPhieuChuyenKho] WHERE InsertServer = 0 AND IDPhieuChuyenKho = " + ID;
                    using (SqlCommand command = new SqlCommand(cmdText, con))
                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        DataTable tb = new DataTable();
                        tb.Load(reader);
                        return tb;
                    }
                }
                catch (Exception) { return new DataTable(); }
            }
        }
        public static void update_PhieuChuyenKho_Server_To_KhoXuat_End(int ID)
        {
            int IDKho = dtSetting.LayIDKho();
            using (SqlConnection con = new SqlConnection(StaticContext.ConnectionServer))
            {
                try
                {
                    con.Open();
                    string cmdText = "UPDATE [GPM_PhieuChuyenKho] SET InsertServer = 1 WHERE ID = " + ID;
                    using (SqlCommand myCommand = new SqlCommand(cmdText, con))
                    {
                        myCommand.ExecuteNonQuery();
                    }
                }
                catch (Exception) { }
            }
        }
        public static DataTable updateData_ChiTietPhieuChuyenKho_Server_To_KhoXuat_End(int ID)
        {
            using (SqlConnection con = new SqlConnection(StaticContext.ConnectionServer))
            {
                try
                {
                    con.Open();
                    string cmdText = " UPDATE [GPM_ChiTietPhieuChuyenKho] SET InsertServer = 1 WHERE ID = " + ID;
                    using (SqlCommand command = new SqlCommand(cmdText, con))
                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        DataTable tb = new DataTable();
                        tb.Load(reader);
                        return tb;
                    }
                }
                catch (Exception) { return new DataTable(); }
            }
        }
        public static object insert_PhieuChuyenKho_To_KhoXuat(int IDServer, int IDKhoXuat, int IDKhoNhap, DateTime NgayLap, string GhiChu, int DaXoa)
        {
            using (SqlConnection myConnection = new SqlConnection(StaticContext.ConnectionString))
            {
                try
                {
                    myConnection.Open();
                    object ID = null;
                    string cmdText = "INSERT INTO [GPM_PhieuChuyenKho] ([IDServer],[IDKhoXuat], [IDKhoNhap],[NgayLap],[GhiChu],[DaXoa]) OUTPUT INSERTED.ID VALUES (@IDServer,@IDKhoXuat,@IDKhoNhap,@NgayLap, @GhiChu,@DaXoa)";
                    using (SqlCommand myCommand = new SqlCommand(cmdText, myConnection))
                    {
                        myCommand.Parameters.AddWithValue("@IDServer", IDServer);
                        myCommand.Parameters.AddWithValue("@IDKhoXuat", IDKhoXuat);
                        myCommand.Parameters.AddWithValue("@IDKhoNhap", IDKhoNhap);
                        myCommand.Parameters.AddWithValue("@NgayLap", NgayLap);
                        myCommand.Parameters.AddWithValue("@GhiChu", GhiChu);
                        myCommand.Parameters.AddWithValue("@DaXoa", DaXoa);
                        ID = myCommand.ExecuteScalar();
                    }
                    myConnection.Close();
                    return ID;
                }
                catch
                {
                    return (object)-1;
                    //throw new Exception("Lỗi: Quá trình thêm dữ liệu gặp lỗi");
                }
            }
        }
        public static void insert_ChiTietPhieuChuyenKho_To_KhoXuat(object IDPhieuChuyenKho, int IDHangHoa, int IDDonViTinh, int SoLuong, float DonGia, float ThanhTien, int DaXoa)
        {
            using (SqlConnection myConnection = new SqlConnection(StaticContext.ConnectionString))
            {
                try
                {
                    myConnection.Open();
                    string cmdText = "INSERT INTO [GPM_ChiTietPhieuChuyenKho] ([IDPhieuChuyenKho], [IDHangHoa], [IDDonViTinh], [SoLuong], [DonGia],[ThanhTien],[DaXoa]) VALUES (@IDPhieuChuyenKho, @IDHangHoa,@IDDonViTinh, @SoLuong, @DonGia,@ThanhTien,@DaXoa)";
                    using (SqlCommand myCommand = new SqlCommand(cmdText, myConnection))
                    {
                        myCommand.Parameters.AddWithValue("@IDPhieuChuyenKho", IDPhieuChuyenKho);
                        myCommand.Parameters.AddWithValue("@IDHangHoa", IDHangHoa);
                        myCommand.Parameters.AddWithValue("@IDDonViTinh", IDDonViTinh);
                        myCommand.Parameters.AddWithValue("@SoLuong", SoLuong);
                        myCommand.Parameters.AddWithValue("@DonGia", DonGia);
                        myCommand.Parameters.AddWithValue("@ThanhTien", ThanhTien);
                        myCommand.Parameters.AddWithValue("@DaXoa", DaXoa);
                        myCommand.ExecuteNonQuery();
                    }
                    myConnection.Close();
                }
                catch
                {
                    //throw new Exception("Lỗi: Quá trình thêm dữ liệu gặp lỗi");
                }
            }
        }
        public static void insert_PhieuChuyenKho_Server_To_KhoXuat()
        {
            DataTable da = getData_PhieuChuyenKho_Server_To_KhoXuat();
            if (da.Rows.Count != 0)
            {
                for (int i = 0; i < da.Rows.Count; i++)
                {
                    DataRow dr = da.Rows[i];
                    int ID = Int32.Parse(dr["ID"].ToString());
                    int IDKhoXuat = Int32.Parse(dr["IDKhoXuat"].ToString());
                    int IDKhoNhap = Int32.Parse(dr["IDKhoNhap"].ToString());
                    DateTime NgayLap = DateTime.Parse(dr["NgayLap"].ToString());
                    string GhiChu = dr["GhiChu"].ToString();
                    int DaXoa = Int32.Parse(dr["DaXoa"].ToString());
                    object IDServer = insert_PhieuChuyenKho_To_KhoXuat(ID, IDKhoXuat, IDKhoNhap, NgayLap, GhiChu, DaXoa);
                    if ((int)IDServer != -1)
                    {
                        update_PhieuChuyenKho_Server_To_KhoXuat_End(ID);
                        DataTable da1 = getData_ChiTietPhieuChuyenKho_Server_To_KhoXuat(ID);
                        if (da1.Rows.Count != 0)
                        {
                            for (int j = 0; j < da1.Rows.Count;j++)
                            {
                                DataRow dr1 = da1.Rows[j];
                                ID = Int32.Parse(dr1["ID"].ToString());
                                int IDHangHoa = Int32.Parse(dr1["IDHangHoa"].ToString());
                                int IDDonViTinh = Int32.Parse(dr1["IDDonViTinh"].ToString());
                                int SoLuong = int.Parse(dr1["SoLuong"].ToString());
                                float DonGia = float.Parse(dr1["DonGia"].ToString());
                                float ThanhTien = float.Parse(dr1["ThanhTien"].ToString());
                                DaXoa = Int32.Parse(dr1["DaXoa"].ToString());

                                insert_ChiTietPhieuChuyenKho_To_KhoXuat(IDServer, IDHangHoa, IDDonViTinh, SoLuong, DonGia, ThanhTien, DaXoa);
                                updateData_ChiTietPhieuChuyenKho_Server_To_KhoXuat_End(ID);
                            }
                        }
                    }
                }
            }
        }

        public static DataTable getData_PhieuChuyenKho_Server_To_KhoNhap()
        {
            int IDKho = dtSetting.LayIDKho();
            using (SqlConnection con = new SqlConnection(StaticContext.ConnectionServer))
            {
                try
                {
                    con.Open();
                    string cmdText = " SELECT * FROM [GPM_PhieuChuyenKho] WHERE TrangThai = 0 AND InsertServer = 1 AND IDKhoNhap = '" + IDKho + "'";
                    using (SqlCommand command = new SqlCommand(cmdText, con))
                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        DataTable tb = new DataTable();
                        tb.Load(reader);
                        return tb;
                    }
                }
                catch (Exception) { return new DataTable(); }
            }
        }
        public static DataTable getData_ChiTietPhieuChuyenKho_Server_To_KhoNhap(int ID)
        {
            using (SqlConnection con = new SqlConnection(StaticContext.ConnectionServer))
            {
                try
                {
                    con.Open();
                    string cmdText = " SELECT * FROM [GPM_ChiTietPhieuChuyenKho] WHERE InsertServer = 1 AND IDPhieuChuyenKho = " + ID;
                    using (SqlCommand command = new SqlCommand(cmdText, con))
                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        DataTable tb = new DataTable();
                        tb.Load(reader);
                        return tb;
                    }
                }
                catch (Exception) { return new DataTable(); }
            }
        }
        public static void update_PhieuChuyenKho_Server_To_KhoNhap_End(int ID)
        {
            int IDKho = dtSetting.LayIDKho();
            using (SqlConnection con = new SqlConnection(StaticContext.ConnectionServer))
            {
                try
                {
                    con.Open();
                    string cmdText = "UPDATE [GPM_PhieuChuyenKho] SET InsertServer = 2 WHERE ID = " + ID;
                    using (SqlCommand myCommand = new SqlCommand(cmdText, con))
                    {
                        myCommand.ExecuteNonQuery();
                    }
                }
                catch (Exception) { }
            }
        }
        public static DataTable updateData_ChiTietPhieuChuyenKho_Server_To_KhoNhap_End(int ID)
        {
            using (SqlConnection con = new SqlConnection(StaticContext.ConnectionServer))
            {
                try
                {
                    con.Open();
                    string cmdText = " UPDATE [GPM_ChiTietPhieuChuyenKho] SET InsertServer = 2 WHERE ID = " + ID;
                    using (SqlCommand command = new SqlCommand(cmdText, con))
                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        DataTable tb = new DataTable();
                        tb.Load(reader);
                        return tb;
                    }
                }
                catch (Exception) { return new DataTable(); }
            }
        }
        public static object insert_PhieuChuyenKho_To_KhoNhap(int IDServer, int IDKhoXuat, int IDKhoNhap, DateTime NgayLap, string GhiChu, int DaXoa)
        {
            using (SqlConnection myConnection = new SqlConnection(StaticContext.ConnectionString))
            {
                try
                {
                    myConnection.Open();
                    object ID = null;
                    string cmdText = "INSERT INTO [GPM_PhieuChuyenKho] ([IDServer],[IDKhoXuat], [IDKhoNhap],[NgayLap],[GhiChu],[DaXoa]) OUTPUT INSERTED.ID VALUES (@IDServer,@IDKhoXuat,@IDKhoNhap,@NgayLap, @GhiChu,@DaXoa)";
                    using (SqlCommand myCommand = new SqlCommand(cmdText, myConnection))
                    {
                        myCommand.Parameters.AddWithValue("@IDServer", IDServer);
                        myCommand.Parameters.AddWithValue("@IDKhoXuat", IDKhoXuat);
                        myCommand.Parameters.AddWithValue("@IDKhoNhap", IDKhoNhap);
                        myCommand.Parameters.AddWithValue("@NgayLap", NgayLap);
                        myCommand.Parameters.AddWithValue("@GhiChu", GhiChu);
                        myCommand.Parameters.AddWithValue("@DaXoa", DaXoa);
                        ID = myCommand.ExecuteScalar();
                    }
                    myConnection.Close();
                    return ID;
                }
                catch
                {
                    return (object)-1;
                    //throw new Exception("Lỗi: Quá trình thêm dữ liệu gặp lỗi");
                }
            }
        }
        public static void insert_ChiTietPhieuChuyenKho_To_KhoNhap(object IDPhieuChuyenKho, int IDHangHoa, int IDDonViTinh, int SoLuong, float DonGia, float ThanhTien, int DaXoa)
        {
            using (SqlConnection myConnection = new SqlConnection(StaticContext.ConnectionString))
            {
                try
                {
                    myConnection.Open();
                    string cmdText = "INSERT INTO [GPM_ChiTietPhieuChuyenKho] ([IDPhieuChuyenKho], [IDHangHoa], [IDDonViTinh], [SoLuong], [DonGia],[ThanhTien],[DaXoa]) VALUES (@IDPhieuChuyenKho, @IDHangHoa,@IDDonViTinh, @SoLuong, @DonGia,@ThanhTien,@DaXoa)";
                    using (SqlCommand myCommand = new SqlCommand(cmdText, myConnection))
                    {
                        myCommand.Parameters.AddWithValue("@IDPhieuChuyenKho", IDPhieuChuyenKho);
                        myCommand.Parameters.AddWithValue("@IDHangHoa", IDHangHoa);
                        myCommand.Parameters.AddWithValue("@IDDonViTinh", IDDonViTinh);
                        myCommand.Parameters.AddWithValue("@SoLuong", SoLuong);
                        myCommand.Parameters.AddWithValue("@DonGia", DonGia);
                        myCommand.Parameters.AddWithValue("@ThanhTien", ThanhTien);
                        myCommand.Parameters.AddWithValue("@DaXoa", DaXoa);
                        myCommand.ExecuteNonQuery();
                    }
                    myConnection.Close();
                }
                catch
                {
                    //throw new Exception("Lỗi: Quá trình thêm dữ liệu gặp lỗi");
                }
            }
        }
        public static void insert_PhieuChuyenKho_Server_To_KhoNhap()
        {
            DataTable da = getData_PhieuChuyenKho_Server_To_KhoXuat();
            if (da.Rows.Count != 0)
            {
                for (int i = 0; i < da.Rows.Count; i++)
                {
                    DataRow dr = da.Rows[i];
                    int ID = Int32.Parse(dr["ID"].ToString());
                    int IDKhoXuat = Int32.Parse(dr["IDKhoXuat"].ToString());
                    int IDKhoNhap = Int32.Parse(dr["IDKhoNhap"].ToString());
                    DateTime NgayLap = DateTime.Parse(dr["NgayLap"].ToString());
                    string GhiChu = dr["GhiChu"].ToString();
                    int DaXoa = Int32.Parse(dr["DaXoa"].ToString());
                    object IDServer = insert_PhieuChuyenKho_To_KhoNhap(ID, IDKhoXuat, IDKhoNhap, NgayLap, GhiChu, DaXoa);
                    if ((int)IDServer != -1)
                    {
                        update_PhieuChuyenKho_Server_To_KhoNhap_End(ID);
                        DataTable da1 = getData_ChiTietPhieuChuyenKho_Server_To_KhoNhap(ID);
                        if (da1.Rows.Count != 0)
                        {
                            for (int j = 0; j < da1.Rows.Count; j++)
                            {
                                DataRow dr1 = da1.Rows[j];
                                ID = Int32.Parse(dr1["ID"].ToString());
                                int IDHangHoa = Int32.Parse(dr1["IDHangHoa"].ToString());
                                int IDDonViTinh = Int32.Parse(dr1["IDDonViTinh"].ToString());
                                int SoLuong = int.Parse(dr1["SoLuong"].ToString());
                                float DonGia = float.Parse(dr1["DonGia"].ToString());
                                float ThanhTien = float.Parse(dr1["ThanhTien"].ToString());
                                DaXoa = Int32.Parse(dr1["DaXoa"].ToString());

                                insert_ChiTietPhieuChuyenKho_To_KhoNhap(IDServer, IDHangHoa, IDDonViTinh, SoLuong, DonGia, ThanhTien, DaXoa);
                                updateData_ChiTietPhieuChuyenKho_Server_To_KhoNhap_End(ID);
                            }
                        }
                    }
                }
            }
        }

        // Cập nhật phiếu chuyển kho. Giai đoạn 2, cập nhật về Kho Xuất.
        public static DataTable getData_PhieuChuyenKho_KhoXuat_GD2()
        {
            int IDKhoXuat = dtSetting.LayIDKho();
            using (SqlConnection con = new SqlConnection(StaticContext.ConnectionServer))
            {
                try
                {
                    con.Open();
                    string cmdText = " SELECT * FROM [GPM_PhieuChuyenKho] WHERE (TrangThai = 2 OR TrangThai = 4) AND IDKhoXuat = " + IDKhoXuat;
                    using (SqlCommand command = new SqlCommand(cmdText, con))
                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        DataTable tb = new DataTable();
                        tb.Load(reader);
                        return tb;
                    }
                }
                catch (Exception) { return new DataTable(); }
            }
        }
        public static void update_PhieuChuyenKho_KhoXua_GD2(int ID, int TrangThai)
        {
            int IDKho = dtSetting.LayIDKho();
            using (SqlConnection con = new SqlConnection(StaticContext.ConnectionString))
            {
                try
                {
                    con.Open();
                    string cmdText = "UPDATE [GPM_PhieuChuyenKho] SET [TrangThai] = '" + TrangThai + "' WHERE IDServer = '" + ID + "' AND [TrangThai] < '" + TrangThai + "'";
                    using (SqlCommand myCommand = new SqlCommand(cmdText, con))
                    {
                        myCommand.ExecuteNonQuery();
                    }
                }
                catch (Exception) { }
            }
        }
        public static void updateData_PhieuChuyenKho_KhoXuat_GD2_Client()
        {
            DataTable da = getData_PhieuChuyenKho_KhoXuat_GD2();
            if (da.Rows.Count != 0)
            {
                for (int i = 0; i < da.Rows.Count; i++)
                {
                    DataRow dr = da.Rows[i];
                    int ID = Int32.Parse(dr["ID"].ToString());
                    int TrangThai = Int32.Parse(dr["TrangThai"].ToString());
                    update_PhieuChuyenKho_KhoXua_GD2(ID, TrangThai);
                }
            }
        }

        // Cập nhật phiếu chuyển kho. Giai đoạn 3, cập nhật về Kho Nhập.
        public static DataTable getData_PhieuChuyenKho_KhoNhap_GD3()
        {
            int IDKhoNhap = dtSetting.LayIDKho();
            using (SqlConnection con = new SqlConnection(StaticContext.ConnectionServer))
            {
                try
                {
                    con.Open();
                    string cmdText = " SELECT * FROM [GPM_PhieuChuyenKho] WHERE (TrangThai = 1 OR TrangThai = 2 OR TrangThai = 3) AND IDKhoNhap = " + IDKhoNhap;
                    using (SqlCommand command = new SqlCommand(cmdText, con))
                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        DataTable tb = new DataTable();
                        tb.Load(reader);
                        return tb;
                    }
                }
                catch (Exception) { return new DataTable(); }
            }
        }
        public static void update_PhieuChuyenKho_KhoNhap_GD3(int ID, int TrangThai)
        {
            int IDKho = dtSetting.LayIDKho();
            using (SqlConnection con = new SqlConnection(StaticContext.ConnectionString))
            {
                try
                {
                    con.Open();
                    string cmdText = "UPDATE [GPM_PhieuChuyenKho] SET [TrangThai] = '" + TrangThai + "' WHERE IDServer = '" + ID + "' AND [TrangThai] < " + TrangThai;
                    using (SqlCommand myCommand = new SqlCommand(cmdText, con))
                    {
                        myCommand.ExecuteNonQuery();
                    }
                }
                catch (Exception) { }
            }
        }
        public static void updateData_PhieuChuyenKho_KhoNhap_GD3_Client()
        {
            DataTable da = getData_PhieuChuyenKho_KhoNhap_GD3();
            if (da.Rows.Count != 0)
            {
                for (int i = 0; i < da.Rows.Count; i++)
                {
                    DataRow dr = da.Rows[i];
                    int ID = Int32.Parse(dr["ID"].ToString());
                    int TrangThai = Int32.Parse(dr["TrangThai"].ToString());
                    update_PhieuChuyenKho_KhoNhap_GD3(ID, TrangThai);
                }
            }
        }
    }
}