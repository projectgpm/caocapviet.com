﻿using BanHang.Data;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace BanHang
{
    public partial class ThongTinCuaHang : System.Web.UI.Page
    {
        dtThongTinCuaHang data = new dtThongTinCuaHang();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (dtSetting.LayTrangThaiMenu(Session["IDNhom"].ToString(), 44) == 1)
            {
                if (!IsPostBack)
                {
                    DanhSachQuan();
                    dtThongTinCuaHangKho data = new dtThongTinCuaHangKho();
                    DataTable d = data.LayDanhSach_ID();
                    DataRow r = d.Rows[0];
                    txtCuaHang.Text = r["TenCuaHang"].ToString();
                    txtDiaChi.Text = r["DiaChi"].ToString();
                    txtDienThoai.Text = r["DienThoai"].ToString();
                    txtSoSerial.Text = r["SoSerial"].ToString();
                    cmbQuan.Value = r["IDQuan"].ToString();
                    cmbThanhPho.Text = r["IDThanhPho"].ToString();

                    DataTable da = dtSetting.LaySetting();
                    DataRow dr = da.Rows[0];
                    int cbCheck = Int32.Parse(dr["TrangThai_SoLuong"].ToString());
                    string fileNam = dr["DatabaseName"].ToString();
                    string urlName = dr["URLBackup"].ToString();

                    txtFileBackup.Text = fileNam;
                    if (cbCheck == 0) cbChuyenAm.Checked = true;
                    else cbChuyenAm.Checked = false;
                }
            }
            else
            {
                Response.Redirect("Default.aspx");
            }
        }

        protected void btnHuy_Click(object sender, EventArgs e)
        {
            Response.Redirect("Default.aspx");
        }

        protected void btnCapNhat_Click(object sender, EventArgs e)
        {
            int ID  = 1;
            string SoSerial = txtSoSerial.Text.ToString();
            string DiaChi = txtDiaChi.Text.ToString();
            int IDQuan =Int32.Parse(cmbQuan.Value.ToString());
            int IDThanhPho = Int32.Parse(cmbThanhPho.Value.ToString());
            string DienThoai = txtDienThoai.Text.ToString();
            data = new dtThongTinCuaHang();
            data.SuaThongTin(ID, SoSerial, DiaChi, IDQuan, IDThanhPho, DienThoai);
            dtLichSuTruyCap.ThemLichSu(Session["IDNhanVien"].ToString(), Session["IDNhom"].ToString(), "Thông tin cửa hàng:", dtSetting.LayIDKho(), "Hệ thống", "Cập Nhật");

            int check = 0;
            if (cbChuyenAm.Checked != true)
                check = 1;

            dtSetting.updateSetting(check);

            Response.Redirect("ThongTinCuaHang.aspx");

        }

        public void DanhSachQuan()
        {
            dtQuan q = new dtQuan();
            cmbQuan.DataSource = q.LayDanhSachQuan();
            cmbQuan.TextField = "name";
            cmbQuan.ValueField = "districtid";
            cmbQuan.DataBind();
        }

        protected void cmbThanhPho_SelectedIndexChanged(object sender, EventArgs e)
        {
            dtQuan q = new dtQuan();
            string ID =  cmbThanhPho.Value.ToString();
            cmbQuan.DataSource = q.LayDanhSachQuan_IDThanhPho(ID);
            cmbQuan.TextField = "name";
            cmbQuan.ValueField = "districtid";
            cmbQuan.DataBind();
        }
    }
}