﻿using BanHang.Data;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace BanHang
{
    public partial class ChiTietPhieuXuatTra : System.Web.UI.Page
    {
        dtPhieuXuatTra data = new dtPhieuXuatTra();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["KTDangNhap"] == "GPM")
            {
                string IDPhieuXuatTra = Request.QueryString["IDPhieuXuatTra"];
                if (IDPhieuXuatTra != null)
                {

                    LoadGrid(Int32.Parse(IDPhieuXuatTra.ToString()));
                }
            }
            else
            {
                Response.Redirect("DangNhap.aspx");
            }
        }

        private void LoadGrid(int IDPhieuXuatTra)
        {
            data = new dtPhieuXuatTra();
            gridChiTietPhieuXuatTra.DataSource = data.DanhSachChiTietPhieuXuatTra_ID(IDPhieuXuatTra);
            gridChiTietPhieuXuatTra.DataBind();
        }

        protected void gridChiTietPhieuXuatTra_RowUpdating(object sender, DevExpress.Web.Data.ASPxDataUpdatingEventArgs e)
        {
            data = new dtPhieuXuatTra();
            string IDPhieuXuatTra = Request.QueryString["IDPhieuXuatTra"];
            int ID = Int32.Parse(e.Keys[0].ToString());
            int SoLuong = Int32.Parse(e.NewValues["SoLuong"].ToString());
            DataTable db = data.DanhSachChiTietPhieuXuatTra(ID);
            if (db.Rows.Count != 0)
            {
                DataRow dr = db.Rows[0];
                float GiaMua = float.Parse(dr["GiaMua"].ToString());
                int SLCu = Int32.Parse(dr["SoLuong"].ToString());
                int IDHangHoa = Int32.Parse(dr["IDHangHoa"].ToString());
                data = new dtPhieuXuatTra();
               
                data.CapNhatChiTietPhieuXuatTra_ID(ID, SoLuong, GiaMua, (SoLuong * GiaMua));
                dtCapNhatTonKho tk = new dtCapNhatTonKho();

                dtLichSuKho.ThemLichSu(IDHangHoa, Int32.Parse(Session["IDNhanVien"].ToString()), SoLuong - SLCu, "Cập nhật chi tiết phiếu xuất trả");

                tk.TruTonKho_IDHangHoa(IDHangHoa, SoLuong - SLCu, dtSetting.LayIDKho());


                // tính tồng tiền
                DataTable tb = data.DanhSachChiTietPhieuXuatTra_ID(Int32.Parse(IDPhieuXuatTra.ToString()));
                if (tb.Rows.Count != 0)
                {
                    float TongTien = 0;
                    foreach (DataRow dr4 in tb.Rows)
                    {
                        float txtThanhTien = float.Parse(dr4["ThanhTien"].ToString());
                        TongTien = TongTien + txtThanhTien;
                    }
                    data.CapNhatTongTienPhieuXuatTra_ID(Int32.Parse(IDPhieuXuatTra.ToString()), TongTien);//cập nhật tổng tiền
                }
                e.Cancel = true;
                gridChiTietPhieuXuatTra.CancelEdit();
                LoadGrid(Int32.Parse(IDPhieuXuatTra.ToString()));

                dtLichSuTruyCap dt1 = new dtLichSuTruyCap();
                dtLichSuTruyCap.ThemLichSu(Session["IDNhanVien"].ToString(), Session["IDNhom"].ToString(), "Chi Tiết Phiếu Xuất Trả:" + ID, dtSetting.LayIDKho(), "Nhập xuất tồn", "Cập Nhật"); ;   
            }
        }
    }
}