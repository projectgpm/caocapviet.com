﻿using BanHang.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace BanHang
{
    public partial class Vung : System.Web.UI.Page
    {
        dtVung data = new dtVung();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["KTDangNhap"] != "GPM")
            {
                Response.Redirect("DangNhap.aspx");
            }
            else
            {
                if (dtSetting.LayTrangThaiMenu_ChucNang(Session["IDNhom"].ToString(), 39) == 1)
                    gridVung.Columns["iconaction"].Visible = false;

                if (dtSetting.LayTrangThaiMenu(Session["IDNhom"].ToString(), 39) == 1)
                {
                    LoadGrid();
                }
                else
                {
                    Response.Redirect("Default.aspx");
                }
            }
        }
        private void LoadGrid()
        {
            data = new dtVung();
            gridVung.DataSource = data.LayDanhSach();
            gridVung.DataBind();
        }

        protected void gridVung_RowUpdating(object sender, DevExpress.Web.Data.ASPxDataUpdatingEventArgs e)
        {
            string ID = e.Keys[0].ToString();
            string MaVung = e.NewValues["MaVung"].ToString();
            string TenVung = e.NewValues["TenVung"].ToString();
            data = new dtVung();
            data.Sua(ID, MaVung, TenVung);
            e.Cancel = true;
            gridVung.CancelEdit();
            LoadGrid();

            ActionServer.CapNhatServer();
        }

        protected void gridVung_RowInserting(object sender, DevExpress.Web.Data.ASPxDataInsertingEventArgs e)
        {
            data = new dtVung();
            string MaVung = e.NewValues["MaVung"].ToString();
            string TenVung = e.NewValues["TenVung"].ToString();
            data = new dtVung();
            data.Them(MaVung, TenVung);
            e.Cancel = true;
            gridVung.CancelEdit();
            LoadGrid();

            ActionServer.CapNhatServer();
        }

        protected void gridVung_RowDeleting(object sender, DevExpress.Web.Data.ASPxDataDeletingEventArgs e)
        {
            data = new dtVung();
            string ID = e.Keys[0].ToString();
            data.Xoa(ID);
            e.Cancel = true;
            gridVung.CancelEdit();
            LoadGrid();

            ActionServer.CapNhatServer();
        }
    }
}