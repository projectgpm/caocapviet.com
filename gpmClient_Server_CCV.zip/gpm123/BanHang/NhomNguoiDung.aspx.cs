﻿using BanHang.Data;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace BanHang
{
    public partial class NhomNguoiDung : System.Web.UI.Page
    {
        dtNhomNguoiDung data = new dtNhomNguoiDung();
        protected void Page_Load(object sender, EventArgs e)
        {

            if (Session["KTDangNhap"] != "GPM")
            {
                Response.Redirect("DangNhap.aspx");
            }
            else
            {
                if (dtSetting.LayTrangThaiMenu_ChucNang(Session["IDNhom"].ToString(), 36) == 1)
                {
                    gridNhomNguoiDung.Columns["iconaction"].Visible = false;
                    gridNhomNguoiDung.Columns["phanquyen"].Visible = false;

                }
                if (dtSetting.LayTrangThaiMenu(Session["IDNhom"].ToString(), 36) == 1)
                {
                    LoadGrid();
                }
                else
                {
                    Response.Redirect("Default.aspx");
                }
            }
        }
        public void LoadGrid()
        {
            data = new dtNhomNguoiDung();
            gridNhomNguoiDung.DataSource = data.LayDanhSachNhomNguoiDung();
            gridNhomNguoiDung.DataBind();
        }

        protected void gridNhomNguoiDung_RowDeleting(object sender, DevExpress.Web.Data.ASPxDataDeletingEventArgs e)
        {
            int ID = Int32.Parse(e.Keys[0].ToString());
            data = new dtNhomNguoiDung();
            data.XoaMenu_IDNhomNguoiDung(ID);
            data.XoaNhomNguoiDung(ID);
            e.Cancel = true;
            gridNhomNguoiDung.CancelEdit();
            LoadGrid();

            ActionServer.CapNhatServer();
            dtLichSuTruyCap.ThemLichSu(Session["IDNhanVien"].ToString(), Session["IDNhom"].ToString(), "Quản trị nhóm người dùng:" + ID, dtSetting.LayIDKho(), "Hệ Thống", "Xóa"); 
        }

        protected void gridNhomNguoiDung_RowInserting(object sender, DevExpress.Web.Data.ASPxDataInsertingEventArgs e)
        {
            DateTime NgayCapNhat = DateTime.Today.Date;
            data = new dtNhomNguoiDung();
            string TenNhom = e.NewValues["TenNhom"].ToString();
            object IDNhomNguoiDung = data.ThemNhomNguoiDung(TenNhom, NgayCapNhat);
            if (IDNhomNguoiDung != null)
            {
                DataTable db = data.DanhSachMenu();
                foreach (DataRow dr in db.Rows)
                {
                    int IDMenu = Int32.Parse(dr["ID"].ToString());
                    data = new dtNhomNguoiDung();
                    data.ThemMenu_IDNhomNguoiDung(IDNhomNguoiDung, IDMenu);
                }
            }
            e.Cancel = true;
            gridNhomNguoiDung.CancelEdit();
            LoadGrid();

            ActionServer.CapNhatServer();
            dtLichSuTruyCap.ThemLichSu(Session["IDNhanVien"].ToString(), Session["IDNhom"].ToString(), "Quản trị nhóm người dùng:" + TenNhom, dtSetting.LayIDKho(), "Hệ Thống", "Thêm"); 
        }

        protected void gridNhomNguoiDung_RowUpdating(object sender, DevExpress.Web.Data.ASPxDataUpdatingEventArgs e)
        {
            string ID = e.Keys["ID"].ToString();
            string TenNhom = e.NewValues["TenNhom"].ToString();
            DateTime NgayCapNhat = DateTime.Today.Date;
            data.SuaThongTinNhomNguoiDung(Int32.Parse(ID), TenNhom, NgayCapNhat);
            e.Cancel = true;
            gridNhomNguoiDung.CancelEdit();
            LoadGrid();

            ActionServer.CapNhatServer();
            dtLichSuTruyCap.ThemLichSu(Session["IDNhanVien"].ToString(), Session["IDNhom"].ToString(), "Quản trị nhóm người dùng:" + TenNhom, dtSetting.LayIDKho(), "Hệ Thống", "Cập Nhật"); 
        }
    }
}