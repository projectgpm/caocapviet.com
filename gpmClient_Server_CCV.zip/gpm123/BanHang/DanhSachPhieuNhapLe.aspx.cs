﻿using BanHang.Data;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace BanHang
{
    public partial class DanhSachPhieuNhapLe : System.Web.UI.Page
    {
        dtPhieuNhapLe data = new dtPhieuNhapLe();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["KTDangNhap"] != "GPM")
            {
                Response.Redirect("DangNhap.aspx");
            }
            else
            {
                if (dtSetting.LayTrangThaiMenu_ChucNang(Session["IDNhom"].ToString(), 13) == 1)
                    btnThemPhieuNhapLe.Enabled = false;
                if (dtSetting.LayTrangThaiMenu(Session["IDNhom"].ToString(), 13) == 1)
                {
                    LoadGrid();
                }
                else
                {
                    Response.Redirect("Default.aspx");
                }
            }
        }
        private void LoadGrid()
        {
            data = new dtPhieuNhapLe();
            gridPhieuNhapLe.DataSource = data.DanhSachPhieuNhapLe();
            gridPhieuNhapLe.DataBind();
        }

        protected void gridPhieuNhapLe_RowDeleting(object sender, DevExpress.Web.Data.ASPxDataDeletingEventArgs e)
        {
            int ID = Int32.Parse(e.Keys[0].ToString());
            data = new dtPhieuNhapLe();
            DataTable da = data.LayDanhSachChiTietPhieuNhapLe_ID(ID);
            if (da.Rows.Count != 0)
            {
                DataRow dr = da.Rows[0];
                int SoLuong = Int32.Parse(dr["SoLuong"].ToString());
                dtLichSuKho.ThemLichSu(ID, Int32.Parse(Session["IDNhanVien"].ToString()), SoLuong * (-1), "Xóa danh sách phoeeí nhập lẻ");
            }
            data.XoaPhieuNhapLe_ID(ID);
            e.Cancel = true;
            gridPhieuNhapLe.CancelEdit();
            LoadGrid();

            dtLichSuTruyCap.ThemLichSu(Session["IDNhanVien"].ToString(), Session["IDNhom"].ToString(), "Phiếu nhập lẻ: " +ID, dtSetting.LayIDKho(), "Nhập xuất tồn", "Xóa");
        }
    }
}