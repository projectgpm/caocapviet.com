﻿using BanHang.Data;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace BanHang
{
    public partial class DanhMucCombo : System.Web.UI.Page
    {
        dtHangCombo data = new dtHangCombo();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["KTDangNhap"] != "GPM")
            {
                Response.Redirect("DangNhap.aspx");
            }
            else
            {
                if (dtSetting.LayTrangThaiMenu_ChucNang(Session["IDNhom"].ToString(), 8) == 1)
                {
                    gridDanhMucCombo.Columns["iconaction"].Visible = false;
                    btnThemHangHoaComBo.Enabled = false;
                }
                if (dtSetting.LayTrangThaiMenu(Session["IDNhom"].ToString(), 8) == 1)
                {
                    LoadGrid();
                }
                else
                {
                    Response.Redirect("Default.aspx");
                }
            }
        }

        private void LoadGrid()
        {
            data = new dtHangCombo();
            gridDanhMucCombo.DataSource = data.DanhSachHangHoaCombo();
            gridDanhMucCombo.DataBind();
        }

        protected void gridDanhMucCombo_RowDeleting(object sender, DevExpress.Web.Data.ASPxDataDeletingEventArgs e)
        {
            int ID = Int32.Parse(e.Keys[0].ToString());
            data = new dtHangCombo();

            DataTable db1 = data.DanhSachHangHoaCombo_IDHangHoaComBo(ID);
            if (db1.Rows.Count != 0)
            {
                int SLTon = dtCapNhatTonKho.SoLuongTonKho_Client(ID, dtSetting.LayIDKho());
                foreach (DataRow dr1 in db1.Rows)
                {
                    int IDHangHoa = Int32.Parse(dr1["IDHangHoa"].ToString());
                    int SoLuong = Int32.Parse(dr1["SoLuong"].ToString());
                    dtCapNhatTonKho tk = new dtCapNhatTonKho();
                    tk.CongTonKho_IDHangHoa(IDHangHoa, SoLuong * SLTon, dtSetting.LayIDKho());
                }

                data = new dtHangCombo();
                data.XoaHangHoa(ID);
                data.XoaHangHoa_IDHangCombo(ID);
                dtHangHoa hh = new dtHangHoa();
                hh.XoaBarCode(ID);
                e.Cancel = true;
                gridDanhMucCombo.CancelEdit();
                LoadGrid();

               
                dtLichSuTruyCap.ThemLichSu(Session["IDNhanVien"].ToString(), Session["IDNhom"].ToString(), "Danh Mục Combo:" + ID, dtSetting.LayIDKho(), "Danh Mục", "Xóa");  
            }

            ActionServer.CapNhatServer();
        }

        protected void gridDanhMucCombo_RowUpdating(object sender, DevExpress.Web.Data.ASPxDataUpdatingEventArgs e)
        {
            int ID = Int32.Parse(e.Keys[0].ToString());
            string TenHangHoa = e.NewValues["TenHangHoa"].ToString();
            if (e.NewValues["TenHangHoa"] != null)
            {
                string IDMaHang = e.NewValues["MaHang"].ToString();
                dtImportHangHoa hh = new dtImportHangHoa();
                DataTable dta = hh.KiemTraHangHoa(IDMaHang);
                if (dta.Rows.Count != 0)
                {
                    int IDDonViTinh = Int32.Parse(e.NewValues["IDDonViTinh"].ToString());
                    float GiaBan = float.Parse(e.NewValues["GiaBan1"].ToString());
                    data = new dtHangCombo();
                    data.SuaThongTinHangHoa(ID, TenHangHoa, IDDonViTinh, GiaBan, IDMaHang);
                    e.Cancel = true;
                    gridDanhMucCombo.CancelEdit();
                    LoadGrid();
                    dtLichSuTruyCap.ThemLichSu(Session["IDNhanVien"].ToString(), Session["IDNhom"].ToString(), "Danh Mục Combo:" + TenHangHoa, dtSetting.LayIDKho(), "Danh Mục", "Cập Nhật");

                }
                else throw new Exception("Mã hàng đã tồn tại.");
            }
            else
            {
                throw new Exception("Lỗi: Vui lòng nhập Tên hàng hóa");
            }

            ActionServer.CapNhatServer();
        }
    }
}