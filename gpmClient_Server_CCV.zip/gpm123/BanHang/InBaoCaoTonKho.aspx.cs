﻿using BanHang.Data;
using BanHang.Report;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace BanHang
{
    public partial class InBaoCaoTonKho : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            dtThongTinCuaHangKho dt = new dtThongTinCuaHangKho();
            DataTable da = dt.LayDanhSach_ID_2(dtSetting.LayIDKho());
            DataRow dr = da.Rows[0];
            string strCty = dr["TenCuaHang"].ToString();

            int idNganh = Int32.Parse(Request.QueryString["nganh"]);
            int idNhom = Int32.Parse(Request.QueryString["nhom"]);
            int idKho = Int32.Parse(Request.QueryString["khohang"]);

            string strNganh = "Tất cả ngành hàng", strNhom = "Tất cả nhóm hàng", strKho = "Tất cả kho hàng";

            if (idNganh != -1)
            {
                dtNganhHang d = new dtNganhHang();
                da = d.LayDanhSachNganhHang_ID(idNganh);
                if (da.Rows.Count != 0)
                {
                    dr = da.Rows[0];
                    strNganh = dr["TenNganhHang"].ToString();
                }
            }
            if (idNhom != -1)
            {
                dtNhomHang d = new dtNhomHang();
                da = d.LayDanhSachNhomHang_ID(idNhom);
                if (da.Rows.Count != 0)
                {
                    dr = da.Rows[0];
                    strNhom = dr["TenNhomHang"].ToString();
                }
            }
            if (idKho != -1)
            {
                dtThongTinCuaHangKho d = new dtThongTinCuaHangKho();
                da = d.LayDanhSach_ID_2(idKho);
                if (da.Rows.Count != 0)
                {
                    dr = da.Rows[0];
                    strKho = dr["TenCuaHang"].ToString();
                }
            }




            rpBaoCaoTonKho rp = new rpBaoCaoTonKho();
 
            rp.Parameters["NganhHang"].Value = idNganh;
            rp.Parameters["NhomHang"].Value = idNhom;
            rp.Parameters["KhoHang"].Value = idKho;

            rp.Parameters["NganhHang"].Visible = false;
            rp.Parameters["NhomHang"].Visible = false;
            rp.Parameters["KhoHang"].Visible = false;

            rp.Parameters["strCty"].Value = strCty;
            rp.Parameters["strNganh"].Value = strNganh;
            rp.Parameters["strNhom"].Value = strNhom;
            rp.Parameters["strKho"].Value = strKho;

            rp.Parameters["strCty"].Visible = false;
            rp.Parameters["strNganh"].Visible = false;
            rp.Parameters["strNhom"].Visible = false;
            rp.Parameters["strKho"].Visible = false;

            reportView.Report = rp;
        }
    }
}