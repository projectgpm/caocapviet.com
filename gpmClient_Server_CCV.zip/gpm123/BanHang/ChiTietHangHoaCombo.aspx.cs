﻿using BanHang.Data;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace BanHang
{
    public partial class ChiTietHangHoaCombo : System.Web.UI.Page
    {
        dtHangCombo data = new dtHangCombo();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["KTDangNhap"] == "GPM")
            {
                string IDHangHoaComBo = Request.QueryString["IDHangHoaComBo"];
                if (IDHangHoaComBo != null)
                {

                    LoadGrid(Int32.Parse(IDHangHoaComBo.ToString()));
                }
            }
            else
            {
                Response.Redirect("DangNhap.aspx");
            }
        }

        private void LoadGrid(int IDHangHoaComBo)
        {

            data = new dtHangCombo();
            gridChiTietHangHoaCombo.DataSource = data.DanhSachHangHoaCombo_IDHangHoaComBo(IDHangHoaComBo);
            gridChiTietHangHoaCombo.DataBind();
        }

        protected void gridChiTietPhieuNhapSi_RowDeleting(object sender, DevExpress.Web.Data.ASPxDataDeletingEventArgs e)
        {
            int ID = Int32.Parse(e.Keys[0].ToString());
            data = new dtHangCombo();
           
            DataTable dt = data.DanhSachHangHoaCombo_ID(ID);
            DataRow dr = dt.Rows[0];
            int IDHangHoa = Int32.Parse(dr["IDHangHoa"].ToString());
            int SLCu = Int32.Parse(dr["SoLuong"].ToString());
            dtCapNhatTonKho tk = new dtCapNhatTonKho();
            tk.CongTonKho_IDHangHoa(IDHangHoa, SLCu,dtSetting.LayIDKho());
            data.XoaHangHoa_ID(ID);
            e.Cancel = true;
            gridChiTietHangHoaCombo.CancelEdit();
            string IDHangHoaComBo = Request.QueryString["IDHangHoaComBo"];
            LoadGrid(Int32.Parse(IDHangHoaComBo.ToString()));

            ActionServer.CapNhatServer();
            dtLichSuTruyCap.ThemLichSu(Session["IDNhanVien"].ToString(), Session["IDNhom"].ToString(), "Chi Tiết Hàng Hóa Combo:" + ID, dtSetting.LayIDKho(), "Danh Mục", "Xóa");    
        }

        protected void gridChiTietPhieuNhapSi_RowUpdating(object sender, DevExpress.Web.Data.ASPxDataUpdatingEventArgs e)
        {
            int SoLuong = Int32.Parse(e.NewValues["SoLuong"].ToString());
            string IDHangHoaComBo = Request.QueryString["IDHangHoaComBo"];
            if (SoLuong > 0)
            {
                int ID = Int32.Parse(e.Keys[0].ToString());
                data = new dtHangCombo();
                DataTable dt = data.DanhSachHangHoaCombo_ID(ID);
                DataRow dr = dt.Rows[0];
                float GiaBan = float.Parse(dr["GiaBan"].ToString());
                //int SoLuong = Int32.Parse(e.NewValues["SoLuong"].ToString());
                int IDHangHoa = Int32.Parse(dr["IDHangHoa"].ToString());
                int SLCu = Int32.Parse(dr["SoLuong"].ToString());
                data = new dtHangCombo();
                data.CapNhatHangHoa_Combo(ID, SoLuong, SoLuong * GiaBan);
                dtCapNhatTonKho tk = new dtCapNhatTonKho();
                tk.CongTonKho_IDHangHoa(IDHangHoa, SLCu - SoLuong,dtSetting.LayIDKho());
                e.Cancel = true;
                gridChiTietHangHoaCombo.CancelEdit();
                LoadGrid(Int32.Parse(IDHangHoaComBo.ToString()));
                dtLichSuTruyCap.ThemLichSu(Session["IDNhanVien"].ToString(), Session["IDNhom"].ToString(), "Chi Tiết Hàng Hóa Combo:" + ID, dtSetting.LayIDKho(), "Danh Mục", "Cập Nhật");   
            }
            else
            {
                throw new Exception("Lỗi: Vui lòng nhập số lượng > 0");
            }

            ActionServer.CapNhatServer();
        }
    }
}