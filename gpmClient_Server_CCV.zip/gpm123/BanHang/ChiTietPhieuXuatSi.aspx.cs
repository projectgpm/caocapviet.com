﻿using BanHang.Data;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace BanHang
{
    public partial class ChiTietPhieuXuatSi : System.Web.UI.Page
    {
        dtPhieuXuatSi data = new dtPhieuXuatSi();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["KTDangNhap"] == "GPM")
            {
                string IDPhieuXuatSi = Request.QueryString["IDPhieuXuatSi"];
                if (IDPhieuXuatSi != null)
                {

                    LoadGrid(Int32.Parse(IDPhieuXuatSi.ToString()));
                }
            }
            else
            {
                Response.Redirect("DangNhap.aspx");
            }
        }

        private void LoadGrid(int IDPhieuXuatSi)
        {
            data = new dtPhieuXuatSi();
            gridChiTietPhieuXuatSi.DataSource = data.DanhSachChiTietPhieuXuatSi_ID(IDPhieuXuatSi);
            gridChiTietPhieuXuatSi.DataBind();
        }

        protected void gridChiTietPhieuXuatSi_RowUpdating(object sender, DevExpress.Web.Data.ASPxDataUpdatingEventArgs e)
        {
            string IDPhieuXuatSi = Request.QueryString["IDPhieuXuatSi"];
            if (IDPhieuXuatSi != null)
            {
                int ID = Int32.Parse(e.Keys[0].ToString());
                data = new dtPhieuXuatSi();
                DataTable db = data.LayDanhSachChiTietPhieuXuatSi_ID(ID);
                if (db.Rows.Count != 0)
                {
                    int SoLuong = Int32.Parse(e.NewValues["SoLuong"].ToString());
                    float DonGia = float.Parse(e.NewValues["DonGia"].ToString());
                    DataRow dr1 = db.Rows[0];

                    int IDHangHoa = Int32.Parse(dr1["IDHangHoa"].ToString());
                    int SLCu = Int32.Parse(dr1["SoLuong"].ToString());

                    data = new dtPhieuXuatSi();
                    DataTable tb = data.DanhSachChiTietPhieuXuatSi_ID(Int32.Parse(IDPhieuXuatSi.ToString()));

                    data = new dtPhieuXuatSi();
                    data.CapNhatChiTietPhieuXuatSi_ID(ID, SoLuong, DonGia, (SoLuong * DonGia));
                    dtCapNhatTonKho tk = new dtCapNhatTonKho();

                    dtLichSuKho.ThemLichSu(IDHangHoa, Int32.Parse(Session["IDNhanVien"].ToString()), SoLuong - SLCu, "Cập nhật chi tiết phiếu xuất sỉ");
                    
                    tk.TruTonKho_IDHangHoa(IDHangHoa, SoLuong - SLCu, dtSetting.LayIDKho());

                    if (tb.Rows.Count != 0)
                    {
                        

                        float TongTien = 0;
                        foreach (DataRow dr4 in tb.Rows)
                        {
                            float txtThanhTien = float.Parse(dr4["ThanhTien"].ToString());
                            TongTien = TongTien + txtThanhTien;
                        }
                        data = new dtPhieuXuatSi();
                        data.CapNhatTongTienPhieuXuatSi_ID(Int32.Parse(IDPhieuXuatSi.ToString()), TongTien);//cập nhật tổng tiền
                    }
                   
                    e.Cancel = true;
                    gridChiTietPhieuXuatSi.CancelEdit();
                    LoadGrid(Int32.Parse(IDPhieuXuatSi.ToString()));

                    dtLichSuTruyCap.ThemLichSu(Session["IDNhanVien"].ToString(), Session["IDNhom"].ToString(), "Chi Tiết Phiếu Xuất Sỉ", dtSetting.LayIDKho(), "Nhập xuất tồn", "Cập Nhật");  
                }
            }
        }
    }
}