﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using BanHang.Data;
using System.IO;

namespace BanHang
{
    public partial class MaHang : System.Web.UI.Page
    {
        dtMaHang data = new dtMaHang();
        protected void Page_Load(object sender, EventArgs e)
        {
            LoadGrid();

        }
        public void LoadGrid()
        {
            //data = new dtMaHang();
            //gridMaHang.DataSource = data.LayDanhSachMaHang();
            //gridMaHang.DataBind();
        }

        protected void gridMaHang_RowInserting(object sender, DevExpress.Web.Data.ASPxDataInsertingEventArgs e)
        {
            DateTime NgayCapNhat = DateTime.Today.Date;
            data = new dtMaHang();
            string MaHang = e.NewValues["MaHang"].ToString();
            string IDDonViTinh = e.NewValues["IDDonViTinh"].ToString();
            string TenMaHang = e.NewValues["TenMaHang"].ToString();
            string IDTenNhomHang = e.NewValues["IDNhomHang"].ToString();
            data.ThemMaHang(MaHang, Int32.Parse(IDDonViTinh), Int32.Parse(IDTenNhomHang), TenMaHang, NgayCapNhat);
            e.Cancel = true;
            gridMaHang.CancelEdit();
            LoadGrid();

            ActionServer.CapNhatServer();
        }

        protected void gridMaHang_RowUpdating(object sender, DevExpress.Web.Data.ASPxDataUpdatingEventArgs e)
        {
            string ID = e.Keys["ID"].ToString();
            string MaHang = e.NewValues["MaHang"].ToString();
            string IDDonViTinh = e.NewValues["IDDonViTinh"].ToString();
            string TenMaHang = e.NewValues["TenMaHang"].ToString();
            string IDTenNhomHang = e.NewValues["IDNhomHang"].ToString();
            DateTime NgayCapNhat = DateTime.Today.Date;
            data.SuaThongTinMaHang(Int32.Parse(ID), MaHang, Int32.Parse(IDDonViTinh), Int32.Parse(IDTenNhomHang), TenMaHang, NgayCapNhat);
            e.Cancel = true;
            gridMaHang.CancelEdit();
            LoadGrid();

            ActionServer.CapNhatServer();
        }

        protected void gridMaHang_RowDeleting(object sender, DevExpress.Web.Data.ASPxDataDeletingEventArgs e)
        {
            string ID = e.Keys[0].ToString();
            data = new dtMaHang();
            data.XoaMaHang(Int32.Parse(ID));
            e.Cancel = true;
            gridMaHang.CancelEdit();
            LoadGrid();

            ActionServer.CapNhatServer();
        }

        protected void btnXuatExcel_Click(object sender, EventArgs e)
        {
            GridExporter1.WriteXlsToResponse();
        }

        protected void btnXuatPDF_Click(object sender, EventArgs e)
        {
            GridExporter1.WritePdfToResponse();
        }

        protected void btnNhapExcel_Click(object sender, EventArgs e)
        {
            Response.Redirect("ImportExcel_MaHang.aspx");
        }

    }
}