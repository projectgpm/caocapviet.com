﻿using BanHang.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace BanHang
{
    public partial class DanhMucTinhThue : System.Web.UI.Page
    {
        dtDanhMucTinhThue data = new dtDanhMucTinhThue();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (dtSetting.LayTrangThaiMenu_ChucNang(Session["IDNhom"].ToString(), 5) == 1)
                gridDanhMucTinhThue.Columns["iconaction"].Visible = false;

            if (dtSetting.LayTrangThaiMenu(Session["IDNhom"].ToString(), 5) == 1)
            {
                LoadGrid();
            }
            else
            {
                Response.Redirect("Default.aspx");
            }
        }

        private void LoadGrid()
        {
            data = new dtDanhMucTinhThue();
            gridDanhMucTinhThue.DataSource = data.LayDanhSachDanhMucTinhThue();
            gridDanhMucTinhThue.DataBind();

        }

        protected void gridDanhMucTinhThue_RowDeleting(object sender, DevExpress.Web.Data.ASPxDataDeletingEventArgs e)
        {
            string ID = e.Keys[0].ToString();
            data = new dtDanhMucTinhThue();
            data.XoaDanhMucTinhThue(Int32.Parse(ID));
            e.Cancel = true;
            gridDanhMucTinhThue.CancelEdit();
            LoadGrid();

            ActionServer.CapNhatServer();
            dtLichSuTruyCap.ThemLichSu(Session["IDNhanVien"].ToString(), Session["IDNhom"].ToString(), "Danh mục tính thuế:" + ID, dtSetting.LayIDKho(), "Danh Mục", "Xóa");
        }

        protected void gridDanhMucTinhThue_RowInserting(object sender, DevExpress.Web.Data.ASPxDataInsertingEventArgs e)
        {
            string Ten = e.NewValues["Ten"].ToString();
            DateTime NgayCapNhat = DateTime.Today.Date;
            data = new dtDanhMucTinhThue();
            data.ThemDanhMucTinhThue(Ten, NgayCapNhat);
            e.Cancel = true;
            gridDanhMucTinhThue.CancelEdit();
            LoadGrid();

            ActionServer.CapNhatServer();
            dtLichSuTruyCap.ThemLichSu(Session["IDNhanVien"].ToString(), Session["IDNhom"].ToString(), "Danh mục tính thuế:" + Ten, dtSetting.LayIDKho(), "Danh Mục", "Thêm");
        }

        protected void gridDanhMucTinhThue_RowUpdating(object sender, DevExpress.Web.Data.ASPxDataUpdatingEventArgs e)
        {
            string ID = e.Keys["ID"].ToString();
            string Ten = e.NewValues["Ten"].ToString();
            DateTime NgayCapNhat = DateTime.Today.Date;
            data.SuaDanhMucTinhThue(Int32.Parse(ID), Ten, NgayCapNhat);
            e.Cancel = true;
            gridDanhMucTinhThue.CancelEdit();
            LoadGrid();

            ActionServer.CapNhatServer();
            dtLichSuTruyCap.ThemLichSu(Session["IDNhanVien"].ToString(), Session["IDNhom"].ToString(), "Danh mục tính thuế:" + Ten, dtSetting.LayIDKho(), "Danh Mục", "Cập Nhật");
        }
    }
}