﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using BanHang.Data;
using DevExpress.Web;

namespace BanHang
{
    public partial class NganhHang : System.Web.UI.Page
    {
        dataNganhHang da = new dataNganhHang();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["KTDangNhap"] != "GPM")
            {
                Response.Redirect("DangNhap.aspx");
            }
            else
            {
                if (dtSetting.LayTrangThaiMenu_ChucNang(Session["IDNhom"].ToString(), 5) == 1)
                    gridNganhHang.Columns["iconaction"].Visible = false;

                if (dtSetting.LayTrangThaiMenu(Session["IDNhom"].ToString(), 5) == 1)
                {
                    LoadGrid();
                }
                else
                {
                    Response.Redirect("Default.aspx");
                }

            }
        }
        public void LoadGrid()
        {
            gridNganhHang.DataSource = da.getDanhSachNganhHang();
            gridNganhHang.DataBind();
        }


        protected void gridNganhHang_RowDeleting(object sender, DevExpress.Web.Data.ASPxDataDeletingEventArgs e)
        {
            string ID = e.Keys[0].ToString();
            da.XoaNganhHang(Int32.Parse(ID));
            e.Cancel = true;
            gridNganhHang.CancelEdit();
            LoadGrid();

            ActionServer.CapNhatServer();
            dtLichSuTruyCap.ThemLichSu(Session["IDNhanVien"].ToString(), Session["IDNhom"].ToString(), "Ngành Hàng", dtSetting.LayIDKho(), "Ngành Hàng", "Xóa ID = " + ID); 
        }

        protected void gridNganhHang_RowUpdating(object sender, DevExpress.Web.Data.ASPxDataUpdatingEventArgs e)
        {
            string ID = e.Keys["ID"].ToString();
            string s = e.NewValues["TenNganhHang"].ToString();
            s = dtSetting.convertDauSangKhongDau(s);
            s.ToUpper();

            da.updateNganhHang(Int32.Parse(ID), e.NewValues["MaNganh"].ToString(), s, e.NewValues["GhiChu"] != null ? e.NewValues["GhiChu"].ToString() : "");
            e.Cancel = true;
            gridNganhHang.CancelEdit();
            LoadGrid();

            ActionServer.CapNhatServer();
            dtLichSuTruyCap.ThemLichSu(Session["IDNhanVien"].ToString(), Session["IDNhom"].ToString(), "Ngành Hàng", dtSetting.LayIDKho(), "Ngành Hàng", "Cập Nhật ID = " + ID); 
        }

        protected void gridNganhHang_RowInserting(object sender, DevExpress.Web.Data.ASPxDataInsertingEventArgs e)
        {
            string s = e.NewValues["TenNganhHang"].ToString();
            s = dtSetting.convertDauSangKhongDau(s);
            s.ToUpper();
            da.insertNganhHang(e.NewValues["MaNganh"].ToString(), s, e.NewValues["GhiChu"] != null ? e.NewValues["GhiChu"].ToString() : "");
            e.Cancel = true;
            gridNganhHang.CancelEdit();
            LoadGrid();

            ActionServer.CapNhatServer();
            dtLichSuTruyCap.ThemLichSu(Session["IDNhanVien"].ToString(), Session["IDNhom"].ToString(), "Ngành Hàng", dtSetting.LayIDKho(), "Ngành Hàng", "Thêm: " + s); 
        }

    }
}