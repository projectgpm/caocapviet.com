﻿using BanHang.Data;
using BanHang.Report;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace BanHang
{
    public partial class InBangKePhieuXuatTra : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

            int idKhohang = Int32.Parse(Request.QueryString["khohang"]);
            int idNhaCC = Int32.Parse(Request.QueryString["nhacc"]);
            string strCty = "", strKho = "Tất cả kho", strNhaCC = "Tất cả nhà cung cấp";

            dtThongTinCuaHangKho dt = new dtThongTinCuaHangKho();
            DataTable da = dt.LayDanhSach_ID_2(dtSetting.LayIDKho());
            DataRow dr = da.Rows[0];
            strCty = dr["TenCuaHang"].ToString();

            if (idKhohang != -1)
            {
                dtThongTinCuaHangKho d1 = new dtThongTinCuaHangKho();
                da = d1.LayDanhSach_ID_2(idKhohang);
                if (da.Rows.Count != 0)
                {
                    dr = da.Rows[0];
                    strKho = dr["TenCuaHang"].ToString();
                }
            }
            if (idNhaCC != -1)
            {
                dtNhaCungCap d1 = new dtNhaCungCap();
                da = d1.LayDanhSachNhaCungCap_ID(idNhaCC);
                if (da.Rows.Count != 0)
                {
                    dr = da.Rows[0];
                    strNhaCC = dr["TenNhaCungCap"].ToString();
                }
            }



            rpBangKePhieuXuatTra rp = new rpBangKePhieuXuatTra();
            rp.Parameters["strCty"].Value = strCty;
            rp.Parameters["strKho"].Value = strKho;
            rp.Parameters["strNhaCC"].Value = strNhaCC;
            rp.Parameters["strCty"].Visible = false;
            rp.Parameters["strKho"].Visible = false;
            rp.Parameters["strNhaCC"].Visible = false;

            rp.Parameters["KhoHang"].Value = idKhohang;
            rp.Parameters["NhaCC"].Value = idNhaCC;
            rp.Parameters["KhoHang"].Visible = false;
            rp.Parameters["NhaCC"].Visible = false;

            rp.Parameters["NgayBD"].Value = Request.QueryString["ngaybd"] + " 00:00:00.000";
            rp.Parameters["NgayBD"].Visible = false;
            rp.Parameters["NgayKT"].Value = Request.QueryString["ngaykt"] + " 23:59:59.000";
            rp.Parameters["NgayKT"].Visible = false;
            DateTime d = DateTime.Parse(Request.QueryString["ngaybd"]);
            string s = d.Date.ToString("dd/MM/yyyy");
            DateTime d2 = DateTime.Parse(Request.QueryString["ngaykt"]);
            string s2 = d2.Date.ToString("dd/MM/yyyy");
            rp.Parameters["strNgay"].Value = s + " - " + s2;
            rp.Parameters["strNgay"].Visible = false;
            reportView.Report = rp;
        }
    }
}