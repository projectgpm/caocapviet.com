﻿using BanHang.Data;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace BanHang
{
    public partial class DuyetHangServer : System.Web.UI.Page
    {
        dtDuyetDonHangServer data = new dtDuyetDonHangServer();
        dtDonHangChuaDuyet data1 = new dtDonHangChuaDuyet();
        private int VisibleIndexHere;
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["KTDangNhap"] != "GPM")
            {
                Response.Redirect("DangNhap.aspx");
            }
            else
            {
                if (dtSetting.LayTrangThaiMenu_ChucNang(Session["IDNhom"].ToString(), 16) == 1)
                    gridDanhSachDonHangChoDuyet.Columns["chucnang"].Visible = false;
                if (dtSetting.LayTrangThaiMenu(Session["IDNhom"].ToString(), 16) == 1)
                {
                    LoadGrid();
                }
                else
                {
                    Response.Redirect("Default.aspx");
                }
            }
        }

        private void LoadGrid()
        {
            data = new dtDuyetDonHangServer();
            gridDanhSachDonHangChoDuyet.DataSource = data.LayDanhSach();
            gridDanhSachDonHangChoDuyet.DataBind();
        }

        protected void gridDanhSachDonHangChoDuyet_RowDeleting(object sender, DevExpress.Web.Data.ASPxDataDeletingEventArgs e)
        {
            int ID = Int32.Parse(e.Keys[0].ToString());
            data1 = new dtDonHangChuaDuyet();
            data1.XoaDonHang(ID);
            e.Cancel = true;
            gridDanhSachDonHangChoDuyet.CancelEdit();
            LoadGrid();

            dtLichSuTruyCap.ThemLichSu(Session["IDNhanVien"].ToString(), Session["IDNhom"].ToString(), "Duyệt Hàng:" + ID, dtSetting.LayIDKho(), "Danh Mục", "Xóa"); 
        }

        protected void gridDanhSachDonHangChoDuyet_CustomButtonCallback(object sender, DevExpress.Web.ASPxGridViewCustomButtonCallbackEventArgs e)
        {
            if (e.ButtonID == "DuyetDonHang")
            {
                int ID = Int32.Parse(gridDanhSachDonHangChoDuyet.GetRowValues(VisibleIndexHere, gridDanhSachDonHangChoDuyet.KeyFieldName).ToString());
                data = new dtDuyetDonHangServer();
                dtChiTietDonDatHang da = new dtChiTietDonDatHang();
                DataTable dta = da.LayDanhSachChiTietDonDatHang_IDDonDatHang(ID);
                if (dta.Rows.Count != 0)
                {
                    for (int i = 0; i < dta.Rows.Count; i++)
                    {
                        DataRow dr = dta.Rows[i];
                        int IDHangHoa = Int32.Parse(dr["IDHangHoa"].ToString());
                        int SoLuong = Int32.Parse(dr["SoLuong"].ToString());
                        dtCapNhatTonKho tk = new dtCapNhatTonKho();
                        dtLichSuKho.ThemLichSu(IDHangHoa, Int32.Parse(Session["IDNhanVien"].ToString()), SoLuong, "Duyệt đơn hàng: " + ID );
                        tk.TruTonKho_IDHangHoa(IDHangHoa, SoLuong, dtSetting.LayIDKho());
                    }
                    // trừ tồn kho
                    data.DuyetDonHang(ID);
                    LoadGrid();
                }
            }
            
        }
    }
}