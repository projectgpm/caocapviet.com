﻿using BanHang.Data;
using DevExpress.Web;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.OleDb;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace BanHang
{
    public partial class ThemDonHang : System.Web.UI.Page
    {
        dtThemDonHang data = new dtThemDonHang();
        protected void Page_Load(object sender, EventArgs e)
        {
            if(!IsPostBack)
            {
                data = new dtThemDonHang();
                data.XoaChiTietDonHang_Temp();
                txtIDKho.Enabled = false;
                int IDKho = dtSetting.LayIDKho();
                txtIDKho.Text = IDKho + "";

            }
            LoadGrid();
           
        }
        protected void ASPxFormLayoutNgayLapPhieu_Init(object sender, EventArgs e)
        {
            ASPxFormLayoutNgayLapPhieu.Date = DateTime.Today;
        }
        protected void ASPxFormLayoutThemTemp_Click(object sender, EventArgs e)
        {
            if (ASPxFormLayoutIDHangHoa.Value != null)
            {
                int IDHangHoa = Int32.Parse(ASPxFormLayoutIDHangHoa.Value.ToString());
                string Thue = ASPxFormLayoutThue.Value == null ? "4" : ASPxFormLayoutThue.Value.ToString();
                int IDThue = Int32.Parse(Thue + "");
                int SoLuong = Int32.Parse(ASPxFormLayoutSoLuong.Value.ToString());
                float DonGia = float.Parse(ASPxFormLayoutDonGia.Value.ToString());
                float TienChuaThue = float.Parse(ASPxFormLayoutTienChuaThue.Value.ToString());
                float TienVAT = float.Parse(ASPxFormLayoutVAT.Value.ToString());
                float ThanhTien = float.Parse(ASPxFormLayoutThanhTien.Value.ToString());

                DataTable db = data.KTChiTietDonHang_Temp(IDHangHoa);// kiểm tra hàng hóa
                if (db.Rows.Count == 0)
                {
                    data = new dtThemDonHang();
                    data.ThemChiTietDonHang_Temp(IDHangHoa, IDThue, SoLuong, DonGia, TienChuaThue, TienVAT, ThanhTien);
                    Clear();
                }
                else
                {
                    data = new dtThemDonHang();
                    data.UpdateChiTietDonHang_temp(IDHangHoa, IDThue, SoLuong, DonGia, TienChuaThue, TienVAT, ThanhTien);
                    Clear();
                }
                LoadGrid();
            }
            else
            {
                Response.Write("<script language='JavaScript'> alert('Bạn chưa chọn hàng hóa.'); </script>");
            }
        }

        private void LoadGrid()
        {
            data = new dtThemDonHang();
            GridViewDanhSachHangHoa_Temp.DataSource = data.LayDanhSachChiTietDonHang_Temp();
            GridViewDanhSachHangHoa_Temp.DataBind();

        }


        protected void ASPxFormLayoutIDHangHoa_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (ASPxFormLayoutIDHangHoa.Text != "")
            {
                data = new dtThemDonHang();
                DataTable dt = data.LayThongTinHangHoa(Int32.Parse(ASPxFormLayoutIDHangHoa.Value.ToString()));
                ASPxFormLayoutSoLuong.Text = "0";
                int SoLuong = Int32.Parse(ASPxFormLayoutSoLuong.Value.ToString());
                foreach (DataRow item in dt.Rows)
                {
                    ASPxFormLayoutDonGia.Text = item["GiaMua"].ToString();
                    int DonGia = Int32.Parse(ASPxFormLayoutDonGia.Value.ToString());
                    ASPxFormLayoutThanhTien.Text = (SoLuong * DonGia).ToString();
                    ASPxFormLayoutTienChuaThue.Text = item["GiaMua"].ToString();
                    ASPxFormLayoutThue.Text = "";
                    ASPxFormLayoutVAT.Text = "0";
                }
            }
        }

      
        protected void ASPxFormLayoutSoLuong_NumberChanged(object sender, EventArgs e)
        {

            if (ASPxFormLayoutIDHangHoa.Text != "")
            {
                if (dtSetting.KT_SoLuong() == 0)
                {
                    data = new dtThemDonHang();
                    DataTable db = data.LayThongTinHangHoa(Int32.Parse(ASPxFormLayoutIDHangHoa.Value.ToString()));
                    if (db.Rows.Count != 0)
                    {
                        DataRow dr = db.Rows[0];
                        double DonGia = double.Parse(dr["GiaMua"].ToString());
                        int SoLuong = Int32.Parse(ASPxFormLayoutSoLuong.Text.ToString());
                        ASPxFormLayoutThanhTien.Text = (SoLuong * DonGia).ToString();
                        ASPxFormLayoutTienChuaThue.Text = (SoLuong * DonGia).ToString();
                        LoadDanhSach(SoLuong);

                    }
                }
                else
                {
                    data = new dtThemDonHang();
                    DataTable db = data.LayThongTinHangHoa(Int32.Parse(ASPxFormLayoutIDHangHoa.Value.ToString()));
                    dtChiTietDonDatHang data1 = new dtChiTietDonDatHang();
                    // DataTable db1 = data1.LayThongTinHangHoaTonKho(ASPxFormLayoutIDHangHoa.SelectedIndex + 1);
                    if (db.Rows.Count != 0)
                    {
                        int DonGia = Int32.Parse(ASPxFormLayoutDonGia.Value.ToString());
                        DataRow dr = db.Rows[0];
                        int SoLuongCon = dtCapNhatTonKho.SoLuongTonKho_Server(Int32.Parse(ASPxFormLayoutIDHangHoa.Value.ToString()));

                        int SoLuongMua = Int32.Parse(ASPxFormLayoutSoLuong.Text.ToString());
                        if (SoLuongMua > SoLuongCon)
                        {
                            ASPxFormLayoutSoLuong.Text = SoLuongCon + "";
                            ASPxFormLayoutThanhTien.Text = (SoLuongCon * DonGia).ToString();
                            ASPxFormLayoutTienChuaThue.Text = (SoLuongCon * DonGia).ToString();
                            LoadDanhSach(SoLuongCon);
                            Response.Write("<script language='JavaScript'> alert('Số hàng trên kho tổng không đủ.'); </script>");
                        }
                        else
                        {
                            int SoLuong = Int32.Parse(ASPxFormLayoutSoLuong.Text.ToString());
                            ASPxFormLayoutThanhTien.Text = (SoLuong * DonGia).ToString();
                            ASPxFormLayoutTienChuaThue.Text = (SoLuong * DonGia).ToString();
                            LoadDanhSach(SoLuong);
                        }
                    }
                }
            }
        }

       

        protected void ASPxFormLayoutThue_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (ASPxFormLayoutIDHangHoa.Text != "")
            {
                data = new dtThemDonHang();
                DataTable db = data.LayThongTinHangHoa(Int32.Parse(ASPxFormLayoutIDHangHoa.Value.ToString()));
                if (db.Rows.Count != 0)
                {
                    LoadDanhSach(Int32.Parse(ASPxFormLayoutSoLuong.Value.ToString()));
                }
            }
            
        }
        public void LoadDanhSach(int SoLuong)
        {
            if (ASPxFormLayoutThue.Text != "")
            {
                data = new dtThemDonHang();
                DataTable dt = data.LayThongTinVAT(Int32.Parse(ASPxFormLayoutThue.Value.ToString()));
                if (dt.Rows.Count != 0)
                {
                    DataRow dr = dt.Rows[0];
                    double txtGiaTri = double.Parse(dr["GiaTri"].ToString());
                    int txtCALCU = Int32.Parse(dr["IDThue_CALCU"].ToString());
                    if (txtCALCU == 1)
                    {
                        double DonGia = double.Parse(ASPxFormLayoutDonGia.Value.ToString());
                        double TienThue = double.Parse(txtGiaTri.ToString());
                        ASPxFormLayoutTienChuaThue.Text = SoLuong * Math.Round((DonGia / (1 + (TienThue / 100)))) + "";
                        ASPxFormLayoutVAT.Text = SoLuong * (DonGia - Math.Round((DonGia / (1 + (TienThue / 100))))) + "";
                        ASPxFormLayoutThanhTien.Text = SoLuong * DonGia + "";
                    }
                    else if (txtCALCU == 2)
                    {
                        double DonGia = double.Parse(ASPxFormLayoutDonGia.Value.ToString());
                        ASPxFormLayoutTienChuaThue.Text = (SoLuong * DonGia).ToString();
                        double TienThue = double.Parse(txtGiaTri.ToString());
                        ASPxFormLayoutVAT.Text = (SoLuong * DonGia * (TienThue / 100)).ToString();
                        ASPxFormLayoutThanhTien.Text = (SoLuong * (DonGia + (DonGia * (TienThue / 100)))).ToString();
                    }

                }
            }
        }
        public void Clear()
        {
            ASPxFormLayoutIDHangHoa.Text = "";
            ASPxFormLayoutThue.Text = "";
            ASPxFormLayoutSoLuong.Text = "";
            ASPxFormLayoutDonGia.Text = "";
            ASPxFormLayoutTienChuaThue.Text = "";
            ASPxFormLayoutVAT.Text = "";
            ASPxFormLayoutThanhTien.Text = "";
        }
        protected void ASPxFormLayoutHuyDonDatHang_Click(object sender, EventArgs e)
        {
            data = new dtThemDonHang();
            data.XoaChiTietDonHang_Temp();
            Response.Redirect("DanhSachDonHang.aspx");
        }

        protected void GridViewDanhSachHangHoa_Temp_RowUpdating(object sender, DevExpress.Web.Data.ASPxDataUpdatingEventArgs e)
        {

        }

        protected void GridViewDanhSachHangHoa_Temp_RowDeleting(object sender, DevExpress.Web.Data.ASPxDataDeletingEventArgs e)
        {
            int ID = Int32.Parse(e.Keys[0].ToString());
            data = new dtThemDonHang();
            data.XoaChiTietDonHang_Temp_ID(ID);
            e.Cancel = true;
            GridViewDanhSachHangHoa_Temp.CancelEdit();
            LoadGrid();
        }
        

        protected void ASPxFormThem_Click(object sender, EventArgs e)
        {
            if (ASPxFormLayout1_NhaCungCap.Value != null)
            {
                DataTable db =  data.LayDanhSachChiTietDonHang_Temp();
                if (db.Rows.Count != 0)
                {
                    int IDNhaCungCap = Int32.Parse(ASPxFormLayout1_NhaCungCap.Value.ToString());
                    DateTime NgayLap = DateTime.Parse(ASPxFormLayoutNgayLapPhieu.Text.ToString());
                    string GhiChu = ASPxFormLayoutGhiChu == null ? "" : ASPxFormLayoutGhiChu.Text.ToString();

                    float TongTien = 0;

                    foreach (DataRow dr in db.Rows)
                    {
                        float ThanhTien = float.Parse(dr["ThanhTien"].ToString());
                        TongTien = TongTien + ThanhTien; 
                    }
                    int IDKho = Int32.Parse((txtIDKho.Value.ToString()));
                    data = new dtThemDonHang();
                    object dh = data.ThemDonDatHang(IDNhaCungCap,IDKho, NgayLap, TongTien, GhiChu);
                    if (dh != null)
                    {
                        foreach (DataRow dr in db.Rows)
                        {
                            int IDHangHoa = Int32.Parse(dr["IDHangHoa"].ToString());
                            int IDThue = Int32.Parse(dr["IDThue"].ToString());
                            int SoLuong = Int32.Parse(dr["SoLuong"].ToString());
                            float DonGia = float.Parse(dr["DonGia"].ToString());
                            float TienChuaThue = float.Parse(dr["TienChuaThue"].ToString());
                            float TienThue = float.Parse(dr["TienThue"].ToString());
                            float ThanhTien = float.Parse(dr["ThanhTien"].ToString());
                            data = new dtThemDonHang();
                            data.ThemChiTietDonHang(dh, IDHangHoa, IDThue, SoLuong, DonGia, TienChuaThue, TienThue, ThanhTien);
                            
                        }
                        data = new dtThemDonHang();
                        data.XoaChiTietDonHang_Temp();
                        Response.Write("<script language='JavaScript'> alert('Đơn đặt hàng đã được gửi vui lòng chờ duyệt.'); </script>");
                        Response.Redirect("DanhSachDonHangChuaDuyet.aspx");
                        LoadGrid();
                        ASPxFormLayout1_NhaCungCap.Text = "";
                        ASPxFormLayoutNgayLapPhieu.Text = "";
                        ASPxFormLayoutGhiChu.Text = "";

                        dtLichSuTruyCap.ThemLichSu(Session["IDNhanVien"].ToString(), Session["IDNhom"].ToString(), "Đơn Đặt Hàng", dtSetting.LayIDKho(), "Nhập xuất tồn", "Thêm");  
                    }
                    else
                    {
                        Response.Write("<script language='JavaScript'> alert('Lỗi xử lý dữ liệu.'); </script>");
                    }
                }
                else
                {
                    Response.Write("<script language='JavaScript'> alert('Danh sách hàng hóa rỗng.'); </script>");
                }
            }
            else
            {
                Response.Write("<script language='JavaScript'> alert('Bạn chưa chọn nhà cung cấp.'); </script>");
            }


        }

        protected void btnLoadFileExcel_Click(object sender, EventArgs e)
        {
            Import();
        }
        private string strFileExcel = "";
        private void Import()
        {
            if (string.IsNullOrEmpty(UploadFileExcel.FileName))
            {
                Response.Write("<script language='JavaScript'> alert('Chưa chọn file.'); </script>");
                return;
            }

            UploadFile();
            string Excel = Server.MapPath("~/Uploads/") + strFileExcel;

            string excelConnectionString = string.Empty;
            excelConnectionString = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" + Excel + ";Extended Properties=Excel 8.0;";

            OleDbConnection excelConnection = new OleDbConnection(excelConnectionString);
            OleDbCommand cmd = new OleDbCommand("Select * from [Sheet$]", excelConnection);
            excelConnection.Open();
            OleDbDataReader dReader = default(OleDbDataReader);
            dReader = cmd.ExecuteReader();

            DataTable dataTable = new DataTable();
            dataTable.Load(dReader);
            int r = dataTable.Rows.Count;
            Import_Temp(dataTable);

        }
        private void UploadFile()
        {
            string folder = null;
            string filein = null;
            string ThangNam = null;

            ThangNam = string.Concat(System.DateTime.Now.Month.ToString(), System.DateTime.Now.Year.ToString());
            if (!Directory.Exists(Server.MapPath("~/Uploads/") + ThangNam))
            {
                Directory.CreateDirectory(Server.MapPath("~/Uploads/") + ThangNam);
            }
            folder = Server.MapPath("~/Uploads/" + ThangNam + "/");

            if (UploadFileExcel.HasFile)
            {
                strFileExcel = Guid.NewGuid().ToString();
                string theExtension = Path.GetExtension(UploadFileExcel.FileName);
                strFileExcel += theExtension;

                filein = folder + strFileExcel;
                UploadFileExcel.SaveAs(filein);
                strFileExcel = ThangNam + "/" + strFileExcel;
            }
        }
        private void Import_Temp(DataTable datatable)
        {
            int intRow = datatable.Rows.Count;
            if (intRow != 0)
            {
                for (int i = 0; i <= intRow - 1; i++)
                {
                    DataRow dr = datatable.Rows[i];
                    int IDHangHoa = Int32.Parse(dr["MaHang"].ToString());
                    string TenHangHoa = dr["TenHangHoa"].ToString();
                    int SL = 0;
                    int SoLuong = Int32.Parse(dr["SoLuong"].ToString());
                    if (dtSetting.KT_SoLuong() == 0)
                    {
                        SL = SoLuong;
                    }
                    else
                    {
                        
                        int SoLuongCon = dtCapNhatTonKho.SoLuongTonKho_Server(IDHangHoa);
                       
                        if (SoLuongCon >= SoLuong)
                        {
                            SL = SoLuong;
                        }
                        else
                        {
                            SL = SoLuongCon;
                            Response.Write("<script language='JavaScript'> alert('Số hàng trên kho tổng không đủ.'); </script>");
                        }
                    }
                    data = new dtThemDonHang();
                    DataTable dt = data.LayThongTinHangHoa_ID_TenHangHoa(IDHangHoa,TenHangHoa);
                    DataRow dr1 = dt.Rows[0];
                    float DonGia = float.Parse(dr1["GiaBan1"].ToString());
                    float ThanhTien = SL * DonGia;
                    float TienChuaThue = 0;
                    float TienThue = 0;

                    dt = data.KTChiTietDonHang_Temp(IDHangHoa);
                    if (dt.Rows.Count == 0)
                    {
                        data.ThemChiTietDonHang_Temp(IDHangHoa, 4, SL, DonGia, TienChuaThue, TienThue, ThanhTien);
                        LoadGrid();
                    }
                }
            }

        }
    }
}