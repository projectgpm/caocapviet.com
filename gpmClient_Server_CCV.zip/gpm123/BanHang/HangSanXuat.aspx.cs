﻿using BanHang.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace BanHang
{
    public partial class HangSanXuat : System.Web.UI.Page
    {
        dtHangSanXuat data = new dtHangSanXuat();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["KTDangNhap"] != "GPM")
            {
                Response.Redirect("DangNhap.aspx");
            }
            else
            {
                if (dtSetting.LayTrangThaiMenu_ChucNang(Session["IDNhom"].ToString(), 10) == 1)
                    gridDanhSach.Columns["chucnang"].Visible = false;
                if (dtSetting.LayTrangThaiMenu(Session["IDNhom"].ToString(), 10) == 1)
                {
                    loadGrid();
                }
                else
                {
                    Response.Redirect("Default.aspx");
                }
            }
        }

        private void loadGrid()
        {
            data = new dtHangSanXuat();
            gridDanhSach.DataSource = data.DanhSachHangSanXuat();
            gridDanhSach.DataBind();

        }

        protected void gridDanhSach_RowInserting(object sender, DevExpress.Web.Data.ASPxDataInsertingEventArgs e)
        {
            string TenNhanHang = e.NewValues["TenNhanHang"].ToString();
            string SDT = e.NewValues["SDT"] == null ? "" : e.NewValues["SDT"].ToString();
            string DiaChi = e.NewValues["DiaChi"] == null ? "" : e.NewValues["DiaChi"].ToString();
            string IDQuan = e.NewValues["IDQuan"] == null ? "" : e.NewValues["IDQuan"].ToString();
            string IDThanhPho = e.NewValues["IDThanhPho"] == null ? "" : e.NewValues["IDThanhPho"].ToString();
            string Email = e.NewValues["Email"] == null ? "" : e.NewValues["Email"].ToString();
            string GhiChu = e.NewValues["GhiChu"] == null ? "" : e.NewValues["GhiChu"].ToString();
            dtHangSanXuat.ThemHangSanXuat(TenNhanHang, SDT, DiaChi, IDQuan, IDThanhPho, Email, GhiChu);
            e.Cancel = true;
            gridDanhSach.CancelEdit();
            loadGrid();
        }

        protected void gridDanhSach_RowDeleting(object sender, DevExpress.Web.Data.ASPxDataDeletingEventArgs e)
        {
            string ID = e.Keys[0].ToString();
            dtHangSanXuat.XoaHangSanXuat(ID);
            e.Cancel = true;
            gridDanhSach.CancelEdit();
            loadGrid();
        }

        protected void gridDanhSach_RowUpdating(object sender, DevExpress.Web.Data.ASPxDataUpdatingEventArgs e)
        {
            string ID = e.Keys[0].ToString();
            string TenNhanHang = e.NewValues["TenNhanHang"].ToString();
            string SDT = e.NewValues["SDT"] == null ? "" : e.NewValues["SDT"].ToString();
            string DiaChi = e.NewValues["DiaChi"] == null ? "" : e.NewValues["DiaChi"].ToString();
            string IDQuan = e.NewValues["IDQuan"] == null ? "" : e.NewValues["IDQuan"].ToString();
            string IDThanhPho = e.NewValues["IDThanhPho"] == null ? "" : e.NewValues["IDThanhPho"].ToString();
            string Email = e.NewValues["Email"] == null ? "" : e.NewValues["Email"].ToString();
            string GhiChu = e.NewValues["GhiChu"] == null ? "" : e.NewValues["GhiChu"].ToString();
            dtHangSanXuat.CapNhatHangSanXuat(ID,TenNhanHang, SDT, DiaChi, IDQuan, IDThanhPho, Email, GhiChu);
            e.Cancel = true;
            gridDanhSach.CancelEdit();
            loadGrid();
        }
    }
}