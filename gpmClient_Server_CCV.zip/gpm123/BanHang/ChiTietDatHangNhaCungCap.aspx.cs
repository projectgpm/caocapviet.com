﻿using BanHang.Data;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace BanHang
{
    public partial class ChiTietDatHangNhaCungCap : System.Web.UI.Page
    {
        dtDuyetHangNhaCungCap data = new dtDuyetHangNhaCungCap();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["KTDangNhap"] == "GPM")
            {
                if (dtSetting.LayTrangThaiMenu_ChucNang(Session["IDNhom"].ToString(), 15) == 1)
                    gridChiTietDonHang.Columns["chucnang"].Visible = false;
                string IDDonDatHang = Request.QueryString["IDDonDatHang"];
                if (IDDonDatHang != null)
                {
                    LoadGrid(Int32.Parse(IDDonDatHang.ToString()));
                }
            }
            else
            {
                Response.Redirect("DangNhap.aspx");
            }
        }
        private void LoadGrid(int IDDonDatHang)
        {
            data = new dtDuyetHangNhaCungCap();
            gridChiTietDonHang.DataSource = data.LayDanhSachChiTietDonDatHang(IDDonDatHang);
            gridChiTietDonHang.DataBind();

        }

        protected void gridChiTietDonHang_RowUpdating(object sender, DevExpress.Web.Data.ASPxDataUpdatingEventArgs e)
        {
            string IDDonDatHang = Request.QueryString["IDDonDatHang"];
            string ID = e.Keys[0].ToString();
            int SoLuong = Int32.Parse(e.NewValues["SoLuong"].ToString());
            data = new dtDuyetHangNhaCungCap();
            DataTable db = data.LayDanhSachChiTietDonHangNCC_ID(ID);
            if(db.Rows.Count !=0)
            {
                DataRow dr = db.Rows[0];
                int IDHangHoa = Int32.Parse(dr["IDHangHoa"].ToString());
                float GiaBan = dtCapNhatTonKho.GiaBan_Client(IDHangHoa);
                float ThanhTien = SoLuong * GiaBan;
                
                data = new dtDuyetHangNhaCungCap();
                data.CapNhatChiTietDonHang_ID(ID, SoLuong, ThanhTien);

                DataTable dt = data.LayDanhSachChiTietDonDatHang(Int32.Parse(IDDonDatHang));
                if (dt.Rows.Count != 0)
                {
                    float TongTien = 0;
                    foreach (DataRow dr4 in dt.Rows)
                    {
                        float txtThanhTien = float.Parse(dr4["ThanhTien"].ToString());
                        TongTien = TongTien + txtThanhTien;
                    }
                    data.CapNhatTongTienDonHang_ID(Int32.Parse(IDDonDatHang), TongTien);
                }
                e.Cancel = true;
                gridChiTietDonHang.CancelEdit();
                LoadGrid(Int32.Parse(IDDonDatHang));
            }
        }
    }
}