﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using BanHang.Data;
using DevExpress.Web;

namespace BanHang
{
    public partial class NhomHang : System.Web.UI.Page
    {
        dataNhomHang da = new dataNhomHang();
        protected void Page_Load(object sender, EventArgs e)
        {

            if (Session["KTDangNhap"] != "GPM")
            {
                Response.Redirect("DangNhap.aspx");
            }
            else
            {
                if (dtSetting.LayTrangThaiMenu_ChucNang(Session["IDNhom"].ToString(), 6) == 1)
                    gridNhomHang.Columns["iconaction"].Visible = false;
                if (dtSetting.LayTrangThaiMenu(Session["IDNhom"].ToString(), 6) == 1)
                {
                    LoadGrid();
                }
                else
                {
                    Response.Redirect("Default.aspx");
                }
            }

            if (dtSetting.LayTrangThaiMenu_ChucNang(Session["IDNhom"].ToString(), 13) == 1)
                gridNhomHang.Columns["iconaction"].Visible = false;
        }
        public void LoadGrid()
        {
            gridNhomHang.DataSource = da.getDanhSachNhomHang();
            gridNhomHang.DataBind();
        }

        protected void gridNhomHang_RowDeleting(object sender, DevExpress.Web.Data.ASPxDataDeletingEventArgs e)
        {
            string ID = e.Keys[0].ToString();
            da.XoaNhomHang(Int32.Parse(ID));
            e.Cancel = true;
            gridNhomHang.CancelEdit();
            LoadGrid();

            ActionServer.CapNhatServer();
            dtLichSuTruyCap.ThemLichSu(Session["IDNhanVien"].ToString(), Session["IDNhom"].ToString(), "Nhóm Hàng", dtSetting.LayIDKho(), "Nhóm Hàng", "Xóa ID = " + ID); 
        }

        protected void gridNhomHang_RowInserting(object sender, DevExpress.Web.Data.ASPxDataInsertingEventArgs e)
        {
            int IDNganhHang = Int32.Parse(e.NewValues["IDNganhHang"].ToString());
            string MaNhom = e.NewValues["MaNhom"].ToString();
            string TenNhomHang = e.NewValues["TenNhomHang"].ToString();
            TenNhomHang = dtSetting.convertDauSangKhongDau(TenNhomHang).ToUpper();
            string GhiChu = e.NewValues["GhiChu"] != null ? e.NewValues["GhiChu"].ToString() : "";

            da.insertNhomHang(IDNganhHang, MaNhom, TenNhomHang, GhiChu);
            e.Cancel = true;
            gridNhomHang.CancelEdit();
            LoadGrid();

            ActionServer.CapNhatServer();
            dtLichSuTruyCap.ThemLichSu(Session["IDNhanVien"].ToString(), Session["IDNhom"].ToString(), "Nhóm Hàng", dtSetting.LayIDKho(), "Nhóm Hàng", "Thêm: " + TenNhomHang); 
        }

        protected void gridNhomHang_RowUpdating(object sender, DevExpress.Web.Data.ASPxDataUpdatingEventArgs e)
        {
            string ID = e.Keys["ID"].ToString();
            int IDNganhHang = Int32.Parse(e.NewValues["IDNganhHang"].ToString());
            string MaNhom = e.NewValues["MaNhom"].ToString();
            string TenNhomHang = e.NewValues["TenNhomHang"].ToString();
            TenNhomHang = dtSetting.convertDauSangKhongDau(TenNhomHang).ToUpper();
            string GhiChu = e.NewValues["GhiChu"] != null ? e.NewValues["GhiChu"].ToString() : "";
            da.updateNhomHang(Int32.Parse(ID), IDNganhHang, MaNhom, TenNhomHang, GhiChu);
            e.Cancel = true;
            gridNhomHang.CancelEdit();
            LoadGrid();

            ActionServer.CapNhatServer();
            dtLichSuTruyCap.ThemLichSu(Session["IDNhanVien"].ToString(), Session["IDNhom"].ToString(), "Nhóm Hàng", dtSetting.LayIDKho(), "Nhóm Hàng", "Cập nhật: " + ID); 
        }
    }
}