﻿using BanHang.Data;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace BanHang
{
    public partial class PhieuDoiHang : System.Web.UI.Page
    {
        dtPhieuDoiHang data = new dtPhieuDoiHang();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["KTDangNhap"] != "GPM")
            {
                Response.Redirect("DangNhap.aspx");
            }
            else
            {
                if (dtSetting.LayTrangThaiMenu_ChucNang(Session["IDNhom"].ToString(), 14) == 1)
                    Response.Redirect("Default.aspx");
                if (dtSetting.LayTrangThaiMenu(Session["IDNhom"].ToString(), 14) == 1)
                {
                    if (!IsPostBack)
                    {
                        data = new dtPhieuDoiHang();
                        data.XoaPhieuDoiHang_Null();
                        object IDPhieuDoiHang = data.ThemPhieuDoiHang_Temp();
                        IDPhieuDoiHang_Temp.Value = IDPhieuDoiHang.ToString();
                        txtTienConLai.Text = "0";

                        int IDKho = dtSetting.LayIDKho();
                        cmbKho.Text = IDKho + "";
                    }
                    LoadGrid(Int32.Parse(IDPhieuDoiHang_Temp.Value.ToString()));
                }
                else
                {
                    Response.Redirect("Default.aspx");
                }
            }
        }

        protected void gridDanhSachDoi_RowDeleting(object sender, DevExpress.Web.Data.ASPxDataDeletingEventArgs e)
        {
            int ID = Int32.Parse(e.Keys[0].ToString());
            data = new dtPhieuDoiHang();
            data.XoaChiTietPhieuDoiHang_Temp_ID(ID);
            TinhTienConLai();
            LoadHangHoaDoi();
            e.Cancel = true;
            gridDanhSachDoi.CancelEdit();
            LoadGrid(Int32.Parse(IDPhieuDoiHang_Temp.Value.ToString()));
        }


       

        protected void txtNgayDoi_Init(object sender, EventArgs e)
        {
            txtNgayDoi.Date = DateTime.Today;
        }


        protected void cmbSoHoaDon_SelectedIndexChanged(object sender, EventArgs e)
        {
            //Response.Write("<script language='JavaScript'> alert('" + cmbSoHoaDon.Value + ".'); </script>");
            if (cmbSoHoaDon.Text != "")
            {
                data = new dtPhieuDoiHang();
                DataTable db = data.DanhSachHoaDon(Int32.Parse(cmbSoHoaDon.Value.ToString()));
                if (db.Rows.Count != 0)
                {
                    Clear_HangHoaDoi();
                    DataRow dr = db.Rows[0];
                    cmbThuNgan.Value = dr["IDNhanVien"].ToString();

                    LoadHangHoaDoi();
                }
            }
        }
        public void LoadHangHoaDoi()
        {
            if (cmbSoHoaDon.Text != "")
            {
                data = new dtPhieuDoiHang();
                cmbHangHoaDoi.DataSource = data.DanhSachHangHoaTra_IDHoaDon(Int32.Parse(cmbSoHoaDon.Value.ToString()));
                cmbHangHoaDoi.TextField = "TenHangHoa";
                cmbHangHoaDoi.ValueField = "ID";
                cmbHangHoaDoi.DataBind();
            }
        }

        protected void txtSoLuongDoi_NumberChanged(object sender, EventArgs e)
        {
            data = new dtPhieuDoiHang();
            if (cmbHangHoaDoi.Text != "")
            {
                int IDHangHoaDoi = Int32.Parse(cmbHangHoaDoi.Value.ToString());
                DataTable db = data.ChiTietHangHoa_IDChiTietHoaDon(IDHangHoaDoi);
                if (db.Rows.Count != 0)
                {
                    DataRow dr = db.Rows[0];
                    int SLCu = Int32.Parse(dr["SoLuong"].ToString());
                    int SoLuongDoi = Int32.Parse(txtSoLuongDoi.Text.ToString());
                    if (SoLuongDoi > SLCu)
                    {
                        Response.Write("<script language='JavaScript'> alert('Vượt quá số lượng cho phép.'); </script>");
                        txtSoLuongDoi.Text = SLCu.ToString();
                        LoadHangHoaDoi();
                    }
                }
            }
        }

        
        public void Clear_HangHoaDoi()
        {
            cmbHangHoaDoi.Text = "";
            txtSoLuongDoi.Text = "";
        }

        protected void btnThemDoi_Click(object sender, EventArgs e)
        {
            if (cmbHangHoaDoi.Text != "" && txtSoLuongDoi.Text != "")
            {
                int IDHangHoaDoi = Int32.Parse(cmbHangHoaDoi.Value.ToString());
                DataTable db = data.ChiTietHangHoa_IDChiTietHoaDon(IDHangHoaDoi);
                if (db.Rows.Count != 0)
                {
                    DataRow dr = db.Rows[0];
                    int SoLuongDoi = Int32.Parse(txtSoLuongDoi.Text.ToString());
                    float GiaMua = float.Parse(dr["GiaMua"].ToString());
                    int IDHangHoa = Int32.Parse(dr["IDHangHoa"].ToString());
                    int IDPhieuDoiHang = Int32.Parse(IDPhieuDoiHang_Temp.Value.ToString());

                    data = new dtPhieuDoiHang();
                    DataTable tbl = data.DanhSanhHangHoa_IDHangHoa(IDHangHoa);
                    DataRow drtbl = tbl.Rows[0];
                    int IDDonViTinh = Int32.Parse(drtbl["IDDonViTinh"].ToString());
                    data = new dtPhieuDoiHang();

                    DataTable db1 = data.KTChiTietPhieuDoiHang_Temp(IDHangHoa);// kiểm tra hàng hóa
                    if (db1.Rows.Count == 0)
                    {
                        data = new dtPhieuDoiHang();
                        data.ThemChiTietPhieuDoiHang_Temp(IDPhieuDoiHang, IDHangHoa, IDDonViTinh, SoLuongDoi, GiaMua, (SoLuongDoi * GiaMua));
                        LoadHangHoaDoi();
                        TinhTienConLai();
                        Clear_HangHoaDoi();
                    }
                    else
                    {
                        data = new dtPhieuDoiHang();
                        data.UpdateChiTietPhieuDoiHang_Temp(IDPhieuDoiHang, IDHangHoa, IDDonViTinh, SoLuongDoi, GiaMua, (SoLuongDoi * GiaMua));
                        LoadHangHoaDoi();
                        TinhTienConLai();
                        Clear_HangHoaDoi();
                    }
                    LoadGrid(IDPhieuDoiHang);
                }

            }
            else
            {
                Response.Write("<script language='JavaScript'> alert('Chưa chọn hàng hóa hay số lượng đổi.'); </script>");
                LoadHangHoaDoi();
            }
        }

        public void TinhTienConLai()
        {
            data = new dtPhieuDoiHang();
            DataTable db = data.DanhSachChiTietPhieuDoiHang_Temp(Int32.Parse(IDPhieuDoiHang_Temp.Value.ToString()));
            if (db.Rows.Count != 0)
            {
                float TienConLai = 0;
                foreach (DataRow dr in db.Rows)
                {
                    float ThanhTien = float.Parse(dr["ThanhTien"].ToString());
                    TienConLai = TienConLai + ThanhTien;
                }
                txtTienConLai.Text = (-TienConLai).ToString();
            }
        }
        private void LoadGrid(int IDPhieuDoiHang)
        {
            data = new dtPhieuDoiHang();
            gridDanhSachDoi.DataSource = data.DanhSachChiTietPhieuDoiHang_Temp(IDPhieuDoiHang);
            gridDanhSachDoi.DataBind();
        }

        protected void btnHuyPhieuDoiHang_Click(object sender, EventArgs e)
        {
            data = new dtPhieuDoiHang();
            int ID = Int32.Parse(IDPhieuDoiHang_Temp.Value.ToString());
            if (ID != null)
            {
                data.XoaPhieuDoiHang_Temp(ID);
                data.XoaPhieuDoiHang_Null();
                data.XoaChiTietPhieuDoiHang_Temp(ID);
                Response.Redirect("DonDoiHang.aspx");
            }
        }

        protected void cmbHangHoaDoi_SelectedIndexChanged(object sender, EventArgs e)
        {
            txtSoLuongDoi.Text = "1";
            TinhTienConLai();
        }

        

        protected void btnThemPhieuDoiHang_Click(object sender, EventArgs e)
        {
            if (cmbSoHoaDon.Text != "")
            {
                int SoHoaDon = Int32.Parse(cmbSoHoaDon.Value.ToString());

                DataTable tbl = data.DanhSachHoaDon(SoHoaDon);
                DataRow drl = tbl.Rows[0];
                int ID = Int32.Parse(drl["ID"].ToString());
                int IDKhachHang = Int32.Parse(drl["IDKhachHang"].ToString());


                int IDNhanVien = Int32.Parse(cmbThuNgan.Value.ToString());
                int IDKho = dtSetting.LayIDKho();
                DateTime NgayDoi = DateTime.Parse(txtNgayDoi.Text.ToString());
                string LyDoDoi = txtLyDoDoi.Text == null ? "" : txtLyDoDoi.Text.ToString();
                
                float TienConLai = float.Parse(txtTienConLai.Text.ToString());
                int IDPhieuDoiHang = Int32.Parse(IDPhieuDoiHang_Temp.Value.ToString());

                data = new dtPhieuDoiHang();
                DataTable db = data.DanhSachChiTietPhieuDoiHang_Temp(IDPhieuDoiHang);
                if (db.Rows.Count != 0)
                {
                    data = new dtPhieuDoiHang();
                    data.CapNhatPhieuDoiHang_ID(IDPhieuDoiHang, SoHoaDon, IDKhachHang, IDNhanVien, IDKho, NgayDoi, LyDoDoi, TienConLai);

                    // insert hàng hóa đổi
                    foreach (DataRow dr in db.Rows)
                    {
                        int IDHangHoa =  Int32.Parse(dr["IDHangHoa"].ToString());
                        int SoLuong = Int32.Parse(dr["SoLuong"].ToString());
                        int IDDonViTinh = Int32.Parse(dr["IDDonViTinh"].ToString());
                        float GiaMua = float.Parse(dr["GiaMua"].ToString());
                        float ThanhTien = float.Parse(dr["ThanhTien"].ToString());

                        // hàm insert
                        data = new dtPhieuDoiHang();
                        data.ThemChiTietPhieuDoiHang(IDPhieuDoiHang, IDHangHoa, IDDonViTinh, SoLuong, GiaMua, ThanhTien);
                        dtCapNhatTonKho tk = new dtCapNhatTonKho();

                        dtLichSuKho.ThemLichSu(IDHangHoa, Int32.Parse(Session["IDNhanVien"].ToString()), SoLuong * (-1), "Đổi hàng");

                        tk.CongTonKho_IDHangHoa(IDHangHoa, SoLuong,IDKho);
                        //cập nhật lại hóa đơn

                        data = new dtPhieuDoiHang();
                        DataTable tbl2 = data.SoLuongHangHoa_IDHoaDon_IDHangHoa(SoHoaDon, IDHangHoa);
                        DataRow drl2 = tbl2.Rows[0];
                        int SLCuHoDoan = Int32.Parse(drl2["SoLuong"].ToString());
                        int SLMoi = SLCuHoDoan - SoLuong;
                        data = new dtPhieuDoiHang();
                        data.CapNhatChiTietHoaDon_IDHoaDon(SoHoaDon, IDHangHoa, SLMoi, (SLMoi * GiaMua));
                    }

                    data = new dtPhieuDoiHang();
                    DataTable tbl3 = data.ChiTietHoaDOn_IDHoaDon(SoHoaDon);
                    float TongTien = 0;
                    foreach (DataRow dr in tbl3.Rows)
                    {
                        float ThanhTien = float.Parse(dr["ThanhTien"].ToString());
                        TongTien = TongTien + ThanhTien;
                    }
                    data.CapNhatHoaDon_ThanhTien_IDHoaDon(ID, TongTien);

                    dtLichSuTruyCap.ThemLichSu(Session["IDNhanVien"].ToString(), Session["IDNhom"].ToString(), "Phiếu Đổi Hàng", dtSetting.LayIDKho(), "Nhập xuất tồn", "Thêm");  

                    data = new dtPhieuDoiHang();
                    data.XoaChiTietPhieuDoiHang_Temp(IDPhieuDoiHang);
                    Response.Redirect("DonDoiHang.aspx");
                }

            }
            else
            {
                Response.Write("<script language='JavaScript'> alert('Bạn chưa chọn số hóa đơn.'); </script>");
            }
        }

        

      
    }
}