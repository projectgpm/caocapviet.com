﻿using BanHang.Data;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace BanHang
{
    public partial class QuanTriNguoiDung : System.Web.UI.Page
    {
        dtQuanTriNguoiDung data = new dtQuanTriNguoiDung();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["KTDangNhap"] != "GPM")
            {
                Response.Redirect("DangNhap.aspx");
            }
            else
            {
                if (dtSetting.LayTrangThaiMenu_ChucNang(Session["IDNhom"].ToString(), 37) == 1)
                    gridQuanTriNguoiDung.Columns["iconaction"].Visible = false;

                if (dtSetting.LayTrangThaiMenu(Session["IDNhom"].ToString(), 37) == 1)
                {
                    LoadGrid();
                }
                else
                {
                    Response.Redirect("Default.aspx");
                }
            }
        }
        public void LoadGrid()
        {
            data = new dtQuanTriNguoiDung();
            gridQuanTriNguoiDung.DataSource = data.LayDanhSachNguoiDung();
            gridQuanTriNguoiDung.DataBind();
        }
        protected void gridQuanTriNguoiDung_RowDeleting(object sender, DevExpress.Web.Data.ASPxDataDeletingEventArgs e)
        {
            string ID = e.Keys[0].ToString();
            data = new dtQuanTriNguoiDung();
            data.XoaNguoiDung(Int32.Parse(ID));
            e.Cancel = true;
            gridQuanTriNguoiDung.CancelEdit();
            LoadGrid();
            dtLichSuTruyCap.ThemLichSu(Session["IDNhanVien"].ToString(), Session["IDNhom"].ToString(), "Quản Trị người dùng", dtSetting.LayIDKho(), "Hệ Thống", "Xóa");
         
        }

        protected void gridQuanTriNguoiDung_RowInserting(object sender, DevExpress.Web.Data.ASPxDataInsertingEventArgs e)
        {
            DateTime NgayCapNhat = DateTime.Today.Date;
            data = new dtQuanTriNguoiDung();
            string TenNguoiDung = e.NewValues["TenNguoiDung"].ToString();
            int IDNhomNguoiDung = Int32.Parse(e.NewValues["IDNhomNguoiDung"].ToString());
            //int IDCaBan = Int32.Parse(e.NewValues["IDCaBan"].ToString());
            string SDT = e.NewValues["SDT"].ToString();
            string MatKhau = e.NewValues["MatKhau"].ToString();
            MatKhau = ActionCilent.GetSHA1HashData(MatKhau);
            string TenDangNhap = e.NewValues["TenDangNhap"].ToString().ToUpper();
            DataTable db = data.KiemTraNguoiDung(TenDangNhap);
            if (db.Rows.Count == 0)
            {
                data.ThemNguoiDung(TenNguoiDung, TenDangNhap, IDNhomNguoiDung, SDT, MatKhau, NgayCapNhat);
                e.Cancel = true;
                gridQuanTriNguoiDung.CancelEdit();
                LoadGrid();
                dtLichSuTruyCap.ThemLichSu(Session["IDNhanVien"].ToString(), Session["IDNhom"].ToString(), "Quản Trị người dùng", dtSetting.LayIDKho(), "Hệ Thống", "Thêm");

            }
            else
            {
               throw new Exception("Lỗi: Tên đăng nhập đã tồn tại");
            }
            
        }

        protected void gridQuanTriNguoiDung_RowUpdating(object sender, DevExpress.Web.Data.ASPxDataUpdatingEventArgs e)
        {
            string ID = e.Keys["ID"].ToString();
            string TenNguoiDung = e.NewValues["TenNguoiDung"].ToString();
            string TenDangNhap = e.NewValues["TenDangNhap"].ToString().ToUpper();
            int IDNhomNguoiDung = Int32.Parse(e.NewValues["IDNhomNguoiDung"].ToString());
            //int IDCaBan = Int32.Parse(e.NewValues["IDCaBan"].ToString());
            string SDT = e.NewValues["SDT"].ToString();
            string MatKhau = e.NewValues["MatKhau"].ToString();
            MatKhau = ActionCilent.GetSHA1HashData(MatKhau);
            DateTime NgayCapNhat = DateTime.Today.Date;
            //DataTable db = data.KiemTraNguoiDung(TenDangNhap);
            //if (db.Rows.Count == 0)
            //{
                data.SuaNguoiDung(Int32.Parse(ID), TenNguoiDung, TenDangNhap, IDNhomNguoiDung, SDT, MatKhau, NgayCapNhat);
                e.Cancel = true;
                gridQuanTriNguoiDung.CancelEdit();
                LoadGrid();

                dtLichSuTruyCap.ThemLichSu(Session["IDNhanVien"].ToString(), Session["IDNhom"].ToString(), "Quản Trị người dùng", dtSetting.LayIDKho(), "Hệ Thống", "Cập Nhật");
            //}
            //else
            //{
            //    throw new Exception("Lỗi: Tên đăng nhập đã tồn tại");
            //}

            
        }
    }
}