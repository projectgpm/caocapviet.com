﻿using BanHang.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace BanHang
{
    public partial class ChiTietPhieuKiemKho : System.Web.UI.Page
    {
        dtKiemKho data = new dtKiemKho();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["KTDangNhap"] == "GPM")
            {
                string IDPhieuKiemKho = Request.QueryString["IDPhieuKiemKho"];
                if (IDPhieuKiemKho != null)
                {

                    LoadGrid(Int32.Parse(IDPhieuKiemKho.ToString()));
                }
            }
            else
            {
                Response.Redirect("DangNhap.aspx");
            }
        }

        private void LoadGrid(int IDPhieuKiemKho)
        {
            data = new dtKiemKho();
            gridChiTietPhieuKiemKho.DataSource = data.DanhSachChiTietPhieuKiemKho_IDPhieuKiemKho(IDPhieuKiemKho);
            gridChiTietPhieuKiemKho.DataBind();
        }
    }
}