﻿using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using DevExpress.XtraReports.UI;

namespace BanHang.Report
{
    public partial class rpBangKePhieuXuatKhac : DevExpress.XtraReports.UI.XtraReport
    {
        public rpBangKePhieuXuatKhac()
        {
            InitializeComponent();
        }

    }
}
