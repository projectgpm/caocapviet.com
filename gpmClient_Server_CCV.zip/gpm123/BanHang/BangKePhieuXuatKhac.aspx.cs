﻿using BanHang.Data;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace BanHang
{
    public partial class BangKePhieuXuatKhac : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["KTDangNhap"] != "GPM")
            {
                Response.Redirect("DangNhap.aspx");
            }
            else
            {
                if (dtSetting.LayTrangThaiMenu(Session["IDNhom"].ToString(), 24) == 1)
                {
                    if (!IsPostBack)
                    {
                        dtThongTinCuaHangKho d = new dtThongTinCuaHangKho();
                        DataTable dx = d.LayDanhSach();
                        dx.Rows.Add(-1, "Tất cả Cửa Hàng", "", "", 0, 0, "", DateTime.Now.Date, 0);
                        cmbKhoXuat.DataSource = dx;
                        cmbKhoXuat.TextField = "TenCuaHang";
                        cmbKhoXuat.ValueField = "ID";
                        cmbKhoXuat.DataBind();
                        cmbKhoXuat.Value = dtSetting.LayIDKho() + "";

                        dtKhachHang d1 = new dtKhachHang();
                        DataTable d1x = d1.LayDanhSachKhachHang();
                        d1x.Rows.Add(-1, 0, 0, "", "Tất cả Khách Hàng", DateTime.Now.Date, "", "", 0, 0, "", "", "", "", 0, DateTime.Now.Date, 0, 0, 0);
                        cmbKhachHang.DataSource = d1x;
                        cmbKhachHang.TextField = "TenKhachHang";
                        cmbKhachHang.ValueField = "ID";
                        cmbKhachHang.DataBind();
                        cmbKhachHang.SelectedIndex = cmbKhachHang.Items.Count;

                        txtNgayBD.Date = DateTime.Today.AddDays(-30);
                        txtNgayKT.Date = DateTime.Today;
                    }
                }
                else
                {
                    Response.Redirect("Default.aspx");
                }
            }
        }

        protected void btnIn_Click(object sender, EventArgs e)
        {
            string ngaybd = txtNgayBD.Date.ToString("yyyy-MM-dd");
            string ngaykt = txtNgayKT.Date.ToString("yyyy-MM-dd");
            string khohang = cmbKhoXuat.Value + "";
            string khachhang = cmbKhachHang.Value + "";
            popup.ContentUrl = "~/InBangKePhieuXuatKhac.aspx?khohang=" + khohang + "&khachhang=" + khachhang + "&ngaybd=" + ngaybd + "&ngaykt=" + ngaykt;
            popup.ShowOnPageLoad = true;
        }
    }
}