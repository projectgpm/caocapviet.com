﻿using BanHang.Data;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace BanHang
{
    public partial class ChiTietPhieuNhapLe : System.Web.UI.Page
    {
        dtPhieuNhapLe data = new dtPhieuNhapLe();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["KTDangNhap"] == "GPM")
            {
                string IDPhieuNhapLe = Request.QueryString["IDPhieuNhapLe"];
                if (IDPhieuNhapLe != null)
                {

                    LoadGrid(Int32.Parse(IDPhieuNhapLe.ToString()));
                }
            }
            else
            {
                Response.Redirect("DangNhap.aspx");
            }

        }

        private void LoadGrid(int IDPhieuNhapLe)
        {
            data = new dtPhieuNhapLe();
            gridChiTietPhieuNhapLe.DataSource = data.DanhSachChiTietPhieuNhapLe_ID(IDPhieuNhapLe);
            gridChiTietPhieuNhapLe.DataBind();
        }

        protected void gridChiTietPhieuNhapLe_RowUpdating(object sender, DevExpress.Web.Data.ASPxDataUpdatingEventArgs e)
        {
            string IDPhieuNhapLe = Request.QueryString["IDPhieuNhapLe"];
            if (IDPhieuNhapLe != null)
            {
                int ID = Int32.Parse(e.Keys[0].ToString());
                data = new dtPhieuNhapLe();
                DataTable db = data.LayDanhSachChiTietPhieuNhapLe_ID(ID);
                if (db.Rows.Count != 0)
                {
                    int SoLuong = Int32.Parse(e.NewValues["SoLuong"].ToString());
                    float GiaNhap = float.Parse(e.NewValues["GiaNhap"].ToString());
                    DataRow dr1 = db.Rows[0];
                    
                    int IDHangHoa = Int32.Parse(dr1["IDHangHoa"].ToString());
                    int SLCu = Int32.Parse(dr1["SoLuong"].ToString());
                    float ThanhTien = SoLuong * GiaNhap;
                    data = new dtPhieuNhapLe();
                    data.CapNhatChiTietPhieuNhapLe_ID(ID, SoLuong, GiaNhap, ThanhTien);
                    dtCapNhatTonKho tk = new dtCapNhatTonKho();

                    dtLichSuKho.ThemLichSu(ID, Int32.Parse(Session["IDNhanVien"].ToString()), (SoLuong - SLCu) * (-1), "Sửa chi tiết phiếu nhập lẻ");
                    
                    tk.CongTonKho_IDHangHoa(IDHangHoa, SoLuong - SLCu, dtSetting.LayIDKho());

                    DataTable tb = data.DanhSachChiTietPhieuNhapLe_ID(Int32.Parse(IDPhieuNhapLe.ToString()));

                    if (tb.Rows.Count != 0)
                    {
                        float TongTien = 0;
                        foreach (DataRow dr4 in tb.Rows)
                        {
                            float txtThanhTien = float.Parse(dr4["ThanhTien"].ToString());
                            TongTien = TongTien + txtThanhTien;
                        }
                        data.CapNhatTongTienPhieuNhapLe_ID(Int32.Parse(IDPhieuNhapLe.ToString()), TongTien);//cập nhật tổng tiền
                    }

                    e.Cancel = true;
                    gridChiTietPhieuNhapLe.CancelEdit();
                    LoadGrid(Int32.Parse(IDPhieuNhapLe.ToString()));

               
                    dtLichSuTruyCap.ThemLichSu(Session["IDNhanVien"].ToString(), Session["IDNhom"].ToString(), "Chi Tiết Phiếu Nhập Lẻ", dtSetting.LayIDKho(), "Nhập xuất tồn", "Cập Nhât"); 
                }
            }
        }

        protected void gridChiTietPhieuNhapLe_RowDeleting(object sender, DevExpress.Web.Data.ASPxDataDeletingEventArgs e)
        {
            string IDPhieuNhapLe = Request.QueryString["IDPhieuNhapLe"];

            if (IDPhieuNhapLe != null)
            {
                data = new dtPhieuNhapLe();
                DataTable db = data.DanhSachChiTietPhieuNhapLe_ID(Int32.Parse(IDPhieuNhapLe.ToString()));

                if (db.Rows.Count > 1)
                {
                    int ID = Int32.Parse(e.Keys[0].ToString());
                    data = new dtPhieuNhapLe();
                    DataTable da = data.LayDanhSachChiTietPhieuNhapLe_ID(ID);
                    if (da.Rows.Count != 0)
                    {
                        DataRow dr = da.Rows[0];
                        int SoLuong = Int32.Parse(dr["SoLuong"].ToString());
                        dtLichSuKho.ThemLichSu(ID, Int32.Parse(Session["IDNhanVien"].ToString()), SoLuong * (-1), "Xóa phiếu nhập nhập lẻ");
                    }
                    data.XoaChiTietPhieuNhapLe_ID(ID);
                    e.Cancel = true;
                    gridChiTietPhieuNhapLe.CancelEdit();
                    LoadGrid(Int32.Parse(IDPhieuNhapLe.ToString()));

                    dtLichSuTruyCap.ThemLichSu(Session["IDNhanVien"].ToString(), Session["IDNhom"].ToString(), "Chi Tiết Phiếu Nhập Lẻ" + ID, dtSetting.LayIDKho(), "Nhập xuất tồn", "Xóa");  
                }
            }
        }
    }
}