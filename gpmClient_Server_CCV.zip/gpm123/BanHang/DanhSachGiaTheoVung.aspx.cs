﻿using BanHang.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace BanHang
{
    public partial class DanhSachGiaTheoVung : System.Web.UI.Page
    {
        dtGiaTheoVung data = new dtGiaTheoVung();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["KTDangNhap"] != "GPM")
            {
                Response.Redirect("DangNhap.aspx");
            }
            else
            {
                if (dtSetting.LayTrangThaiMenu_ChucNang(Session["IDNhom"].ToString(), 9) == 1)
                {
                    gridHangHoa.Columns["giaban"].Visible = false;
                    btnGiaTheoKho.Enabled = false;
                }
                if (dtSetting.LayTrangThaiMenu(Session["IDNhom"].ToString(), 9) == 1)
                {
                    LoadGrid();
                }
                else
                {
                   
                    Response.Redirect("Default.aspx");
                   
                }
            }
        }

        private void LoadGrid()
        {
            data = new dtGiaTheoVung();
            gridHangHoa.DataSource = data.DanhSachHangHoa_ALL();
            gridHangHoa.DataBind();
        }

        protected void gridHangHoa_RowUpdating(object sender, DevExpress.Web.Data.ASPxDataUpdatingEventArgs e)
        {
            int ID = Int32.Parse(e.Keys[0].ToString());
            float GiaMoi = float.Parse(e.NewValues["GiaBan"].ToString());
            int IDKho = Int32.Parse(e.NewValues["IDKho"].ToString());
            int IDHangHoa = Int32.Parse(dtSetting.LayIDHangHoa_MaHang(e.NewValues["MaHang"].ToString()));
            float giacu = dtCapNhatTonKho.GiaBan_Client_TonKho(IDHangHoa, IDKho);

            dtHangHoa dtx = new dtHangHoa();
            dtx.ThemLichSuThayDoiGia(IDHangHoa, dtCapNhatTonKho.IDDVT_Client(IDHangHoa), giacu, GiaMoi, Int32.Parse(Session["IDNhanVien"].ToString()), e.NewValues["MaHang"].ToString());

            dtGiaTheoVung.Update_GiaTheoVung_ID(ID, IDKho, GiaMoi);
        
            dtLichSuTruyCap.ThemLichSu(Session["IDNhanVien"].ToString(), Session["IDNhom"].ToString(), "Kho", dtSetting.LayIDKho(), "Danh Mục", "Cập nhật giá theo vùng");
            e.Cancel = true;
            gridHangHoa.CancelEdit();
            LoadGrid();

            ActionServer.CapNhatServer();
        }

        protected void btnGiaTheoVung_Click(object sender, EventArgs e)
        {

        }

        protected void btnGiaTheoKho_Click(object sender, EventArgs e)
        {

        }
    }
}