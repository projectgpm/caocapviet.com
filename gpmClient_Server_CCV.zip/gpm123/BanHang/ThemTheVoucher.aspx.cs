﻿using BanHang.Data;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace BanHang
{
    public partial class ThemTheVoucher : System.Web.UI.Page
    {
        dtThevoucher data = new dtThevoucher();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (dtSetting.LayTrangThaiMenu(Session["IDNhom"].ToString(), 59) == 1)
            {
                LoadGrid();
            }
            else
            {
                Response.Redirect("Default.aspx");
            }

        }
        public void LoadGrid()
        {
            data = new dtThevoucher();
            gridTempVoucher.DataSource = data.LayDanhSachThevoucher_Temp();
            gridTempVoucher.DataBind();
        }

        protected void btnLuu_Click(object sender, EventArgs e)
        {
            if (txtMaTheVoucher.Text != "" && txtTenTheVoucher.Text != "" && txtSoLuongThe.Text != "" && txtGiaTri.Text != "" && txtTuNgay.Text != "" && txtDenNgay.Text != "")
            {
                data.XoaTheVoucher_Temp();  // Clear.

                string maThe = txtMaTheVoucher.Text;
                string tenThe = txtTenTheVoucher.Text;
                DateTime ngaybd = txtTuNgay.Date;
                DateTime ngaykt = txtDenNgay.Date;
                int soluong = Int32.Parse(txtSoLuongThe.Text);
                float gia = float.Parse(txtGiaTri.Text);
                int i = 0;
                DateTime NgayCapNhat = DateTime.Today.Date;
                while (i < soluong)
                {
                    string s1 = maThe + i;
                    data = new dtThevoucher();
                    data.ThemTheVoucher_Temp(s1, tenThe, ngaybd, ngaykt, gia, NgayCapNhat);
                    i++;
                }
                LoadGrid();
            }
            else
            {
                Response.Write("<script language='JavaScript'> alert('Hãy nhập đầy đủ thông tin thẻ.'); </script>");
            }
        }

        protected void btnLuTheVoucher_Click(object sender, EventArgs e)
        {
            data = new dtThevoucher();
            DataTable da = data.LayDanhSachThevoucher_Temp();
            foreach (DataRow dr in da.Rows)
            {
                string MaVoucher = dr["MaVoucher"].ToString();
                string TenVoucher = dr["TenVoucher"].ToString();
                DateTime TuNgay = DateTime.Parse(dr["TuNgay"].ToString());
                DateTime DenNgay = DateTime.Parse(dr["DenNgay"].ToString());
                float GiaTri = float.Parse(dr["GiaTri"].ToString());
                DateTime NgayCapNhat = DateTime.Today.Date;
                data.ThemTheVoucher(MaVoucher, TenVoucher, TuNgay, DenNgay, GiaTri, NgayCapNhat);
            }
            dtLichSuTruyCap dt1 = new dtLichSuTruyCap();
            dtLichSuTruyCap.ThemLichSu(Session["IDNhanVien"].ToString(), Session["IDNhom"].ToString(), "Thẻ Voucher" + ID, dtSetting.LayIDKho(), "Danh Mục", "Thêm");
            data.XoaTheVoucher_Temp();  // Clear.
            Response.Redirect("TheVoucher.aspx");

            ActionServer.CapNhatServer();
        }

        protected void btnHuy_Click(object sender, EventArgs e)
        {
            data = new dtThevoucher();
            data.XoaTheVoucher_Temp();  // Clear.
            Response.Redirect("TheVoucher.aspx");
        }

    }
}