﻿using BanHang.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace BanHang
{
    public partial class ThanhPho : System.Web.UI.Page
    {
        dtThanhPho data = new dtThanhPho();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (dtSetting.LayTrangThaiMenu(Session["IDNhom"].ToString(), 3) == 1)
            {
                LoadGrid();
            }
            else
            {
                Response.Redirect("Default.aspx");
            }
        }

        private void LoadGrid()
        {
            data = new dtThanhPho();
            gridThanhPho.DataSource = data.LayDanhSachThanhPho();
            gridThanhPho.DataBind();
        }

        protected void gridThanhPho_RowInserting(object sender, DevExpress.Web.Data.ASPxDataInsertingEventArgs e)
        {
            string txtID = e.NewValues["provinceid"].ToString();
            string txtTenThanhPho = e.NewValues["name"].ToString();
            string txtType = e.NewValues["type"].ToString();
            data = new dtThanhPho();
            data.ThemThanhPho(txtID, txtTenThanhPho, txtType);
            e.Cancel = true;
            gridThanhPho.CancelEdit();
            LoadGrid();

            ActionServer.CapNhatServer();
            dtLichSuTruyCap.ThemLichSu(Session["IDNhanVien"].ToString(), Session["IDNhom"].ToString(), "Thành Phố:" + txtTenThanhPho, dtSetting.LayIDKho(), "Danh Mục", "Thêm");
        }

        protected void gridThanhPho_RowUpdating(object sender, DevExpress.Web.Data.ASPxDataUpdatingEventArgs e)
        {
            string txtID = e.Keys["provinceid"].ToString();
            string txtTenThanhPho = e.NewValues["name"].ToString();
            string txtType = e.NewValues["type"].ToString();
            DateTime NgayCapNhat = DateTime.Today.Date;
            data.SuaThanhPho(txtID, txtTenThanhPho, txtType);
            e.Cancel = true;
            gridThanhPho.CancelEdit();
            LoadGrid();

            ActionServer.CapNhatServer();
            dtLichSuTruyCap.ThemLichSu(Session["IDNhanVien"].ToString(), Session["IDNhom"].ToString(), "Thành Phố:" + txtTenThanhPho, dtSetting.LayIDKho(), "Danh Mục", "Cập Nhật");
        }

        protected void gridThanhPho_RowDeleting(object sender, DevExpress.Web.Data.ASPxDataDeletingEventArgs e)
        {
            string ID = e.Keys[0].ToString();
            data = new dtThanhPho();
            data.XoaThanhPho(ID);
            e.Cancel = true;
            gridThanhPho.CancelEdit();
            LoadGrid();

            ActionServer.CapNhatServer();
            dtLichSuTruyCap.ThemLichSu(Session["IDNhanVien"].ToString(), Session["IDNhom"].ToString(), "Thành Phố:" + ID, dtSetting.LayIDKho(), "Danh Mục", "Xóa");
        }
    }
}