﻿using BanHang.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace BanHang
{
    public partial class ChietKhauTheoMaHang : System.Web.UI.Page
    {
        dtChietKhauTheoHangHoa data = new dtChietKhauTheoHangHoa();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (dtSetting.LayTrangThaiMenu_ChucNang(Session["IDNhom"].ToString(), 11) == 1)
                gridChietKhauTheoHangHoa.Columns["iconaction"].Visible = false;

            if (dtSetting.LayTrangThaiMenu(Session["IDNhom"].ToString(), 11) == 1)
            {
                LoadGrid();
            }
            else
            { Response.Redirect("Default.aspx"); }
            
        }

        private void LoadGrid()
        {
            data = new dtChietKhauTheoHangHoa();
            gridChietKhauTheoHangHoa.DataSource = data.LayDanhSach();
            gridChietKhauTheoHangHoa.DataBind();
        }

        protected void gridChietKhauTheoHangHoa_RowDeleting(object sender, DevExpress.Web.Data.ASPxDataDeletingEventArgs e)
        {
            int ID = Int32.Parse(e.Keys[0].ToString());
            data = new dtChietKhauTheoHangHoa();
            data.Xoa(ID);
            e.Cancel = true;
            gridChietKhauTheoHangHoa.CancelEdit();
            LoadGrid();

            ActionServer.CapNhatServer();
            dtLichSuTruyCap.ThemLichSu(Session["IDNhanVien"].ToString(), Session["IDNhom"].ToString(), "Chiết khấu theo hàng hóa: " + ID, dtSetting.LayIDKho(), "Danh Mục", "Xóa");
        }

        protected void gridChietKhauTheoHangHoa_RowInserting(object sender, DevExpress.Web.Data.ASPxDataInsertingEventArgs e)
        {
            data = new dtChietKhauTheoHangHoa();
            int IDHangHoa = Int32.Parse(e.NewValues["IDHangHoa"].ToString());
            double GiaTri = double.Parse(e.NewValues["GiaTri"].ToString());
            double txtGiaTri = Math.Round((GiaTri / 100), 2);
            DateTime NgayBatDau = DateTime.Parse(e.NewValues["NgayBatDau"].ToString());
            DateTime NgayKetThuc = DateTime.Parse(e.NewValues["NgayKetThuc"].ToString());

            data.Them(IDHangHoa, float.Parse(txtGiaTri + ""), NgayBatDau, NgayKetThuc);
            e.Cancel = true;
            gridChietKhauTheoHangHoa.CancelEdit();
            LoadGrid();

            ActionServer.CapNhatServer();
            dtLichSuTruyCap.ThemLichSu(Session["IDNhanVien"].ToString(), Session["IDNhom"].ToString(), "Chiết khấu theo hàng hóa: ", dtSetting.LayIDKho(), "Danh Mục", "Thêm");
        }

        protected void gridChietKhauTheoHangHoa_RowUpdating(object sender, DevExpress.Web.Data.ASPxDataUpdatingEventArgs e)
        {
            int ID = Int32.Parse(e.Keys["ID"].ToString());
            int IDHangHoa = Int32.Parse(e.NewValues["IDHangHoa"].ToString());

            double GiaTri = double.Parse(e.NewValues["GiaTri"].ToString());
            double txtGiaTri = Math.Round((GiaTri / 100), 2);

            DateTime NgayBatDau = DateTime.Parse(e.NewValues["NgayBatDau"].ToString());
            DateTime NgayKetThuc = DateTime.Parse(e.NewValues["NgayKetThuc"].ToString());
            data.Sua(ID, IDHangHoa, float.Parse(txtGiaTri + ""), NgayBatDau, NgayKetThuc);

            e.Cancel = true;
            gridChietKhauTheoHangHoa.CancelEdit();
            LoadGrid();

            ActionServer.CapNhatServer();
            dtLichSuTruyCap.ThemLichSu(Session["IDNhanVien"].ToString(), Session["IDNhom"].ToString(), "Chiết khấu theo hàng hóa: " +  ID, dtSetting.LayIDKho(), "Danh Mục", "Cập Nhật"); 
        }
    }
}