﻿using BanHang.Data;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace BanHang
{
    public partial class ThongTinCuaHangKho : System.Web.UI.Page
    {
        dtThongTinCuaHangKho data = new dtThongTinCuaHangKho();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["KTDangNhap"] != "GPM")
            {
                Response.Redirect("DangNhap.aspx");
            }
            else
            {
                if (dtSetting.LayTrangThaiMenu_ChucNang(Session["IDNhom"].ToString(), 40) == 1)
                    gridThongTinCuaHangKho.Columns["iconaction"].Visible = false;


                if (dtSetting.LayTrangThaiMenu(Session["IDNhom"].ToString(), 40) == 1)
                {
                    LoadGrid();
                }
                else
                {
                    Response.Redirect("Default.aspx");
                }
            }
        }

        private void LoadGrid()
        {
            data = new dtThongTinCuaHangKho();
            gridThongTinCuaHangKho.DataSource = data.LayDanhSach();
            gridThongTinCuaHangKho.DataBind();
        }

        protected void gridThongTinCuaHangKho_RowDeleting(object sender, DevExpress.Web.Data.ASPxDataDeletingEventArgs e)
        {
            int ID = Int32.Parse(e.Keys[0].ToString());
            data = new dtThongTinCuaHangKho();
            data.Xoa(ID);
            e.Cancel = true;
            gridThongTinCuaHangKho.CancelEdit();
            LoadGrid();

            ActionServer.CapNhatServer();
            dtLichSuTruyCap.ThemLichSu(Session["IDNhanVien"].ToString(), Session["IDNhom"].ToString(), "Thông tin cửa hàng kho:" + ID, dtSetting.LayIDKho(), "Hệ Thống", "Xóa");   
        }

        protected void gridThongTinCuaHangKho_RowInserting(object sender, DevExpress.Web.Data.ASPxDataInsertingEventArgs e)
        {
            string TenCuaHang = e.NewValues["TenCuaHang"].ToString();
            string SoSerial = e.NewValues["SoSerial"] == null ? "" : e.NewValues["SoSerial"].ToString();
            string DiaChi = e.NewValues["DiaChi"] == null ? "" : e.NewValues["DiaChi"].ToString();
            int IDQuan = Int32.Parse(e.NewValues["IDQuan"] == null ? "" : e.NewValues["IDQuan"].ToString());
            int IDThanhPho = Int32.Parse(e.NewValues["IDThanhPho"] == null ? "" : e.NewValues["IDThanhPho"].ToString());
            string DienThoai = e.NewValues["DienThoai"] == null ? "" : e.NewValues["DienThoai"].ToString();

            string MaKho = e.NewValues["MaKho"] == null ? "" : e.NewValues["MaKho"].ToString();
            DateTime NgayMo = DateTime.Parse(e.NewValues["NgayCapNhat"].ToString());
            int IDVung = Int32.Parse(e.NewValues["IDVung"].ToString());
            data = new dtThongTinCuaHangKho();
            object id = data.Them(TenCuaHang, SoSerial, DiaChi, IDQuan, IDThanhPho, DienThoai, MaKho.Trim(), NgayMo, IDVung);

            // Thêm hàng hóa vào tồn kho...
            dtHangHoa dt = new dtHangHoa();
            DataTable da = dt.LayDanhSachHangHoa_Full();
            for (int i = 0; i < da.Rows.Count; i++)
            {
                DataRow dr = da.Rows[i];
                int IDHangHoa = Int32.Parse(dr["ID"].ToString());
                float GiaBan = float.Parse(dr["GiaBan1"].ToString());
                int SoLuongCon = 0;
                DateTime NgayCapNhat = DateTime.Now;
                dt.ThemHangVaoTonKho(id, IDHangHoa, SoLuongCon, NgayCapNhat, GiaBan);

            }


            e.Cancel = true;
            gridThongTinCuaHangKho.CancelEdit();
            LoadGrid();

            ActionServer.CapNhatServer();
            dtLichSuTruyCap.ThemLichSu(Session["IDNhanVien"].ToString(), Session["IDNhom"].ToString(), "Thông tin cửa hàng kho", dtSetting.LayIDKho(), "Hệ Thống", "Thêm");   
        }

        protected void gridThongTinCuaHangKho_RowUpdating(object sender, DevExpress.Web.Data.ASPxDataUpdatingEventArgs e)
        {
            int ID = Int32.Parse(e.Keys["ID"].ToString());
            string TenCuaHang = e.NewValues["TenCuaHang"].ToString();
            string SoSerial = e.NewValues["SoSerial"] == null ? "" : e.NewValues["SoSerial"].ToString();
            string DiaChi = e.NewValues["DiaChi"] == null ? "" : e.NewValues["DiaChi"].ToString();
            int IDQuan = Int32.Parse(e.NewValues["IDQuan"] == null ? "" : e.NewValues["IDQuan"].ToString());
            int IDThanhPho = Int32.Parse(e.NewValues["IDThanhPho"] == null ? "" : e.NewValues["IDThanhPho"].ToString());
            string DienThoai = e.NewValues["DienThoai"] == null ? "" : e.NewValues["DienThoai"].ToString();
            string MaKho = e.NewValues["MaKho"] == null ? "" : e.NewValues["MaKho"].ToString();
            DateTime NgayMo = DateTime.Parse(e.NewValues["NgayCapNhat"].ToString());
            int IDVung = Int32.Parse(e.NewValues["IDVung"].ToString());

            data.Sua(ID, TenCuaHang, SoSerial, DiaChi, IDQuan, IDThanhPho, DienThoai, MaKho.Trim(), NgayMo, IDVung);
            e.Cancel = true;
            gridThongTinCuaHangKho.CancelEdit();

            LoadGrid();

            ActionServer.CapNhatServer();
            dtLichSuTruyCap.ThemLichSu(Session["IDNhanVien"].ToString(), Session["IDNhom"].ToString(), "Thông tin cửa hàng kho", dtSetting.LayIDKho(), "Hệ Thống", "Cập Nhật");   
        }
    }
}