﻿using BanHang.Data;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace BanHang
{
    public partial class GiaTheoVung : System.Web.UI.Page
    {
        dtGiaTheoVung data = new dtGiaTheoVung();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["KTDangNhap"] != "GPM")
            {
                Response.Redirect("DangNhap.aspx");
            }
            else
            {
                if (dtSetting.LayTrangThaiMenu_ChucNang(Session["IDNhom"].ToString(), 9) == 1)
                    Response.Redirect("Default.aspx");
                if (dtSetting.LayTrangThaiMenu(Session["IDNhom"].ToString(), 9) == 1)
                {
                    if (!IsPostBack)
                    {
                        DanhSachVung();
                    }
                    LoadGrid();
                }
                else
                {
                    Response.Redirect("Default.aspx");
                }
            }  
        }

        private void DanhSachVung()
        {
            data = new dtGiaTheoVung();
            DanhSachKho.DataSource = data.LayDanhSachKho();
            DanhSachKho.ValueField = "ID";
            DanhSachKho.TextField = "TenCuaHang";
            DanhSachKho.DataBind();

            dtVung dt1 = new dtVung();
            DataTable d2x = dt1.LayDanhSach();
            d2x.Rows.Add(-1,0 ,"Tất cả Vùng", 0);

            cmbVung.DataSource = d2x;
            cmbVung.ValueField = "ID";
            cmbVung.TextField = "TenVung";
            cmbVung.DataBind();
            cmbVung.SelectedIndex = cmbVung.Items.Count;


            dtNhomHang d2 = new dtNhomHang();
            DataTable d2x1 = d2.LayDanhSachNhomHang();
            d2x1.Rows.Add(-1, "Tất cả Nhóm Hàng", DateTime.Now.Date, 0);
            LayoutGiaTheoVung_E2.DataSource = d2x1;
            LayoutGiaTheoVung_E2.TextField = "TenNhomHang";
            LayoutGiaTheoVung_E2.ValueField = "ID";
            LayoutGiaTheoVung_E2.DataBind();
            LayoutGiaTheoVung_E2.SelectedIndex = LayoutGiaTheoVung_E2.Items.Count;

        }

        private void LoadGrid()
        {
            data = new dtGiaTheoVung();
          
            int ID = Int32.Parse(LayoutGiaTheoVung_E2.Value.ToString());
            dtHangHoa dt = new dtHangHoa();
            DataTable da = dt.LayDanhSachHangHoa_IDNhomHang(ID);
            gridHangHoa.DataSource = da;
            gridHangHoa.DataBind();
    

           
           
        }
        protected void LayoutGiaTheoVung_E2_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (LayoutGiaTheoVung_E2.Text != "")
            {
                int ID = Int32.Parse(LayoutGiaTheoVung_E2.Value.ToString());
                dtHangHoa dt = new dtHangHoa();
                DataTable da = dt.LayDanhSachHangHoa_IDNhomHang(ID);
                gridHangHoa.DataSource = da;
                gridHangHoa.DataBind();
            }
        }

        protected void cmbVung_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cmbVung.Text != "")
            {
                int ID = Int32.Parse(cmbVung.Value.ToString());
                data = new dtGiaTheoVung();
                DanhSachKho.DataSource = data.LayDanhSachKho_IDVung(ID);
                DanhSachKho.ValueField = "ID";
                DanhSachKho.TextField = "TenCuaHang";
                DanhSachKho.DataBind();

            }
        }
        protected void gridHangHoa_RowUpdating(object sender, DevExpress.Web.Data.ASPxDataUpdatingEventArgs e)
        {
            int IDHangHoa = Int32.Parse(e.Keys[0].ToString());
            int IDDonViTinh = Int32.Parse(e.NewValues["IDDonViTinh"].ToString());
            float GiaMoi = float.Parse(e.NewValues["GiaBan"].ToString());
            float Gia1 = float.Parse(e.NewValues["GiaBan1"].ToString());
            if (DanhSachKho.SelectedItems.Count != 0)
            {
                for (int i = DanhSachKho.Items.Count - 1; i >= 0; i--)
                {
                    if (DanhSachKho.Items[i].Selected == true)
                    {
                        int IDKho = Int32.Parse(DanhSachKho.Items[i].Value.ToString());
                        dtGiaTheoVung.Update_GiaTheoVung(IDKho, IDHangHoa, GiaMoi);
                        dtHangHoa dtx = new dtHangHoa();
                        
                        dtx.ThemLichSuThayDoiGia(IDHangHoa, IDDonViTinh, Gia1, GiaMoi, Int32.Parse(Session["IDNhanVien"].ToString()),e.NewValues["MaHang"].ToString());

                        dtLichSuTruyCap.ThemLichSu(Session["IDNhanVien"].ToString(), Session["IDNhom"].ToString(), "Giá Theo Vùng:" + IDHangHoa+": "+GiaMoi, dtSetting.LayIDKho(), "Danh Mục", "Cập Nhât"); 
                        
                    }
                }
                e.Cancel = true;
                gridHangHoa.CancelEdit();
                LoadGrid();
                

               
            }
            else
            {
                throw new Exception("Lỗi: Chưa chọn kho để áp dụng giá mới?");
               // Response.Write("<script language='JavaScript'> alert('Chưa chọn kho để áp dụng giá mới.'); </script>");
            }
            //Response.RedirectLocation("DanhSachGiaTheoVung.aspx");
            //HttpContext.Current.Response.RedirectPermanent("DanhSachGiaTheoVung.aspx");
            //Response.RedirectToRoute("DanhSachGiaTheoVung.aspx");
            //throw new Exception("Thông báo: Cập nhật giá mới thành công!");
        }

       

     
       

        
    }
}