﻿using BanHang.Data;
using BanHang.Report;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace BanHang
{
    public partial class InBaoCaoTraHang : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            int idNganh = Int32.Parse(Request.QueryString["nganh"]);
            int idNhom = Int32.Parse(Request.QueryString["nhom"]);
            int idKho = Int32.Parse(Request.QueryString["khohang"]);
            int idKhachHang = Int32.Parse(Request.QueryString["khachhang"]);
            string strNganh = "Tất cả ngành hàng", strNhom = "Tất cả nhóm hàng", strKho = "Tất cả kho hàng", strKhachHang = "Tất cả khách hàng";

            dtThongTinCuaHangKho dt = new dtThongTinCuaHangKho();
            DataTable da = dt.LayDanhSach_ID_2(dtSetting.LayIDKho());
            DataRow dr = da.Rows[0];
            string strCty = dr["TenCuaHang"].ToString();

            if (idNganh != -1)
            {
                dtNganhHang d = new dtNganhHang();
                da = d.LayDanhSachNganhHang_ID(idNganh);
                if (da.Rows.Count != 0)
                {
                    dr = da.Rows[0];
                    strNganh = dr["TenNganhHang"].ToString();
                }
            }
            if (idNhom != -1)
            {
                dtNhomHang d = new dtNhomHang();
                da = d.LayDanhSachNhomHang_ID(idNhom);
                if (da.Rows.Count != 0)
                {
                    dr = da.Rows[0];
                    strNhom = dr["TenNhomHang"].ToString();
                }
            }
            if (idKho != -1)
            {
                dtThongTinCuaHangKho d = new dtThongTinCuaHangKho();
                da = d.LayDanhSach_ID_2(idKho);
                if (da.Rows.Count != 0)
                {
                    dr = da.Rows[0];
                    strKho = dr["TenCuaHang"].ToString();
                }
            }
            if (idKhachHang != -1)
            {
                dtKhachHang d = new dtKhachHang();
                da = d.LayDanhSachKhachHang_ID(idKhachHang);
                if (da.Rows.Count != 0)
                {
                    dr = da.Rows[0];
                    strKhachHang = dr["TenNhomKhachHang"].ToString();
                }
            }

            rpBaoCaoTraHang rp = new rpBaoCaoTraHang();
            rp.Parameters["strCty"].Value = strCty;
            rp.Parameters["strNhom"].Value = strNhom;
            rp.Parameters["strNganh"].Value = strNganh;
            rp.Parameters["strKho"].Value = strKho;
            rp.Parameters["strKhachHang"].Value = strKhachHang;

            rp.Parameters["strCty"].Visible = false;
            rp.Parameters["strNhom"].Visible = false;
            rp.Parameters["strNganh"].Visible = false;
            rp.Parameters["strKho"].Visible = false;
            rp.Parameters["strKhachHang"].Visible = false;

            rp.Parameters["NganhHang"].Value = idNganh;
            rp.Parameters["NhomHang"].Value = idNhom;
            rp.Parameters["KhoHang"].Value = idKho;
            rp.Parameters["KhachHang"].Value = idKhachHang;

            rp.Parameters["NganhHang"].Visible = false;
            rp.Parameters["NhomHang"].Visible = false;
            rp.Parameters["KhoHang"].Visible = false;
            rp.Parameters["KhachHang"].Visible = false;

            rp.Parameters["NgayBD"].Value = Request.QueryString["ngaybd"] + " 00:00:00.000";
            rp.Parameters["NgayBD"].Visible = false;
            rp.Parameters["NgayKT"].Value = Request.QueryString["ngaykt"] + " 23:59:59.000";
            rp.Parameters["NgayKT"].Visible = false;
            DateTime d1 = DateTime.Parse(Request.QueryString["ngaybd"]);
            string s = d1.Date.ToString("dd/MM/yyyy");
            DateTime d2 = DateTime.Parse(Request.QueryString["ngaykt"]);
            string s2 = d2.Date.ToString("dd/MM/yyyy");
            rp.Parameters["strNgay"].Value = s + " - " + s2;
            rp.Parameters["strNgay"].Visible = false;
            reportView.Report = rp;
        }
    }
}