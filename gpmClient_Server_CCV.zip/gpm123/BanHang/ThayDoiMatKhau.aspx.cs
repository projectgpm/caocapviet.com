﻿using BanHang.Data;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace BanHang
{
    public partial class ThayDoiMatKhau : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (dtSetting.LayTrangThaiMenu(Session["IDNhom"].ToString(), 56) == 1)
            {
                if (Session["KTDangNhap"] != "GPM")
                {
                    Response.Redirect("DangNhap.aspx");
                }
            }
            else
            {
                Response.Redirect("Default.aspx");
            }

        }
        protected void btnThayDoiMatKhau_Click(object sender, EventArgs e)
        {
            if (KiemTra() == true)
            {
                dtCheckDangNhap data = new dtCheckDangNhap();
                DataTable db = data.KiemTraNguoiDung(Session["UserName"].ToString(), ActionCilent.GetSHA1HashData(txtMatKhauCu.Value.ToString()));
                if (db.Rows.Count != 0)
                {
                    if (KiemTraMatKhauKhop() == true)
                    {
                        int ID = Int32.Parse(Session["IDNhanVien"].ToString());
                        data = new dtCheckDangNhap();
                        string sha1 = ActionCilent.GetSHA1HashData(txtMatKhauMoi2.Value.ToString());
                        data.DoiMatKhau(ID, sha1);
                        Session["KTDangNhap"] = null;
                        Response.Redirect("DangNhap.aspx");

                        dtLichSuTruyCap.ThemLichSu(Session["IDNhanVien"].ToString(), Session["IDNhom"].ToString(), "Thây đổi mật khẩu: " + Session["UserName"].ToString(), dtSetting.LayIDKho(), "Hệ thống", "Cập Nhật"); 
                        //Response.Write("<script language='JavaScript'> alert('Mật Khẩu củ không đúng.'); </script>");
                    }
                }
                Response.Write("<script language='JavaScript'> alert('Mật Khẩu củ không đúng.'); </script>");
            }
           
        }
        protected void btnHuy_Click(object sender, EventArgs e)
        {
            Response.Redirect("Default.aspx");
        }
        public bool KiemTra()
        {
            if (txtMatKhauCu.Value.ToString() == "" || txtMatKhauMoi1.Value.ToString() == "" || txtMatKhauMoi2.Value.ToString() == "")
            {
                Response.Write("<script language='JavaScript'> alert('Vui lòng điền đầy đủ thông tin đăng nhập.'); </script>");
                return false;
            }
            return true;
        }
        public bool KiemTraMatKhauKhop()
        {
            if (txtMatKhauMoi1.Value.ToString() != txtMatKhauMoi2.Value.ToString())
            {
                Response.Write("<script language='JavaScript'> alert('Mật Khẩu Nhập Lại không khớp.'); </script>");
                return false;
            }
            return true;
        }
        
    }
}