﻿using BanHang.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace BanHang
{
    public partial class ChiecKhauTheoKhachHang : System.Web.UI.Page
    {
        dtChietKhauKhachHang data = new dtChietKhauKhachHang();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (dtSetting.LayTrangThaiMenu_ChucNang(Session["IDNhom"].ToString(), 11) == 1)
                gridChietKhauTheoKhachHang.Columns["iconaction"].Visible = false;

            if (dtSetting.LayTrangThaiMenu(Session["IDNhom"].ToString(), 11) == 1)
            {
                LoadGrid();
            }
            else
            { Response.Redirect("Default.aspx"); }
        }

        private void LoadGrid()
        {
            data = new dtChietKhauKhachHang();
            gridChietKhauTheoKhachHang.DataSource = data.LayDanhSachChietKhauKhachHang();
            gridChietKhauTheoKhachHang.DataBind();
        }

        protected void gridChietKhauTheoKhachHang_RowDeleting(object sender, DevExpress.Web.Data.ASPxDataDeletingEventArgs e)
        {
            string ID = e.Keys[0].ToString();
            data = new dtChietKhauKhachHang();
            data.XoaChietKhauKhachHang(Int32.Parse(ID));
            e.Cancel = true;
            gridChietKhauTheoKhachHang.CancelEdit();
            LoadGrid();

            ActionServer.CapNhatServer();
            dtLichSuTruyCap.ThemLichSu(Session["IDNhanVien"].ToString(), Session["IDNhom"].ToString(), "Chiết khấu theo khách hàng: ", dtSetting.LayIDKho(), "Danh Mục", "Xóa");
        }

        protected void gridChietKhauTheoKhachHang_RowInserting(object sender, DevExpress.Web.Data.ASPxDataInsertingEventArgs e)
        {
            DateTime NgayCapNhat = DateTime.Today.Date;
            data = new dtChietKhauKhachHang();
            int IDKhachHang = Int32.Parse(e.NewValues["IDKhachHang"].ToString());
            int IDHangHoa = Int32.Parse(e.NewValues["IDHangHoa"].ToString());
            double GiaTri = double.Parse(e.NewValues["GiaTri"].ToString());

            double txtGiaTri = Math.Round((GiaTri / 100), 2);
            DateTime NgayBatDau = DateTime.Parse(e.NewValues["NgayBatDau"].ToString());
            DateTime NgayKetThuc = DateTime.Parse(e.NewValues["NgayKetThuc"].ToString());
            data.ThemChietKhauKhachHang(IDKhachHang, IDHangHoa, float.Parse(txtGiaTri+""), NgayBatDau, NgayKetThuc, NgayCapNhat);
            e.Cancel = true;
            gridChietKhauTheoKhachHang.CancelEdit();
            LoadGrid();

            ActionServer.CapNhatServer();
            dtLichSuTruyCap.ThemLichSu(Session["IDNhanVien"].ToString(), Session["IDNhom"].ToString(), "Chiết khấu theo khách hàng: ", dtSetting.LayIDKho(), "Danh Mục", "Thêm");
        }

        protected void gridChietKhauTheoKhachHang_RowUpdating(object sender, DevExpress.Web.Data.ASPxDataUpdatingEventArgs e)
        {
            string ID = e.Keys[0].ToString();
            int IDKhachHang = Int32.Parse(e.NewValues["IDKhachHang"].ToString());
            int IDHangHoa = Int32.Parse(e.NewValues["IDHangHoa"].ToString());

            double GiaTri = Int32.Parse(e.NewValues["GiaTri"].ToString());
            double txtGiaTri = Math.Round((GiaTri / 100), 2);
            DateTime NgayBatDau = DateTime.Parse(e.NewValues["NgayBatDau"].ToString());
            DateTime NgayKetThuc = DateTime.Parse(e.NewValues["NgayKetThuc"].ToString());
            DateTime NgayCapNhat = DateTime.Today.Date;
            data.SuaChietKhauKhachHang(Int32.Parse(ID), IDKhachHang, IDHangHoa, float.Parse(txtGiaTri + ""), NgayBatDau, NgayKetThuc, NgayCapNhat);
            e.Cancel = true;
            gridChietKhauTheoKhachHang.CancelEdit();
            LoadGrid();

            ActionServer.CapNhatServer();
            dtLichSuTruyCap.ThemLichSu(Session["IDNhanVien"].ToString(), Session["IDNhom"].ToString(), "Chiết khấu theo khách hàng: ", dtSetting.LayIDKho(), "Danh Mục", "Cập Nhật");
        }
    }
}