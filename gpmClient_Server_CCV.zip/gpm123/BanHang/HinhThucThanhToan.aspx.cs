﻿using BanHang.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace BanHang
{
    public partial class HinhThucThanhToan : System.Web.UI.Page
    {
        dtHinhThucThanhToan data = new dtHinhThucThanhToan();
        protected void Page_Load(object sender, EventArgs e)
        {
           
                LoadGrid();
           

        }
        public void LoadGrid()
        {
            data = new dtHinhThucThanhToan();
            gridHinhThucThanhToan.DataSource = data.LayDanhSachHinhThucThanhToan();
            gridHinhThucThanhToan.DataBind();
        }

        protected void gridHinhThucThanhToan_RowDeleting(object sender, DevExpress.Web.Data.ASPxDataDeletingEventArgs e)
        {
            string ID = e.Keys[0].ToString();
            data = new dtHinhThucThanhToan();
            data.XoaHinhThucThanhToan(Int32.Parse(ID));
            e.Cancel = true;
            gridHinhThucThanhToan.CancelEdit();
            LoadGrid();

            ActionServer.CapNhatServer();
            dtLichSuTruyCap.ThemLichSu(Session["IDNhanVien"].ToString(), Session["IDNhom"].ToString(), "Hình Thức Thanh Toán", dtSetting.LayIDKho(), "Danh Mục", "Xóa");
        }

        protected void gridHinhThucThanhToan_RowInserting(object sender, DevExpress.Web.Data.ASPxDataInsertingEventArgs e)
        {
            data = new dtHinhThucThanhToan();
            string TenHinhThuc = e.NewValues["TenHinhThuc"].ToString();
            int TiLe = int.Parse(e.NewValues["TiLe"].ToString());
            DateTime NgayCapNhat = DateTime.Today.Date;
            data.ThemHinhThucThanhToan(TenHinhThuc, TiLe, NgayCapNhat);
            e.Cancel = true;
            gridHinhThucThanhToan.CancelEdit();
            LoadGrid();

            ActionServer.CapNhatServer();
            dtLichSuTruyCap.ThemLichSu(Session["IDNhanVien"].ToString(), Session["IDNhom"].ToString(), "Hình Thức Thanh Toán", dtSetting.LayIDKho(), "Danh Mục", "Thêm");
        }

        protected void gridHinhThucThanhToan_RowUpdating(object sender, DevExpress.Web.Data.ASPxDataUpdatingEventArgs e)
        {

            data = new dtHinhThucThanhToan();
            string TenHinhThuc = e.NewValues["TenHinhThuc"].ToString();
            int TiLe = int.Parse(e.NewValues["TiLe"].ToString());
            DateTime NgayCapNhat = DateTime.Today.Date;
            int ID = int.Parse(e.Keys["ID"].ToString());
            data.SuaHinhThucThanhToan(ID, TenHinhThuc, TiLe, NgayCapNhat);
            e.Cancel = true;
            gridHinhThucThanhToan.CancelEdit();
            LoadGrid();

            ActionServer.CapNhatServer();
            dtLichSuTruyCap.ThemLichSu(Session["IDNhanVien"].ToString(), Session["IDNhom"].ToString(), "Hình Thức Thanh Toán", dtSetting.LayIDKho(), "Danh Mục", "Cập Nhật");
        }
    }
}