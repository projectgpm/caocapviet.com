﻿using BanHang.Data;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace BanHang
{
    public partial class NhanVienThuNgan : System.Web.UI.Page
    {
        dtNhanVienThuNgan data = new dtNhanVienThuNgan();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["KTDangNhap"] != "GPM")
            {
                Response.Redirect("DangNhap.aspx");
            }
            else
            {
                if (dtSetting.LayTrangThaiMenu_ChucNang(Session["IDNhom"].ToString(), 38) == 1)
                    gridNhanVienThuNgan.Columns["iconaction"].Visible = false;


                if (dtSetting.LayTrangThaiMenu(Session["IDNhom"].ToString(), 38) == 1)
                {
                    LoadGrid();
                }
                else
                {
                    Response.Redirect("Default.aspx");
                }
            }
        }

        private void LoadGrid()
        {
            data = new dtNhanVienThuNgan();
            gridNhanVienThuNgan.DataSource = data.LayDanhSachNhanVienThuNgan();
            gridNhanVienThuNgan.DataBind();
        }

        protected void gridNhanVienThuNgan_RowDeleting(object sender, DevExpress.Web.Data.ASPxDataDeletingEventArgs e)
        {
            int ID = Int32.Parse(e.Keys[0].ToString());
            data = new dtNhanVienThuNgan();
            data.XoaNhanVienThuNgan(ID);
            e.Cancel = true;
            gridNhanVienThuNgan.CancelEdit();
            LoadGrid();
            dtLichSuTruyCap.ThemLichSu(Session["IDNhanVien"].ToString(), Session["IDNhom"].ToString(), "Nhân viên thu ngân", dtSetting.LayIDKho(), "Hệ Thống", "Xóa"); ;   
        }

        protected void gridNhanVienThuNgan_RowInserting(object sender, DevExpress.Web.Data.ASPxDataInsertingEventArgs e)
        {
            data = new dtNhanVienThuNgan();
            string TenNhanVien = e.NewValues["TenNhanVien"].ToString();
            string TenDangNhap = e.NewValues["TenDangNhap"].ToString().ToUpper();
            int IDCaBan = Int32.Parse(e.NewValues["IDCaBan"].ToString());
            string MatKhau = e.NewValues["MatKhau"].ToString();
            MatKhau = ActionCilent.GetSHA1HashData(MatKhau);
            int TrangThai = Int32.Parse(e.NewValues["TrangThai"] == null ? "0": e.NewValues["TrangThai"].ToString());

            DataTable db = data.KiemTraNhanVien(TenDangNhap);

            if (db.Rows.Count == 0)
            {
                data.ThemNhanVienThuNgan(TenNhanVien, TenDangNhap, IDCaBan, MatKhau, TrangThai);
                e.Cancel = true;
                gridNhanVienThuNgan.CancelEdit();
                LoadGrid();
                dtLichSuTruyCap.ThemLichSu(Session["IDNhanVien"].ToString(), Session["IDNhom"].ToString(), "Nhân viên thu ngân", dtSetting.LayIDKho(), "Hệ Thống", "Thêm"); ;   
            }
            else
            {
                throw new Exception("Lỗi: Tên đăng nhập đã tồn tại");
            }
        }

       
        protected void gridNhanVienThuNgan_RowUpdating(object sender, DevExpress.Web.Data.ASPxDataUpdatingEventArgs e)
        {
            int ID = Int32.Parse(e.Keys["ID"].ToString());
            string TenNhanVien = e.NewValues["TenNhanVien"].ToString();
            string TenDangNhap = e.NewValues["TenDangNhap"].ToString().ToUpper();
            int IDCaBan = Int32.Parse(e.NewValues["IDCaBan"].ToString());
            string MatKhau = e.NewValues["MatKhau"].ToString();
            MatKhau = ActionCilent.GetSHA1HashData(MatKhau);
            int TrangThai = Int32.Parse(e.NewValues["TrangThai"] == null ? "0" : e.NewValues["TrangThai"].ToString());
            //DataTable db = data.KiemTraNhanVien(TenDangNhap);
            //if (db.Rows.Count == 0)
            //{
                data.SuaNhanVienThuNgan(ID, TenNhanVien, TenDangNhap, IDCaBan, MatKhau, TrangThai);
                e.Cancel = true;
                gridNhanVienThuNgan.CancelEdit();
                LoadGrid();
                dtLichSuTruyCap.ThemLichSu(Session["IDNhanVien"].ToString(), Session["IDNhom"].ToString(), "Nhân viên thu ngân", dtSetting.LayIDKho(), "Hệ Thống", "Cập Nhật"); ;   
            //}
            //else
            //{
            //    throw new Exception("Lỗi: Tên đăng nhập đã tồn tại");
            //}

        }
    }
}