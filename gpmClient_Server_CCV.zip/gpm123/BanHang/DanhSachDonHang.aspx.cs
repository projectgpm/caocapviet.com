﻿using BanHang.Data;
using DevExpress.Web;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
namespace BanHang
{
    public partial class DanhSachDonHang : System.Web.UI.Page
    {
        dtDonHang data = new dtDonHang();
        protected void Page_Load(object sender, EventArgs e)
        {
            LoadGrid();
        }

        private void LoadGrid()
        {
            data = new dtDonHang();
            gridDanhSachDonHang.DataSource = data.LayDanhSach();
            gridDanhSachDonHang.DataBind();
        }

      
    }
}