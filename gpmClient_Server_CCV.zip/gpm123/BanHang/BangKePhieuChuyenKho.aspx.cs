﻿using BanHang.Data;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace BanHang
{
    public partial class BangKePhieuChuyenKho : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["KTDangNhap"] != "GPM")
            {
                Response.Redirect("DangNhap.aspx");
            }
            else
            {
                if (dtSetting.LayTrangThaiMenu(Session["IDNhom"].ToString(), 25) == 1)
                {
                    if (!IsPostBack)
                    {
                        dtThongTinCuaHangKho d = new dtThongTinCuaHangKho();
                        DataTable dx = d.LayDanhSach();
                        dx.Rows.Add(-1, "Tất cả Cửa Hàng", "", "", 0, 0, "", DateTime.Now.Date, 0);

                        cmbKhoXuat.DataSource = dx;
                        cmbKhoXuat.TextField = "TenCuaHang";
                        cmbKhoXuat.ValueField = "ID";
                        cmbKhoXuat.DataBind();
                        cmbKhoXuat.Value = dtSetting.LayIDKho() + "";

                        cmbKhoNhap.DataSource = dx;
                        cmbKhoNhap.TextField = "TenCuaHang";
                        cmbKhoNhap.ValueField = "ID";
                        cmbKhoNhap.DataBind();
                        cmbKhoNhap.SelectedIndex = cmbKhoNhap.Items.Count;

                        txtNgayBD.Date = DateTime.Today.AddDays(-30);
                        txtNgayKT.Date = DateTime.Today;
                    }
                }
                else
                {
                    Response.Redirect("Default.aspx");
                }
            }

        }

        protected void btnIn_Click1(object sender, EventArgs e)
        {
            string ngaybd = txtNgayBD.Date.ToString("yyyy-MM-dd");
            string ngaykt = txtNgayKT.Date.ToString("yyyy-MM-dd");
            string khoxuat = cmbKhoXuat.Value + "";
            string khonhap = cmbKhoNhap.Value + "";
            popup.ContentUrl = "~/InBangKePhieuChuyenKho.aspx?khoxuat=" + khoxuat + "&khonhap=" + khonhap + "&ngaybd=" + ngaybd + "&ngaykt=" + ngaykt;
            popup.ShowOnPageLoad = true;
        }
    }
}