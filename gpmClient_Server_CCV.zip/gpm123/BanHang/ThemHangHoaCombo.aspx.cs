﻿using BanHang.Data;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace BanHang
{
    public partial class ThemHangHoaCombo : System.Web.UI.Page
    {
        dtHangCombo data = new dtHangCombo();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["KTDangNhap"] != "GPM")
            {
                Response.Redirect("DangNhap.aspx");
            }
            else
            {
                if (dtSetting.LayTrangThaiMenu_ChucNang(Session["IDNhom"].ToString(), 8) == 1)
                    Response.Redirect("Default.aspx");
                if (dtSetting.LayTrangThaiMenu(Session["IDNhom"].ToString(), 8) == 1)
                {
                    if (!IsPostBack)
                    {
                        data = new dtHangCombo();
                        data.XoaHangHoa_Null();
                        object IDHangHoaComBo = data.ThemIDHangHoa_Temp();
                        IDHangHoaComBo_Temp.Value = IDHangHoaComBo.ToString();
                        txtSoLuong.Text = "0";

                        ActionServer.CapNhatServer();
                    }
                    dtHangHoa dt = new dtHangHoa();
                    cmbHangHoa.DataSource = dt.LayDanhSachHangHoa_BanHangCombo();
                    cmbHangHoa.TextField = "TenHangHoa";
                    cmbHangHoa.ValueField = "ID";
                    cmbHangHoa.DataBind();

                    LoadGrid(Int32.Parse(IDHangHoaComBo_Temp.Value.ToString()));
                }
                else
                {
                    Response.Redirect("Default.aspx");
                }
            }
            
        }

        protected void btnHuy_Click(object sender, EventArgs e)
        {
            data = new dtHangCombo();
            int IDHangHoaComBo = Int32.Parse(IDHangHoaComBo_Temp.Value.ToString());
            data.XoaHangHoa_Temp_IDHangCombo(IDHangHoaComBo);
            data.XoaHangHoa_Null();
            Response.Redirect("DanhMucCombo.aspx");
        }

        protected void btnThem_Click(object sender, EventArgs e)
        {
            if (txtMaHang.Text != "" && cmbDonViTinh.Text != ""  && txtTenHangHoa.Text != "" && txtGiaBan.Text != "" && txtBarcode.Text != "")
            {
                data = new dtHangCombo();
                int IDHangHoaComBo = Int32.Parse(IDHangHoaComBo_Temp.Value.ToString());
                DataTable dt = data.DanhSachHangHoaCombo_Temp(IDHangHoaComBo);
                if (dt.Rows.Count != 0)
                {
                    string MaHang = txtMaHang.Text;
                    int IDDonViTinh = Int32.Parse(cmbDonViTinh.Value.ToString());
             
                    string txtTenHangComBo = txtTenHangHoa.Text.ToString();
                    float GiaBan = float.Parse(txtGiaBan.Text.ToString());
                    data = new dtHangCombo();

                    dtImportHangHoa hh1 = new dtImportHangHoa();
                    DataTable dd = hh1.KiemTraHangHoa(MaHang);
                    if (dd.Rows.Count == 0)
                    {
                        data.CapNhatHangHoa(IDHangHoaComBo, MaHang, IDDonViTinh, txtTenHangComBo, GiaBan);
                        //-----------------------------------------------
                        int SL_ComBo = Int32.Parse(txtSLCombo.Text);
                        string barcode = txtBarcode.Text.Trim();
                        dtHangHoa hh = new dtHangHoa();
                        hh.ThemHangVaoTonKho(dtSetting.LayIDKho(), IDHangHoaComBo, SL_ComBo, DateTime.Now, GiaBan);
                        hh.ThemBarCode(IDHangHoaComBo, barcode);


                        // Thêm hàng hóa vào các kho....
                        dtThongTinCuaHangKho dtx = new dtThongTinCuaHangKho();
                        DataTable dta = dtx.LayDanhSachCombo();
                        for (int i = 0; i < dta.Rows.Count; i++)
                        {
                            DataRow dr = dta.Rows[i];
                            int IDKho = Int32.Parse(dr["ID"].ToString());
                            dtHangHoa da = new dtHangHoa();
                            da.ThemHangVaoTonKho(IDKho, (int)IDHangHoaComBo, 0, DateTime.Now, GiaBan);
                        }

                        foreach (DataRow dr in dt.Rows)
                        {

                            int IDHangHoa = Int32.Parse(dr["IDHangHoa"].ToString());
                            int SoLuong = Int32.Parse(dr["SoLuong"].ToString());
                            float GiaBan1 = float.Parse(dr["GiaBan"].ToString());
                            float ThanhTien = float.Parse(dr["ThanhTien"].ToString());

                            data = new dtHangCombo();

                            data.ThemHangHoa(IDHangHoaComBo, IDHangHoa, SoLuong, GiaBan1, ThanhTien);
                            dtCapNhatTonKho tk = new dtCapNhatTonKho();
                            //trừ tồn kho


                            tk.TruTonKho_IDHangHoa(IDHangHoa, SoLuong * SL_ComBo, dtSetting.LayIDKho());
                        }
                        data.XoaHangHoa_Temp_IDHangCombo(IDHangHoaComBo);

                        dtLichSuTruyCap.ThemLichSu(Session["IDNhanVien"].ToString(), Session["IDNhom"].ToString(), "Hàng hóa combo", dtSetting.LayIDKho(), "Danh Mục", "Thêm");
                        Response.Redirect("DanhMucCombo.aspx");
                    }else
                        Response.Write("<script language='JavaScript'> alert('Mã hàng đã tồn tại.'); </script>");
                }
                else
                {
                    Response.Write("<script language='JavaScript'> alert('Danh sách hàng hóa combo rỗng.'); </script>");
                }
            }
            else
            {
                Response.Write("<script language='JavaScript'> alert('Vui lòng điền đầy đủ thoog tin hàng hóa combo.'); </script>");
            }
        }
        public void TinhTongTien()
        {
            data = new dtHangCombo();
            DataTable db = data.DanhSachHangHoaCombo_Temp(Int32.Parse(IDHangHoaComBo_Temp.Value.ToString()));
            if (db.Rows.Count != 0)
            {
                double TongTien = 0;
                foreach (DataRow dr in db.Rows)
                {
                    double ThanhTien = double.Parse(dr["ThanhTien"].ToString());
                    TongTien = TongTien + ThanhTien;
                }
                txtGiaBan.Text = "";
                 int SL_ComBo = Int32.Parse(txtSLCombo.Text);
                 txtGiaBan.Text = (TongTien * SL_ComBo).ToString();
            }
        }
        protected void gridDanhSachHangHoa_Temp_RowDeleting(object sender, DevExpress.Web.Data.ASPxDataDeletingEventArgs e)
        {
            int IDHangHoaComBo = Int32.Parse(IDHangHoaComBo_Temp.Value.ToString());
            int ID = Int32.Parse(e.Keys[0].ToString());
            data = new dtHangCombo();
            data.XoaHangHoa_Temp_ID(ID);
            e.Cancel = true;
            gridDanhSachHangHoa_Temp.CancelEdit();
            LoadGrid(IDHangHoaComBo);
        }

        protected void btnThem_Temp_Click(object sender, EventArgs e)
        {
            if (cmbHangHoa.Text != "")
            {
                int IDHangHoaComBo = Int32.Parse(IDHangHoaComBo_Temp.Value.ToString());
                int IDHangHoa = Int32.Parse(cmbHangHoa.Value.ToString());
                int SoLuong = Int32.Parse(txtSoLuong.Text.ToString());
                float DonGia = float.Parse(txtDonGia.Text.ToString());
                //double ThanhTien = double.Parse(txtThanhTien.Text.ToString());
                data = new dtHangCombo();

                DataTable db = data.KTHangHoa_Temp(IDHangHoa);// kiểm tra hàng hóa
                if (db.Rows.Count == 0)
                {
                    data = new dtHangCombo();
                    data.ThemHangHoa_Temp(IDHangHoaComBo, IDHangHoa, SoLuong, DonGia, SoLuong * DonGia);
                    TinhTongTien();
                    Clear();
                }
                else
                {
                    data = new dtHangCombo();
                    data.UpdateHangHoa_temp(IDHangHoaComBo, IDHangHoa, SoLuong, DonGia, SoLuong * DonGia);
                    TinhTongTien();
                    Clear();
                }
                LoadGrid(IDHangHoaComBo);
            }
            else
            {
                Response.Write("<script language='JavaScript'> alert('Bạn chưa chọn hàng hóa.'); </script>");
            }

        }
        public void Clear()
        {
            cmbHangHoa.Text = "";
            txtSoLuong.Text = "0";
            txtDonGia.Text = "";
            txtThanhTien.Text = "";
            txtTonKho.Text = "";
        }

        protected void cmbHangHoa_SelectedIndexChanged(object sender, EventArgs e)
        {
            data = new dtHangCombo();
            DataTable dt = data.LayThongTinHangHoa(Int32.Parse(cmbHangHoa.Value.ToString()));
            DataRow dr = dt.Rows[0];
            txtTonKho.Text = dtCapNhatTonKho.SoLuongTonKho_Client(Int32.Parse(cmbHangHoa.Value.ToString()), dtSetting.LayIDKho()) + "";
            double DonGia = double.Parse(dr["GiaBan1"].ToString());
            txtDonGia.Text = DonGia + "";
            txtSoLuong.Text = "1";
            txtThanhTien.Text = DonGia +"";
        }
        private void LoadGrid(int IDHangHoaComBo)
        {
            data = new dtHangCombo();
            //TinhTongTien();
            gridDanhSachHangHoa_Temp.DataSource = data.DanhSachHangHoaCombo_Temp(IDHangHoaComBo);
            gridDanhSachHangHoa_Temp.DataBind();

        }
        protected void txtSoLuong_NumberChanged(object sender, EventArgs e)
        {
            int SLT = dtCapNhatTonKho.SoLuongTonKho_Client(Int32.Parse(cmbHangHoa.Value.ToString()), dtSetting.LayIDKho());
            int SoLuong = Int32.Parse(txtSoLuong.Text.ToString());
            int SLCom = Int32.Parse(txtSLCombo.Text);
            if (SLCom * SoLuong <= SLT)
            {
                
                double DonGia = double.Parse(txtDonGia.Text.ToString());
                txtThanhTien.Text = (SoLuong * DonGia).ToString();
            }
            else
            {
                txtSoLuong.Text = "0";
                double DonGia = double.Parse(txtDonGia.Text.ToString());
                txtThanhTien.Text = (0 * DonGia).ToString();
                Response.Write("<script language='JavaScript'> alert('Số Lượng Tồn Kho Không Đủ.'); </script>");
            }
        }
        protected void gridDanhSachHangHoa_Temp_RowUpdating(object sender, DevExpress.Web.Data.ASPxDataUpdatingEventArgs e)
        {
            int IDHangHoaComBo = Int32.Parse(IDHangHoaComBo_Temp.Value.ToString());
            int ID = Int32.Parse(e.Keys[0].ToString());
            int SoLuong = Int32.Parse(e.NewValues["SoLuong"].ToString());
            float DonGia = float.Parse(e.NewValues["GiaBan"].ToString());
            data = new dtHangCombo();
            data.UpdateHangHoa_ID_SoLuong_temp(ID, SoLuong, SoLuong * DonGia);
            TinhTongTien();
            e.Cancel = true;
            gridDanhSachHangHoa_Temp.CancelEdit();
            LoadGrid(IDHangHoaComBo);
        }

        protected void txtSLCombo_NumberChanged(object sender, EventArgs e)
        {
          
            int SL = Int32.Parse(txtSLCombo.Text);
            if (SL <= 0)
            {
                Clear();
                Response.Write("<script language='JavaScript'> alert('Số phải lớn hơn 0.'); </script>");
            }
            else
            {
                cmbHangHoa.Enabled = true;
                txtSoLuong.Enabled = true;
                btnThem_Temp.Enabled = true;
            }
       }
    }
}