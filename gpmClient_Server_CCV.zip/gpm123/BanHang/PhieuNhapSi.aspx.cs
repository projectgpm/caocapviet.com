﻿using BanHang.Data;
using DevExpress.Web;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.OleDb;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace BanHang
{
    public partial class PhieuNhapSi : System.Web.UI.Page
    {
        dtPhieuNhapSi data = new dtPhieuNhapSi();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["KTDangNhap"] != "GPM")
            {
                Response.Redirect("DangNhap.aspx");
            }
            else
            {
                if (dtSetting.LayTrangThaiMenu_ChucNang(Session["IDNhom"].ToString(), 12) == 1)
                    Response.Redirect("Default.aspx");
                if (dtSetting.LayTrangThaiMenu(Session["IDNhom"].ToString(), 12) == 1)
                {
                    if (!IsPostBack)
                    {
                        data = new dtPhieuNhapSi();

                        object IDPhieuNhapSi = data.ThemPhieuNhapSi_Temp();
                        IDPhieuNhapSi_Temp.Value = IDPhieuNhapSi.ToString();
                        txtIDKho.Enabled = false;
                        txtIDKho.Text = dtSetting.LayIDKho() + "";
                    }
                    LoadGrid(Int32.Parse(IDPhieuNhapSi_Temp.Value.ToString()));
                }
                else
                {
                    Response.Redirect("Default.aspx");
                }
            }
            
        }
        protected void ASPxFormLayoutNgayLapPhieu_Init(object sender, EventArgs e)
        {
            ASPxFormLayoutNgayLapPhieu.Date = DateTime.Today;
        }
        protected void ASPxFormLayoutThemTemp_Click(object sender, EventArgs e)
        {

            if (ASPxFormLayoutIDHangHoa.Value != null && ASPxFormLayoutSoLuong.Text !="")
            {
                int SoLuong = Int32.Parse(ASPxFormLayoutSoLuong.Value.ToString());
                if (SoLuong > 0)
                {
                    int IDHangHoa = Int32.Parse(ASPxFormLayoutIDHangHoa.Value.ToString());
                    dtHangHoa dt = new dtHangHoa();

                    string MaHang = dt.LaymaHang_IDHangHoa(IDHangHoa);

                    float DonGia = float.Parse(ASPxFormLayoutDonGia.Value.ToString());
                    float ThanhTien = float.Parse(ASPxFormLayoutThanhTien.Value.ToString());
                    int IDPhieuNhapSi = Int32.Parse(IDPhieuNhapSi_Temp.Value.ToString());
                    int IDDonViTinh = Int32.Parse(cmbDonViTinh.Value.ToString());
                    DataTable db = data.KTChiTietPhieuNhapSi_Temp(IDHangHoa);// kiểm tra hàng hóa
                    if (db.Rows.Count == 0)
                    {
                        data = new dtPhieuNhapSi();
                        data.ThemChiTietPhieuNhapSi_Temp(IDPhieuNhapSi, IDHangHoa, IDDonViTinh, SoLuong, DonGia, ThanhTien, MaHang);
                        Clear();
                    }
                    else
                    {
                        data = new dtPhieuNhapSi();
                        data.UpdateChiTietPhieuNhapSi_temp(IDPhieuNhapSi, IDHangHoa, IDDonViTinh, SoLuong, DonGia, ThanhTien, MaHang);
                        Clear();
                    }
                    LoadGrid(IDPhieuNhapSi);
                }
                else
                {
                    Response.Write("<script language='JavaScript'> alert('Số lượng > 0.'); </script>");
                }
            }
            else
            {
                Response.Write("<script language='JavaScript'> alert('Bạn chưa chọn hàng hóa.'); </script>");
            }
        }

        private void LoadGrid(int IDPhieuNhapSi)
        {
            data = new dtPhieuNhapSi();
        
            GridViewDanhSachHangHoa_Temp.DataSource = data.LayDanhSachPhieuNhapSi_Temp(IDPhieuNhapSi);
            GridViewDanhSachHangHoa_Temp.DataBind();

        }


        protected void ASPxFormLayoutIDHangHoa_SelectedIndexChanged(object sender, EventArgs e)
        {
            ASPxFormLayoutSoLuong.Text = "0";
            if (ASPxFormLayoutIDHangHoa.Text != "" && ASPxFormLayoutSoLuong.Text !="")
            {
                data = new dtPhieuNhapSi();
                DataTable dt = data.LayThongTinHangHoa(Int32.Parse(ASPxFormLayoutIDHangHoa.Value.ToString()));
                txtTonKho.Text = dtCapNhatTonKho.SoLuongTonKho_Client(Int32.Parse(ASPxFormLayoutIDHangHoa.Value.ToString()), dtSetting.LayIDKho()).ToString();

                
                int SoLuong = Int32.Parse(ASPxFormLayoutSoLuong.Value.ToString());
                foreach (DataRow item in dt.Rows)
                {
                    ASPxFormLayoutDonGia.Text = item["GiaMua"].ToString();
                    int DonGia = Int32.Parse(ASPxFormLayoutDonGia.Value.ToString());
                    ASPxFormLayoutThanhTien.Text = (SoLuong * DonGia).ToString();
                    cmbDonViTinh.Value = item["IDDonViTinh"].ToString();
                }
            }
        }

        //không kiểm tra tồn kho
        protected void ASPxFormLayoutSoLuong_NumberChanged(object sender, EventArgs e)
        {
            if (ASPxFormLayoutIDHangHoa.Text != "")
            {
                data = new dtPhieuNhapSi();
                DataTable db = data.LayThongTinHangHoa(Int32.Parse(ASPxFormLayoutIDHangHoa.Value.ToString()));
                if (db.Rows.Count != 0)
                {
                    DataRow dr = db.Rows[0];
                    double DonGia = double.Parse(dr["GiaMua"].ToString());
                    int SoLuong = Int32.Parse(ASPxFormLayoutSoLuong.Text.ToString());
                    ASPxFormLayoutThanhTien.Text = (SoLuong * DonGia).ToString();
                    

                }
            }
        }

        public void Clear()
        {
            ASPxFormLayoutIDHangHoa.Text = "";
            ASPxFormLayoutSoLuong.Text = "";
            ASPxFormLayoutDonGia.Text = "";
            ASPxFormLayoutThanhTien.Text = "";
            txtTonKho.Text = "";
            cmbDonViTinh.Text = "";
        }
        protected void ASPxFormLayoutHuyDonDatHang_Click(object sender, EventArgs e)
        {
            data = new dtPhieuNhapSi();
            int ID = Int32.Parse(IDPhieuNhapSi_Temp.Value.ToString());
            if (ID != null)
            {
                data.XoaPhieuNhapSi_Temp(ID);
                data.XoaPhieuNhapSi_Null();
                data.XoaChiTietPhieuNhapSi_Temp(ID);
                Response.Redirect("DanhSachPhieuNhapSi.aspx");
            }
        }

        protected void GridViewDanhSachHangHoa_Temp_RowUpdating(object sender, DevExpress.Web.Data.ASPxDataUpdatingEventArgs e)
        {
            string ID = e.Keys[0].ToString();
            int SL = Int32.Parse(e.NewValues["SoLuong"].ToString());
            double DG = double.Parse(e.NewValues["DonGia"].ToString());
            data = new dtPhieuNhapSi();
            data.CapNhatChiTietPhieuNhapSi_temp(ID, SL, DG, (SL * DG));
            int IDPhieuNhapSi = Int32.Parse(IDPhieuNhapSi_Temp.Value.ToString());
            e.Cancel = true;
            GridViewDanhSachHangHoa_Temp.CancelEdit();
            LoadGrid(IDPhieuNhapSi);
        }

        protected void GridViewDanhSachHangHoa_Temp_RowDeleting(object sender, DevExpress.Web.Data.ASPxDataDeletingEventArgs e)
        {
            int ID = Int32.Parse(e.Keys[0].ToString());
            data = new dtPhieuNhapSi();
            data.XoaChiTietPhieuNhapSi_Temp_ID(ID);
            e.Cancel = true;
            GridViewDanhSachHangHoa_Temp.CancelEdit();
            int IDPhieuNhapSi = Int32.Parse(IDPhieuNhapSi_Temp.Value.ToString());
            LoadGrid(IDPhieuNhapSi);
        }


        protected void ASPxFormThem_Click(object sender, EventArgs e)
        {
            // không trừ tồn kho
            if (ASPxFormLayout1_NhaCungCap.Value != null)
            {
                int IDPhieuNhapSi = Int32.Parse(IDPhieuNhapSi_Temp.Value.ToString());
                DataTable db = data.LayDanhSachPhieuNhapSi_Temp(IDPhieuNhapSi);
                if (db.Rows.Count != 0)
                {
                    int IDNhaCungCap = Int32.Parse(ASPxFormLayout1_NhaCungCap.Value.ToString());
                    DateTime NgayLap = DateTime.Parse(ASPxFormLayoutNgayLapPhieu.Text.ToString());
                    string GhiChu = ASPxFormLayoutGhiChu == null ? "" : ASPxFormLayoutGhiChu.Text.ToString();

                    float TongTien = 0;

                    foreach (DataRow dr in db.Rows)
                    {
                        float ThanhTien = float.Parse(dr["ThanhTien"].ToString());
                        TongTien = TongTien + ThanhTien;
                    }
                    int IDKho = dtSetting.LayIDKho();
                    data = new dtPhieuNhapSi();
                    string SoHoaDon = cmbSohoadon.Value == null ? "0" : cmbSohoadon.Value.ToString();
                    string TenHoaDon = cmbSohoadon.Text == null ? "" : cmbSohoadon.Text.ToString();
                    data.CapNhatPhieuNhapSi_ID(IDPhieuNhapSi, IDKho, IDNhaCungCap, NgayLap, TongTien, GhiChu, SoHoaDon, TenHoaDon);
                    
                    foreach (DataRow dr in db.Rows)
                    {
                        int IDHangHoa = Int32.Parse(dr["IDHangHoa"].ToString());
                       
                        int SoLuong = Int32.Parse(dr["SoLuong"].ToString());
                        float DonGia = float.Parse(dr["DonGia"].ToString());
                     
                        float ThanhTien = float.Parse(dr["ThanhTien"].ToString());
                        int IDDonViTinh = Int32.Parse(dr["IDDonViTinh"].ToString());
                        
                        data = new dtPhieuNhapSi();
                        
                        data.ThemChiTietPhieuNhapSi(IDPhieuNhapSi, IDHangHoa,IDDonViTinh, SoLuong, DonGia, ThanhTien);
                        dtCapNhatTonKho tk = new dtCapNhatTonKho();
                        dtLichSuKho.ThemLichSu(IDHangHoa, Int32.Parse(Session["IDNhanVien"].ToString()), SoLuong * (-1), "Nhập hàng sỉ");

                        dtLichSuKho.ThemLichSuNhap(IDHangHoa, IDNhaCungCap, SoLuong);
                        tk.CongTonKho_IDHangHoa(IDHangHoa, SoLuong,IDKho);
                        
                    }

                    dtLichSuTruyCap.ThemLichSu(Session["IDNhanVien"].ToString(), Session["IDNhom"].ToString(), "Phiếu Nhập Sỉ", dtSetting.LayIDKho(), "Nhập xuất tồn", "Thêm");
                    if (SoHoaDon != "")
                    {
                        dtDuyetHangNhaCungCap dt = new dtDuyetHangNhaCungCap();
                        dt.DuyetDonHangNhaCungCap(Int32.Parse(SoHoaDon));
                    }

                    
                    data = new dtPhieuNhapSi();
                    data.XoaChiTietPhieuNhapSi_Temp(IDPhieuNhapSi);
                    data.XoaPhieuNhapSi_Null();
                    //Response.Write("<script language='JavaScript'> alert('Thêm phiếu nhập sỉ thành công.'); </script>");
                    Response.Redirect("DanhSachPhieuNhapSi.aspx");
                    //LoadGrid(IDPhieuNhapSi);
             
                  
                }
                else
                {
                    Response.Write("<script language='JavaScript'> alert('Danh sách hàng hóa rỗng.'); </script>");
                }
            }
            else
            {
                Response.Write("<script language='JavaScript'> alert('Bạn chưa chọn nhà cung cấp.'); </script>");
            }
        }

        protected void cmbSohoadon_SelectedIndexChanged(object sender, EventArgs e)
        {

            data = new dtPhieuNhapSi();
            //data.XoaPhieuNhapSi_Temp(Int32.Parse(IDPhieuNhapSi_Temp.Value.ToString()));
            int ID = Int32.Parse(IDPhieuNhapSi_Temp.Value.ToString());
            data.XoaChiTietPhieuNhapSi_Temp(ID);
            dtHangHoa dt = new dtHangHoa();
            dtDonHang dt1 = new dtDonHang();
            DataTable da1 = dt1.LayDanhSachChiTiet(Int32.Parse(cmbSohoadon.Value.ToString()));
            if (da1.Rows.Count != 0)
            {
                DataRow dr = da1.Rows[0];
                ASPxFormLayout1_NhaCungCap.Value = dr["IDNhaCungCap"].ToString();
                ASPxFormLayout1_NhaCungCap.Enabled = false;
                ASPxFormLayoutNgayLapPhieu.Date = DateTime.Parse(dr["NgayLap"].ToString());
                ASPxFormLayoutNgayLapPhieu.Enabled = false;
                ASPxFormLayoutGhiChu.Text = dr["GhiChu"].ToString();
                ASPxFormLayoutGhiChu.Enabled = false;
            }
            // insert hang hóa vào bảng temp
             DataTable dd = dt1.LayDanhSachHangHoa_MaHoaDon(Int32.Parse(cmbSohoadon.Value.ToString()));
             if (dd.Rows.Count != 0)
             {
                 foreach (DataRow dr in dd.Rows)
                 {
                     string MaHang = dr["MaHang"].ToString();
                     int IDHangHoa = Int32.Parse(dr["IDHangHoa"].ToString());
                     int SoLuong = Int32.Parse(dr["SoLuong"].ToString());
                     float DonGia = float.Parse(dr["DonGia"].ToString());
                     float ThanhTien = float.Parse(dr["ThanhTien"].ToString());
                     int IDPhieuNhapSi = Int32.Parse(IDPhieuNhapSi_Temp.Value.ToString());

                     dtHangHoa hh = new dtHangHoa();
                     int IDDonViTinh = hh.LayIDĐVT_IDHangHoa(IDHangHoa);
                     DataTable db = data.KTChiTietPhieuNhapSi_Temp(IDHangHoa);// kiểm tra hàng hóa
                     if (db.Rows.Count == 0)
                     {
                         data = new dtPhieuNhapSi();
                         data.ThemChiTietPhieuNhapSi_Temp(IDPhieuNhapSi, IDHangHoa, IDDonViTinh, SoLuong, DonGia, ThanhTien, MaHang);
                         Clear();
                     }
                     else
                     {
                         data = new dtPhieuNhapSi();
                         data.UpdateChiTietPhieuNhapSi_temp(IDPhieuNhapSi, IDHangHoa, IDDonViTinh, SoLuong, DonGia, ThanhTien, MaHang);
                         Clear();
                     }
                     LoadGrid(IDPhieuNhapSi);
                 }
             }
           

        }

        protected void btnLoadFileExcel_Click(object sender, EventArgs e)
        {
            Import();
        }
        private void Import()
        {
            if (string.IsNullOrEmpty(UploadFileExcel.FileName))
            {
                Response.Write("<script language='JavaScript'> alert('Chưa chọn file.'); </script>");
                return;
            }

            UploadFile();
            string Excel = Server.MapPath("~/Uploads/") + strFileExcel;

            string excelConnectionString = string.Empty;
            excelConnectionString = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" + Excel + ";Extended Properties=Excel 8.0;";

            OleDbConnection excelConnection = new OleDbConnection(excelConnectionString);
            OleDbCommand cmd = new OleDbCommand("Select * from [Sheet$]", excelConnection);
            excelConnection.Open();
            OleDbDataReader dReader = default(OleDbDataReader);
            dReader = cmd.ExecuteReader();

            DataTable dataTable = new DataTable();
            dataTable.Load(dReader);
            int r = dataTable.Rows.Count;
            Import_Temp(dataTable);

        }
        private void Import_Temp(DataTable datatable)
        {
            int intRow = datatable.Rows.Count;
            if (intRow != 0)
            {
                for (int i = 0; i <= intRow - 1; i++)
                {
                    DataRow dr = datatable.Rows[i];
                    string MaHang = dr["MaHang"].ToString().Trim();
                    string TenHangHoa = dr["TenHangHoa"].ToString();
                    int SoLuong = Int32.Parse(dr["SoLuong"].ToString());
                    if (SoLuong > 0)
                    {
                        int IDPhieuNhapSi = Int32.Parse(IDPhieuNhapSi_Temp.Value);
                        int IDHangHoa = dtThemDonHangClient.LayIDHangHoa_MaHang_TenHangHoa(MaHang, TenHangHoa);
                        float GiaBan = dtCapNhatTonKho.GiaMua_Client(IDHangHoa);
                        float ThanhTien = SoLuong * GiaBan;

                        DataTable db = dtThemDonHangClient.KTChiTietDonHang_Temp(IDHangHoa, IDPhieuNhapSi);// kiểm tra hàng hóa
                        if (db.Rows.Count == 0)
                        {
                            data = new dtPhieuNhapSi();
                            data.ThemChiTietPhieuNhapSi_Temp(IDPhieuNhapSi, IDHangHoa, dtCapNhatTonKho.IDDVT_Client(IDHangHoa), SoLuong, GiaBan, ThanhTien, MaHang);

                        }
                        else
                        {

                            data.UpdateChiTietPhieuNhapSi_temp(IDPhieuNhapSi, IDHangHoa, dtCapNhatTonKho.IDDVT_Client(IDHangHoa), SoLuong, GiaBan, ThanhTien, MaHang);

                        }
                        LoadGrid(IDPhieuNhapSi);
                    }
                    else
                    {
                        Response.Write("<script language='JavaScript'> alert('Số lượng phải > 0.'); </script>");
                    }

                }
            }

        }
        private void UploadFile()
        {
            string folder = null;
            string filein = null;
            string ThangNam = null;

            ThangNam = string.Concat(System.DateTime.Now.Month.ToString(), System.DateTime.Now.Year.ToString());
            if (!Directory.Exists(Server.MapPath("~/Uploads/") + ThangNam))
            {
                Directory.CreateDirectory(Server.MapPath("~/Uploads/") + ThangNam);
            }
            folder = Server.MapPath("~/Uploads/" + ThangNam + "/");

            if (UploadFileExcel.HasFile)
            {
                strFileExcel = Guid.NewGuid().ToString();
                string theExtension = Path.GetExtension(UploadFileExcel.FileName);
                strFileExcel += theExtension;

                filein = folder + strFileExcel;
                UploadFileExcel.SaveAs(filein);
                strFileExcel = ThangNam + "/" + strFileExcel;
            }
        }
        public string strFileExcel { get; set; }

        protected void ASPxFormLayoutIDHangHoa_ItemRequestedByValue(object source, DevExpress.Web.ListEditItemRequestedByValueEventArgs e)
        {
            long value = 0;
            if (e.Value == null || !Int64.TryParse(e.Value.ToString(), out value))
                return;
            ASPxComboBox comboBox = (ASPxComboBox)source;
            sqlHangHoa.SelectCommand = @"SELECT GPM_HangHoa.ID, GPM_HangHoa.MaHang, GPM_HangHoa.TenHangHoa, GPM_HangHoa.GiaMua, GPM_DonViTinh.TenDonViTinh 
                                        FROM GPM_DonViTinh INNER JOIN GPM_HangHoa ON GPM_DonViTinh.ID = GPM_HangHoa.IDDonViTinh 
                                                           INNER JOIN GPM_HangHoaTonKho ON GPM_HangHoaTonKho.IDHangHoa = GPM_HangHoa.ID 
                                        WHERE (GPM_HangHoa.ID = @ID)";

            sqlHangHoa.SelectParameters.Clear();
            sqlHangHoa.SelectParameters.Add("ID", TypeCode.Int64, e.Value.ToString());
            comboBox.DataSource = sqlHangHoa;
            comboBox.DataBind();
        }

        protected void ASPxFormLayoutIDHangHoa_ItemsRequestedByFilterCondition(object source, ListEditItemsRequestedByFilterConditionEventArgs e)
        {
            ASPxComboBox comboBox = (ASPxComboBox)source;

            sqlHangHoa.SelectCommand = @"SELECT [ID], [MaHang], [TenHangHoa], [GiaMua] , [TenDonViTinh]
                                        FROM (
	                                        select GPM_HangHoa.ID, GPM_HangHoa.MaHang, GPM_HangHoa.TenHangHoa, GPM_HangHoa.GiaMua, GPM_DonViTinh.TenDonViTinh, 
	                                        row_number()over(order by GPM_HangHoa.MaHang) as [rn] 
	                                        FROM GPM_DonViTinh INNER JOIN GPM_HangHoa ON GPM_DonViTinh.ID = GPM_HangHoa.IDDonViTinh 
                                                               INNER JOIN GPM_HangHoaTonKho ON GPM_HangHoaTonKho.IDHangHoa = GPM_HangHoa.ID
	                                        WHERE (GPM_HangHoa.MaHang LIKE @MaHang) AND (GPM_HangHoaTonKho.IDKho = @IDKho) AND (GPM_HangHoaTonKho.DaXoa = 0)	
	                                        ) as st 
                                        where st.[rn] between @startIndex and @endIndex";

            sqlHangHoa.SelectParameters.Clear();
            sqlHangHoa.SelectParameters.Add("MaHang", TypeCode.String, string.Format("%{0}%", e.Filter));
            sqlHangHoa.SelectParameters.Add("IDKho", TypeCode.Int32, dtSetting.LayIDKho()+"");
            sqlHangHoa.SelectParameters.Add("startIndex", TypeCode.Int64, (e.BeginIndex + 1).ToString());
            sqlHangHoa.SelectParameters.Add("endIndex", TypeCode.Int64, (e.EndIndex + 1).ToString());
            comboBox.DataSource = sqlHangHoa;
            comboBox.DataBind();
        }
    }
}