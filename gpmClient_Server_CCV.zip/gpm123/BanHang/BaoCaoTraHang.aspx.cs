﻿using BanHang.Data;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace BanHang
{
    public partial class BaoCaoTraHang : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["KTDangNhap"] != "GPM")
            {
                Response.Redirect("DangNhap.aspx");
            }
            else
            {
                if (dtSetting.LayTrangThaiMenu(Session["IDNhom"].ToString(), 30) == 1)
                {
                    if (!IsPostBack)
                    {
                        dtThongTinCuaHangKho d = new dtThongTinCuaHangKho();
                        DataTable dx = d.LayDanhSach();
                        dx.Rows.Add(-1, "Tất cả Cửa Hàng", "", "", 0, 0, "", DateTime.Now.Date, 0);
                        cmbCuaHangKho.DataSource = dx;
                        cmbCuaHangKho.TextField = "TenCuaHang";
                        cmbCuaHangKho.ValueField = "ID";
                        cmbCuaHangKho.DataBind();
                        cmbCuaHangKho.Value = dtSetting.LayIDKho() + "";

                        dtNganhHang d1 = new dtNganhHang();
                        DataTable d1x = d1.LayDanhSachNganhHang();
                        d1x.Rows.Add(-1, "", "Tất cả Ngành Hàng", DateTime.Now.Date, "", 0);
                        cmbNganhHang.DataSource = d1x;
                        cmbNganhHang.TextField = "TenNganhHang";
                        cmbNganhHang.ValueField = "ID";
                        cmbNganhHang.DataBind();
                        cmbNganhHang.SelectedIndex = cmbNganhHang.Items.Count;

                        dtNhomHang d2 = new dtNhomHang();
                        DataTable d2x = d2.LayDanhSachNhomHang();
                        d2x.Rows.Add(-1, "Tất cả Nhóm Hàng", DateTime.Now.Date, 0);
                        cmbNhomHang.DataSource = d2x;
                        cmbNhomHang.TextField = "TenNhomHang";
                        cmbNhomHang.ValueField = "ID";
                        cmbNhomHang.DataBind();
                        cmbNhomHang.SelectedIndex = cmbNhomHang.Items.Count;

                        dtNhomKhachHang d3 = new dtNhomKhachHang();
                        DataTable d3x = d3.LayDanhNhomKhachHang();
                        d3x.Rows.Add(-1, "Tất cả nhóm", "", DateTime.Now.Date, "", 0);
                        cmbNhomNguoiDung.DataSource = d3x;
                        cmbNhomNguoiDung.TextField = "TenNhomKhachHang";
                        cmbNhomNguoiDung.ValueField = "ID";
                        cmbNhomNguoiDung.DataBind();
                        cmbNhomNguoiDung.SelectedIndex = cmbNhomNguoiDung.Items.Count;

                        txtNgayBD.Date = DateTime.Today.AddDays(-30);
                        txtNgayKT.Date = DateTime.Today;
                    }
                }
                else
                {
                    Response.Redirect("Default.aspx");
                }
            }
        }

        protected void btnIn_Click(object sender, EventArgs e)
        {
            string ngaybd = txtNgayBD.Date.ToString("yyyy-MM-dd");
            string ngaykt = txtNgayKT.Date.ToString("yyyy-MM-dd");
            string nganhhang = cmbNganhHang.Value + "";
            string nhomhang = cmbNhomHang.Value + "";
            string cuahang = cmbCuaHangKho.Value + "";
            string khachhang = cmbNhomNguoiDung.Value + "";
            popup.ContentUrl = "~/InBaoCaoTraHang.aspx?nganh=" + nganhhang + "&nhom=" + nhomhang + "&khohang=" + cuahang + "&ngaybd=" + ngaybd + "&ngaykt=" + ngaykt + "&khachhang=" + khachhang;
            popup.ShowOnPageLoad = true;
        }

        protected void cmbNganhHang_SelectedIndexChanged(object sender, EventArgs e)
        {
            int id = Int32.Parse(cmbNganhHang.Value + "");
            if (id == -1)
            {
                dtNhomHang d2 = new dtNhomHang();
                DataTable d2x = d2.LayDanhSachNhomHang();
                d2x.Rows.Add(-1, "Tất cả Nhóm Hàng", DateTime.Now.Date, 0);
                cmbNhomHang.DataSource = d2x;
                cmbNhomHang.TextField = "TenNhomHang";
                cmbNhomHang.ValueField = "ID";
                cmbNhomHang.DataBind();
                cmbNhomHang.SelectedIndex = cmbNhomHang.Items.Count;
            }
            else
            {
                dtNhomHang d2 = new dtNhomHang();
                DataTable d2x = d2.LayDanhSachNhomHang_ID(id);
                d2x.Rows.Add(-1, "Tất cả Nhóm Hàng", 0, DateTime.Now.Date, 0);
                cmbNhomHang.DataSource = d2x;
                cmbNhomHang.TextField = "TenNhomHang";
                cmbNhomHang.ValueField = "ID";
                cmbNhomHang.DataBind();
                cmbNhomHang.SelectedIndex = cmbNhomHang.Items.Count;
            }
        }
    }
}