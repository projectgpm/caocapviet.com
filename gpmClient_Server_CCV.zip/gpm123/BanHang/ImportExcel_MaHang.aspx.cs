﻿using BanHang.Data;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.OleDb;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.Configuration;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace BanHang
{
    public partial class ImportExcel_MaHang : System.Web.UI.Page
    {
        private string strFileExcel = "";
        dtImportMaHang data = new dtImportMaHang();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["KTDangNhap"] == "GPM")
            {
                if (!IsPostBack)
                {
                    // xóa dữ liệu bảng temp
                    data = new dtImportMaHang();
                    data.XoaDuLieuTemp();

                }
                LoadGrid();
            }
            else
            {
                Response.Redirect("DangNhap.aspx");
            }
        }

        private void LoadGrid()
        {
            data = new dtImportMaHang();
            gridMaHang_Temp.DataSource = data.DanhSachMaHang_Import_Temp();
            gridMaHang_Temp.DataBind();
        }

        protected void btnNhap_Click(object sender, EventArgs e)
        {
            Import();
        }

        protected void btnThem_Click(object sender, EventArgs e)
        {
            data = new dtImportMaHang();
            DataTable dt = data.DanhSachMaHang_Import_Temp();
            if (dt.Rows.Count != 0)
            {
                foreach (DataRow dr in dt.Rows)
                {
                    int IDNhomHang = Int32.Parse(dr["IDNhomHang"].ToString());
                    int IDDonViTinh = Int32.Parse(dr["IDDonViTinh"].ToString());
                    string MaHang = dr["MaHang"].ToString();
                    string TenMaHang = dr["TenMaHang"].ToString();

                    data = new dtImportMaHang();
                    DataTable dd = data.KiemTraMaHang_Import(MaHang, TenMaHang, IDDonViTinh, IDNhomHang);
                    if (dd.Rows.Count == 0)
                    {
                        dtMaHang mh = new dtMaHang();
                        mh.ThemMaHang(MaHang, IDDonViTinh, IDNhomHang, TenMaHang, DateTime.Today);
                    }
                }

                ActionServer.CapNhatServer();
                Response.Redirect("MaHang.aspx");
            }
        }

        private void Import()
        {
            if (string.IsNullOrEmpty(UploadFileExcel.FileName))
            {
                Response.Write("<script language='JavaScript'> alert('Chưa chọn file.'); </script>");
                return;
            }

            UploadFile();
            string Excel = Server.MapPath("~/Uploads/") + strFileExcel;

            string excelConnectionString = string.Empty;
            excelConnectionString = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" + Excel + ";Extended Properties=Excel 8.0;";

            OleDbConnection excelConnection = new OleDbConnection(excelConnectionString);
            OleDbCommand cmd = new OleDbCommand("Select * from [Sheet$]", excelConnection);
            excelConnection.Open();
            OleDbDataReader dReader = default(OleDbDataReader);
            dReader = cmd.ExecuteReader();

            DataTable dataTable = new DataTable();
            dataTable.Load(dReader);
            int r = dataTable.Rows.Count;
            Import_Temp(dataTable);

        }

        private void Import_Temp(DataTable dataTable)
        {
            int intRow = dataTable.Rows.Count;
            if (intRow != 0)
            {
                for (int i = 0; i <= intRow - 1; i++)
                {
                    DataRow dr = dataTable.Rows[i];
                    string MaHang = dr["Mã Hàng"].ToString();
                    string TenMaHang = dr["Tên Mã Hàng"].ToString();
                    string NhomHang = dr["Nhóm Hàng"].ToString();
                    string DonViTinh = dr["Đơn Vị Tính"].ToString();
                    int IDNhomHang = dtImportMaHang.Lay_IDNhomHang(NhomHang);
                    int IDDonViTinh = dtImportHangHoa.Lay_IDDVT(DonViTinh);

                    data = new dtImportMaHang();
                    DataTable dt = data.KiemTraMaHang_Import_Temp(MaHang, TenMaHang, IDDonViTinh, IDNhomHang);
                    if (dt.Rows.Count == 0)
                    {
                        data.ThemMaHang(MaHang, IDDonViTinh, IDNhomHang, TenMaHang);
                        LoadGrid();
                    }
                }
            }
        }

        private void UploadFile()
        {
            string folder = null;
            string filein = null;
            string ThangNam = null;

            ThangNam = string.Concat(System.DateTime.Now.Month.ToString(), System.DateTime.Now.Year.ToString());
            if (!Directory.Exists(Server.MapPath("~/Uploads/") + ThangNam))
            {
                Directory.CreateDirectory(Server.MapPath("~/Uploads/") + ThangNam);
            }
            folder = Server.MapPath("~/Uploads/" + ThangNam + "/");

            if (UploadFileExcel.HasFile)
            {
                strFileExcel = Guid.NewGuid().ToString();
                string theExtension = Path.GetExtension(UploadFileExcel.FileName);
                strFileExcel += theExtension;

                filein = folder + strFileExcel;
                UploadFileExcel.SaveAs(filein);
                strFileExcel = ThangNam + "/" + strFileExcel;
            }
        }

        protected void btnHuy_Click(object sender, EventArgs e)
        {
            Response.Redirect("MaHang.aspx");
        }

        protected void gridMaHang_Temp_RowDeleting(object sender, DevExpress.Web.Data.ASPxDataDeletingEventArgs e)
        {
            int ID = Int32.Parse(e.Keys[0].ToString());
            data = new dtImportMaHang();
            data.XoaDuLieuTemp_ID(ID);
            e.Cancel = true;
            gridMaHang_Temp.CancelEdit();
            LoadGrid();
        }
    }
}