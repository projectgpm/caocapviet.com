﻿using BanHang.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace BanHang
{
    public partial class KhachHang : System.Web.UI.Page
    {
        dtKhachHang data = new dtKhachHang();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["KTDangNhap"] != "GPM")
            {
                Response.Redirect("DangNhap.aspx");
            }
            else
            {
                if (dtSetting.LayTrangThaiMenu_ChucNang(Session["IDNhom"].ToString(), 3) == 1)
                {
                    btnNhapExcel.Enabled = false;
                    gridKhachHang.Columns["iconaction"].Visible = false;
                }
                if (dtSetting.LayTrangThaiMenu(Session["IDNhom"].ToString(), 3) == 1)
                {
                    LoadGrid();
                }
                else
                {
                    Response.Redirect("Default.aspx");
                }
            }
        }
        public void LoadGrid()
        {
            data = new dtKhachHang();
            gridKhachHang.DataSource = data.LayDanhSachKhachHang();
            gridKhachHang.DataBind();
        }

        protected void gridKhachHang_RowUpdating(object sender, DevExpress.Web.Data.ASPxDataUpdatingEventArgs e)
        {
            DateTime NgayCapNhat = DateTime.Today.Date;
            string ID = e.Keys["ID"].ToString();
            data = new dtKhachHang();
            int IDNhomKhachHang = Int32.Parse(e.NewValues["IDNhomKhachHang"].ToString());
            string TenKhachHang = e.NewValues["TenKhachHang"] == null ? "" : e.NewValues["TenKhachHang"].ToString();
            string NgaySinh = e.NewValues["NgaySinh"] == null ? "" : e.NewValues["NgaySinh"].ToString();
            string CMND = e.NewValues["CMND"] == null ? "" : e.NewValues["CMND"].ToString();
            string DiaChi = e.NewValues["DiaChi"] == null ? "" : e.NewValues["DiaChi"].ToString();
            int IDThanhPho = Int32.Parse(e.NewValues["IDThanhPho"].ToString());
            int IDQuan = Int32.Parse(e.NewValues["IDQuan"].ToString());
            string DienThoai = e.NewValues["DienThoai"] == null ? "" : e.NewValues["DienThoai"].ToString();
          
            string Email = e.NewValues["Email"] == null ? "" : e.NewValues["Email"].ToString();
            string MaKh = "";
            string Barcode = "";
            string GhiChu = e.NewValues["GhiChu"] == null ? "" : e.NewValues["GhiChu"].ToString();

            data.SuaThongTinKhachHang(Int32.Parse(ID),MaKh, IDNhomKhachHang, TenKhachHang, NgaySinh, CMND, DiaChi, IDThanhPho, IDQuan, DienThoai, Email, Barcode, GhiChu, NgayCapNhat);
            if (e.NewValues["MaKhachHang"] == null)
            {
                data = new dtKhachHang();
                data.CapNhatMaKhachHang(ID, (dtSetting.LayMaKho() + "." + ID).ToString(), (dtSetting.LayMaKho() + "." + ID).Replace(".", ""));
            }
            e.Cancel = true;
            gridKhachHang.CancelEdit();
            LoadGrid();
            dtLichSuTruyCap.ThemLichSu(Session["IDNhanVien"].ToString(), Session["IDNhom"].ToString(), "Khách hàng:" + TenKhachHang, dtSetting.LayIDKho(), "Danh Mục", "Cập Nhật");   
        }

        protected void gridKhachHang_RowInserting(object sender, DevExpress.Web.Data.ASPxDataInsertingEventArgs e)
        {
            DateTime NgayCapNhat = DateTime.Today.Date;
            data = new dtKhachHang();
            int IDNhomKhachHang = Int32.Parse(e.NewValues["IDNhomKhachHang"].ToString());
            string TenKhachHang = e.NewValues["TenKhachHang"] == null ? "" : e.NewValues["TenKhachHang"].ToString();
            DateTime NgaySinh =DateTime.Parse( e.NewValues["NgaySinh"] == null ? "" : e.NewValues["NgaySinh"].ToString());
            string CMND = e.NewValues["CMND"] == null ? "" : e.NewValues["CMND"].ToString();
            string DiaChi = e.NewValues["DiaChi"] == null ? "" : e.NewValues["DiaChi"].ToString();
            int IDThanhPho = Int32.Parse(e.NewValues["IDThanhPho"].ToString());
            int IDQuan = Int32.Parse(e.NewValues["IDQuan"].ToString());
            string DienThoai = e.NewValues["DienThoai"] == null ? "" : e.NewValues["DienThoai"].ToString();
           
            string Email = e.NewValues["Email"] == null ? "" : e.NewValues["Email"].ToString();
            string MaKh = "";
            string Barcode = "";
            string GhiChu = e.NewValues["GhiChu"] == null ? "" : e.NewValues["GhiChu"].ToString();

            object ID = data.ThemKhachHang(IDNhomKhachHang,MaKh, TenKhachHang, NgaySinh, CMND, DiaChi, IDThanhPho, IDQuan, DienThoai, Email, Barcode, GhiChu, NgayCapNhat);

            if (ID != null)
            {
                if (e.NewValues["MaKhachHang"] == null)
                {
                    data = new dtKhachHang();
                    data.CapNhatMaKhachHang(ID, (dtSetting.LayMaKho() + "." + ID).ToString(),(dtSetting.LayMaKho() + "." + ID).Replace(".",""));
                }
            }
            e.Cancel = true;
            gridKhachHang.CancelEdit();
            LoadGrid();

            dtLichSuTruyCap.ThemLichSu(Session["IDNhanVien"].ToString(), Session["IDNhom"].ToString(), "Khách hàng:" + TenKhachHang, dtSetting.LayIDKho(), "Danh Mục", "Thêm"); 
        }

        protected void gridKhachHang_RowDeleting(object sender, DevExpress.Web.Data.ASPxDataDeletingEventArgs e)
        {
            string ID = e.Keys[0].ToString();
            data = new dtKhachHang();
            data.XoaKhachHang(Int32.Parse(ID));
            e.Cancel = true;
            gridKhachHang.CancelEdit();
            LoadGrid();

            dtLichSuTruyCap.ThemLichSu(Session["IDNhanVien"].ToString(), Session["IDNhom"].ToString(), "Khách hàng:" + ID, dtSetting.LayIDKho(), "Danh Mục", "Xóa");  
        }

        protected void btnXuatPDF_Click(object sender, EventArgs e)
        {
            XuatDuLieu.WritePdfToResponse();
        }

        protected void btnXuatExcel_Click(object sender, EventArgs e)
        {
            XuatDuLieu.WriteXlsToResponse();
        }

        protected void btnNhapExcel_Click(object sender, EventArgs e)
        {
            Response.Redirect("ImportExcel_KhachHang.aspx");
        }
    }
}