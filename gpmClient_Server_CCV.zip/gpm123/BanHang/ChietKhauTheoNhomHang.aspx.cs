﻿using BanHang.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace BanHang
{
    public partial class ChiecKhauTheoNhomHang : System.Web.UI.Page
    {
        dtChietKhauNhomHang data = new dtChietKhauNhomHang();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (dtSetting.LayTrangThaiMenu_ChucNang(Session["IDNhom"].ToString(), 11) == 1)
                gridChietKhauTheoNhomHang.Columns["iconaction"].Visible = false;

            if (dtSetting.LayTrangThaiMenu(Session["IDNhom"].ToString(), 11) == 1)
            {
                LoadGrid();
            }
            else
            { Response.Redirect("Default.aspx"); }
        }

        private void LoadGrid()
        {
            data = new dtChietKhauNhomHang();
            gridChietKhauTheoNhomHang.DataSource = data.LayDanhSachChietKhauNhomHang();
            gridChietKhauTheoNhomHang.DataBind();
        }

        protected void gridChietKhauTheoNhomHang_RowDeleting(object sender, DevExpress.Web.Data.ASPxDataDeletingEventArgs e)
        {
            string ID = e.Keys[0].ToString();
            data = new dtChietKhauNhomHang();
            data.XoaChietKhauNhomHang(Int32.Parse(ID));
            e.Cancel = true;
            gridChietKhauTheoNhomHang.CancelEdit();
            LoadGrid();

            ActionServer.CapNhatServer();
            dtLichSuTruyCap.ThemLichSu(Session["IDNhanVien"].ToString(), Session["IDNhom"].ToString(), "Chiết Khấu Theo Nhóm Hàng", dtSetting.LayIDKho(), "Danh Mục", "Xóa");
        }

        protected void gridChietKhauTheoNhomHang_RowInserting(object sender, DevExpress.Web.Data.ASPxDataInsertingEventArgs e)
        {
            DateTime NgayCapNhat = DateTime.Today.Date;
            data = new dtChietKhauNhomHang();
            
            int IDNhomHang = Int32.Parse(e.NewValues["IDNhomHang"].ToString());

            double GiaTri = double.Parse(e.NewValues["GiaTri"].ToString());
            double txtGiaTri = Math.Round((GiaTri / 100), 2);
            DateTime NgayBatDau = DateTime.Parse(e.NewValues["NgayBatDau"].ToString());
            DateTime NgayKetThuc = DateTime.Parse(e.NewValues["NgayKetThuc"].ToString());
            data.ThemChietKhauNhomHang(IDNhomHang, float.Parse(txtGiaTri + ""), NgayBatDau, NgayKetThuc, NgayCapNhat);
            e.Cancel = true;
            gridChietKhauTheoNhomHang.CancelEdit();
            LoadGrid();

            ActionServer.CapNhatServer();
            dtLichSuTruyCap.ThemLichSu(Session["IDNhanVien"].ToString(), Session["IDNhom"].ToString(), "Chiết Khấu Theo Nhóm Hàng", dtSetting.LayIDKho(), "Danh Mục", "Thêm");
        }

        protected void gridChietKhauTheoNhomHang_RowUpdating(object sender, DevExpress.Web.Data.ASPxDataUpdatingEventArgs e)
        {
            string ID = e.Keys[0].ToString();
            
            int IDNhomHang = Int32.Parse(e.NewValues["IDNhomHang"].ToString());
            double GiaTri = double.Parse(e.NewValues["GiaTri"].ToString());
            double txtGiaTri = Math.Round((GiaTri / 100), 2);

            DateTime NgayBatDau = DateTime.Parse(e.NewValues["NgayBatDau"].ToString());
            DateTime NgayKetThuc = DateTime.Parse(e.NewValues["NgayKetThuc"].ToString());
            DateTime NgayCapNhat = DateTime.Today.Date;
            data.SuaChietKhauNhomHang(Int32.Parse(ID), IDNhomHang, float.Parse(txtGiaTri + ""), NgayBatDau, NgayKetThuc, NgayCapNhat);
            e.Cancel = true;
            gridChietKhauTheoNhomHang.CancelEdit();
            LoadGrid();

            ActionServer.CapNhatServer();
            dtLichSuTruyCap.ThemLichSu(Session["IDNhanVien"].ToString(), Session["IDNhom"].ToString(), "Chiết Khấu Theo Nhóm Hàng", dtSetting.LayIDKho(), "Danh Mục", "Cập Nhật");
        }
    }
}