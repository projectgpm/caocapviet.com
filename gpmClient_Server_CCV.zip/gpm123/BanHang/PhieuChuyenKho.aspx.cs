﻿using BanHang.Data;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace BanHang
{
    public partial class PhieuChuyenKho : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["KTDangNhap"] != "GPM")
            {
                Response.Redirect("DangNhap.aspx");
            }
            else
            {
                if (dtSetting.LayTrangThaiMenu_ChucNang(Session["IDNhom"].ToString(), 20) == 1)
                    Response.Redirect("Default.aspx");
                if (dtSetting.LayTrangThaiMenu(Session["IDNhom"].ToString(), 20) == 1)
                {
                    dtChuyenKho data = new dtChuyenKho();
                    if (!IsPostBack)
                    {
                        data.XoaPhieuChuyenKho_Null();
                        data.XoaChiTietPhieuChuyenKho_Temp();
                        object IDPhieuChuyenKho1 = data.ThemPhieuChuyenKho_Temp();
                        IDPhieuChuyenKho.Value = IDPhieuChuyenKho1.ToString();
                        int IDKho = dtSetting.LayIDKho();
                        cmbKhoNhap.Text = IDKho + "";
                    }
                }
                else
                {
                    Response.Redirect("Default.aspx");
                }
            }  
        }

        protected void cmbHangHoa_SelectedIndexChanged(object sender, EventArgs e)
        {
            dtPhieuXuatSi datax = new dtPhieuXuatSi();
            if (cmbHangHoa.Text != "")
            {
                DataTable dt = datax.LayThongTinHangHoa(Int32.Parse(cmbHangHoa.Value.ToString()));
                DataRow dr = dt.Rows[0];
                cmbDonViTinh.Value = dr["IDDonViTinh"].ToString();
                txtSoLuong.Text = "1";
                txtDonGia.Text = dr["GiaBan1"].ToString();
                txtThanhTien.Text = (Int32.Parse(txtSoLuong.Text.ToString()) * double.Parse(txtDonGia.Text.ToString())).ToString();
            }
        }

        protected void txtSoLuong_NumberChanged(object sender, EventArgs e)
        {
            dtPhieuXuatSi data = new dtPhieuXuatSi();
            if (cmbHangHoa.Text != "")
            {
                DataTable dt = data.LayThongTinHangHoa(Int32.Parse(cmbHangHoa.Value.ToString()));
                if (dt.Rows.Count != 0)
                {
                    int SoLuong = Int32.Parse(txtSoLuong.Text.ToString());
                    if (dtSetting.KT_SoLuong() == 0)
                    {
                        double DonGia = double.Parse(txtDonGia.Text.ToString());
                        txtThanhTien.Text = (SoLuong * DonGia).ToString();
                    }
                    else
                    {

                        int SL;
                        int SLTonKhoClient = dtCapNhatTonKho.SoLuongTonKho_Client(Int32.Parse(cmbHangHoa.Value.ToString()), dtSetting.LayIDKho());
                        //if (SLTonKhoClient >= SoLuong)
                        {
                            SL = SoLuong;
                        }
                        //else
                        //{
                        //    SL = SLTonKhoClient;
                        //    txtSoLuong.Text = SLTonKhoClient + "";
                        //    Response.Write("<script language='JavaScript'> alert('Số hàng trong kho không đủ.'); </script>");
                        //}
                        double DonGia = double.Parse(txtDonGia.Text.ToString());
                        txtThanhTien.Text = (SL * DonGia).ToString();
                    }
                }
            }
        }

        protected void btnThem_Click(object sender, EventArgs e)
        {
            dtChuyenKho data = new dtChuyenKho();
            if (cmbHangHoa.Value != null)
            {
                int IDHangHoa = Int32.Parse(cmbHangHoa.Value.ToString());
                int SoLuong = Int32.Parse(txtSoLuong.Value.ToString());
                int IDPhieu = Int32.Parse(IDPhieuChuyenKho.Value.ToString());
                float DonGia = float.Parse(txtDonGia.Value.ToString());
                float ThanhTien = float.Parse(txtThanhTien.Value.ToString());
                int IDDonViTinh = Int32.Parse(cmbDonViTinh.Value.ToString());

                DataTable db = data.LayDanhSachChiTietPhieuChuyenKho_Temp_ID(IDHangHoa);// -----------------------
                if (db.Rows.Count == 0)
                {
                    data.ThemChiTietPhieuChuyenKho_Temp(IDPhieu, IDHangHoa, IDDonViTinh, SoLuong, DonGia, ThanhTien);
                    cmbHangHoa.Text = "";
                    txtSoLuong.Text = "1";
                    cmbDonViTinh.Text = "";
                    txtThanhTien.Text = "";
                }
                else
                {
                    data.UpdateChiTietPhieuChuyenKho_Temp(IDPhieu, IDHangHoa, IDDonViTinh, SoLuong, DonGia, ThanhTien);
                    cmbHangHoa.Text = "";
                    txtSoLuong.Text = "1";
                    cmbDonViTinh.Text = "";
                    txtThanhTien.Text = "";
                }
                gridDanhSachHangHoa_Temp.DataSource = data.LayDanhSachChiTietPhieuChuyenKho_Temp();
                gridDanhSachHangHoa_Temp.DataBind();
            }
            else
            {
                Response.Write("<script language='JavaScript'> alert('Bạn chưa chọn hàng hóa.'); </script>");
            }
        }

        protected void btnThemPhieuXuat_Click(object sender, EventArgs e)
        {
            dtChuyenKho data = new dtChuyenKho();
            if (cmbKhoXuat.Value != null)
            {
                int IDPhieu = Int32.Parse(IDPhieuChuyenKho.Value.ToString());
                DataTable db = data.LayDanhSachChiTietPhieuChuyenKho_Temp();
                if (db.Rows.Count != 0)
                {
                    int IDKhoNhap = Int32.Parse(cmbKhoNhap.Value.ToString());
                    DateTime NgayXuat = DateTime.Parse(cmbNgayLapPhieu.Text.ToString());
                    string GhiChu = txtGhiChu == null ? "" : txtGhiChu.Text.ToString();
                    int IDKhoXuat = Int32.Parse((cmbKhoXuat.Value + "").ToString());

                    data.UpdatePhieuChuyenKho(IDPhieu, IDKhoXuat, IDKhoNhap, GhiChu);
                    foreach (DataRow dr in db.Rows)
                    {
                        int IDHangHoa = Int32.Parse(dr["IDHangHoa"].ToString());
                        int SoLuong = Int32.Parse(dr["SoLuong"].ToString());
                        float DonGia = float.Parse(dr["DonGia"].ToString());
                        int IDDonViTinh = Int32.Parse(dr["IDDonViTinh"].ToString());
                        float ThanhTien = SoLuong * DonGia;
                        data.ThemChiTietPhieuChuyenKho(IDPhieu, IDHangHoa, IDDonViTinh, SoLuong, DonGia, ThanhTien);

                        dtCapNhatTonKho tk = new dtCapNhatTonKho();
                        dtLichSuKho.ThemLichSu(IDHangHoa, Int32.Parse(Session["IDNhanVien"].ToString()), SoLuong, "Chuyển kho");
                        tk.TruTonKho_IDHangHoa(IDHangHoa, SoLuong, dtSetting.LayIDKho());

                    }


                    dtLichSuTruyCap.ThemLichSu(Session["IDNhanVien"].ToString(), Session["IDNhom"].ToString(), "Phiếu Chuyển Kho", dtSetting.LayIDKho(), "Nhập xuất tồn", "Thêm");
                    data.XoaChiTietPhieuChuyenKho_Temp();
                    Response.Redirect("DanhSachPhieuChuyenKho.aspx");
                }
                else
                {
                    Response.Write("<script language='JavaScript'> alert('Danh sách hàng hóa rỗng.'); </script>");
                }
            }
            else
            {
                Response.Write("<script language='JavaScript'> alert('Bạn chưa chọn kho xuất.'); </script>");
            }
        }

        protected void btnHuyPhieuXuat_Click(object sender, EventArgs e)
        {
            dtChuyenKho data = new dtChuyenKho();
            data.XoaChiTietPhieuChuyenKho_Temp();
            data.XoaPhieuChuyenKho_Null();
            Response.Redirect("DanhSachPhieuChuyenKho.aspx");
        }

        protected void cmbNgayLapPhieu_Init(object sender, EventArgs e)
        {
            cmbNgayLapPhieu.Date = DateTime.Today;
        }

        protected void gridDanhSachHangHoa_Temp_RowDeleting(object sender, DevExpress.Web.Data.ASPxDataDeletingEventArgs e)
        {
            int ID = Int32.Parse(e.Keys[0].ToString());
            dtChuyenKho data = new dtChuyenKho();
            data.XoaChiTietPhieuChuyenKho_Temp_ID(ID);
            e.Cancel = true;
            gridDanhSachHangHoa_Temp.CancelEdit();
            gridDanhSachHangHoa_Temp.DataSource = data.LayDanhSachChiTietPhieuChuyenKho_Temp();
            gridDanhSachHangHoa_Temp.DataBind();
        }
    }
}