﻿using BanHang.Data;
using DevExpress.Web;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace BanHang
{
    public partial class PhieuXuatKhac : System.Web.UI.Page
    {
        dtPhieuXuatKhac data = new dtPhieuXuatKhac();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["KTDangNhap"] != "GPM")
            {
                Response.Redirect("DangNhap.aspx");
            }
            else
            {
                if (dtSetting.LayTrangThaiMenu_ChucNang(Session["IDNhom"].ToString(), 19) == 1)
                    Response.Redirect("Default.aspx");
                if (dtSetting.LayTrangThaiMenu(Session["IDNhom"].ToString(), 19) == 1)
                {
                    if (!IsPostBack)
                    {
                        data = new dtPhieuXuatKhac();
                        data.XoaPhieuXuatKhac_Null();
                        object IDPhieuXuatKhac = data.ThemPhieuXuatKhac_Temp();
                        IDPhieuXuatKhac_Temp.Value = IDPhieuXuatKhac.ToString();
                        cmbKho.Enabled = false;
                        cmbKho.Text = dtSetting.LayIDKho() + "";
                    }
                    LoadGrid(Int32.Parse(IDPhieuXuatKhac_Temp.Value.ToString()));
                }
                else
                {
                    Response.Redirect("Default.aspx");
                }
            }
        }
       
        public void Clear()
        {
            cmbHangHoa.Text = "";
            txtSoLuong.Text = "";
            txtTonKho.Text = "";
            cmbDonViTinh.Text = "";
          
        }


        protected void cmbNgayLapPhieu_Init(object sender, EventArgs e)
        {
            cmbNgayLapPhieu.Date = DateTime.Today;
        }

        protected void cmbHangHoa_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cmbHangHoa.Text != "")
            {
                data = new dtPhieuXuatKhac();
                DataTable dt = data.LayThongTinHangHoa(Int32.Parse(cmbHangHoa.Value.ToString()));



                txtTonKho.Text = dtCapNhatTonKho.SoLuongTonKho_Client(Int32.Parse(cmbHangHoa.Value.ToString()), dtSetting.LayIDKho()) + "";
                DataRow dr = dt.Rows[0];

                cmbDonViTinh.Value = dr["IDDonViTinh"].ToString();
                txtSoLuong.Text = "0";
              
            }
        }

        protected void btnThem_Click(object sender, EventArgs e)
        {
            if (cmbHangHoa.Value != null && txtSoLuong.Text != "")
            {
                int SoLuong = Int32.Parse(txtSoLuong.Value.ToString());
                if (SoLuong > 0)
                {
                    int IDHangHoa = Int32.Parse(cmbHangHoa.Value.ToString());

                    int IDPhieuXuatKhac = Int32.Parse(IDPhieuXuatKhac_Temp.Value.ToString());
                    DataTable db = data.KTChiTietPhieuXuatKhac_Temp(IDHangHoa);// kiểm tra hàng hóa
                    if (db.Rows.Count == 0)
                    {
                        data = new dtPhieuXuatKhac();
                        data.ThemPhieuXuatKhac_Temp(IDPhieuXuatKhac, IDHangHoa, SoLuong);
                        Clear();
                    }
                    else
                    {
                        data = new dtPhieuXuatKhac();
                        data.UpdatePhieuXuatKhac_temp(IDPhieuXuatKhac, IDHangHoa, SoLuong);
                        Clear();
                    }
                    LoadGrid(IDPhieuXuatKhac);
                }
                else
                {
                    Response.Write("<script language='JavaScript'> alert('Số Lượng > 0.'); </script>");
                }
            }
            else
            {
                Response.Write("<script language='JavaScript'> alert('Bạn chưa chọn hàng hóa.'); </script>");
            }
        }

        private void LoadGrid(int IDPhieuXuatKhac)
        {
            data = new dtPhieuXuatKhac();
            gridDanhSachHangHoa_Temp.DataSource = data.LayDanhSachPhieuXuatKhac_Temp(IDPhieuXuatKhac);
            gridDanhSachHangHoa_Temp.DataBind();

        }

        protected void btnHuyPhieuXuatKhac_Click(object sender, EventArgs e)
        {
            data = new dtPhieuXuatKhac();
            int ID = Int32.Parse(IDPhieuXuatKhac_Temp.Value.ToString());
            if (ID != null)
            {
                data.XoaPhieuXuatKhac_Temp(ID);
                data.XoaPhieuXuatKhac_Null();
                data.XoaChiTietPhieuXuatKhac_Temp(ID);
                Response.Redirect("DanhSachPhieuXuatKhac.aspx");
            }
        }

        protected void btnThemPhieuXuatKhac_Click(object sender, EventArgs e)
        {
            if (cmbLyDoXuat.Value != null)
            {
                int IDPhieuXuatKhac = Int32.Parse(IDPhieuXuatKhac_Temp.Value.ToString());
                DataTable db = data.LayDanhSachPhieuXuatKhac_Temp(IDPhieuXuatKhac);
                if (db.Rows.Count != 0)
                {
                    int IDKhachHang = Int32.Parse(cmbKhachHang.Value.ToString() == null ? "" : cmbKhachHang.Value.ToString());
                    DateTime NgayLap = DateTime.Parse(cmbNgayLapPhieu.Text.ToString());
                    string GhiChu = txtGhiChu == null ? "" : txtGhiChu.Text.ToString();
                    int IDKho = dtSetting.LayIDKho();
                    string LyDoXuat = cmbLyDoXuat.Value.ToString();

                    data = new dtPhieuXuatKhac();

                    data.CapNhatPhieuXuatKhac_ID(IDPhieuXuatKhac, IDKho, IDKhachHang, LyDoXuat, NgayLap, GhiChu);

                    foreach (DataRow dr in db.Rows)
                    {
                        int IDHangHoa = Int32.Parse(dr["IDHangHoa"].ToString());

                        int SoLuong = Int32.Parse(dr["SoLuong"].ToString());

                        data = new dtPhieuXuatKhac();
                        data.ThemChiTietPhieuXuatKhac(IDPhieuXuatKhac, IDHangHoa, SoLuong);
                        dtCapNhatTonKho tk = new dtCapNhatTonKho();

                        dtLichSuKho.ThemLichSu(IDHangHoa, Int32.Parse(Session["IDNhanVien"].ToString()), SoLuong, "Phiếu xuất khác");

                        dtLichSuKho.ThemLichSuXuat(IDHangHoa, IDKhachHang, SoLuong);
                        tk.TruTonKho_IDHangHoa(IDHangHoa, SoLuong, dtSetting.LayIDKho());
                    }

                    dtLichSuTruyCap.ThemLichSu(Session["IDNhanVien"].ToString(), Session["IDNhom"].ToString(), "Phiếu Xuất Khác", dtSetting.LayIDKho(), "Nhập xuất tồn", "Thêm");  
  
                    data = new dtPhieuXuatKhac();
                    data.XoaChiTietPhieuXuatKhac_Temp(IDPhieuXuatKhac);
                    Response.Redirect("DanhSachPhieuXuatKhac.aspx");
                }
                else
                {
                    Response.Write("<script language='JavaScript'> alert('Danh sách hàng hóa rỗng.'); </script>");
                }
            }
            else
            {
                Response.Write("<script language='JavaScript'> alert('Bạn chưa chọn lý do xuất.'); </script>");
            }
        }

        protected void gridDanhSachHangHoa_Temp_RowDeleting(object sender, DevExpress.Web.Data.ASPxDataDeletingEventArgs e)
        {
            int ID = Int32.Parse(e.Keys[0].ToString());
            data = new dtPhieuXuatKhac();
            data.XoaChiTietPhieuXuatKhac_Temp_ID(ID);
            e.Cancel = true;
            gridDanhSachHangHoa_Temp.CancelEdit();
            int IDPhieuXuatKhac = Int32.Parse(IDPhieuXuatKhac_Temp.Value.ToString());
            LoadGrid(IDPhieuXuatKhac);
        }

        protected void cmbHangHoa_ItemsRequestedByFilterCondition(object source, DevExpress.Web.ListEditItemsRequestedByFilterConditionEventArgs e)
        {
            ASPxComboBox comboBox = (ASPxComboBox)source;

            sqlHangHoa.SelectCommand = @"SELECT [ID], [MaHang], [TenHangHoa], [GiaMua] , [TenDonViTinh]
                                        FROM (
	                                        select GPM_HangHoa.ID, GPM_HangHoa.MaHang, GPM_HangHoa.TenHangHoa, GPM_HangHoa.GiaMua, GPM_DonViTinh.TenDonViTinh, 
	                                        row_number()over(order by GPM_HangHoa.MaHang) as [rn] 
	                                        FROM GPM_DonViTinh INNER JOIN GPM_HangHoa ON GPM_DonViTinh.ID = GPM_HangHoa.IDDonViTinh 
                                                               INNER JOIN GPM_HangHoaTonKho ON GPM_HangHoaTonKho.IDHangHoa = GPM_HangHoa.ID
	                                        WHERE (GPM_HangHoa.MaHang LIKE @MaHang) AND (GPM_HangHoaTonKho.IDKho = @IDKho) AND (GPM_HangHoaTonKho.DaXoa = 0)	
	                                        ) as st 
                                        where st.[rn] between @startIndex and @endIndex";

            sqlHangHoa.SelectParameters.Clear();
            sqlHangHoa.SelectParameters.Add("MaHang", TypeCode.String, string.Format("%{0}%", e.Filter));
            sqlHangHoa.SelectParameters.Add("IDKho", TypeCode.Int32, dtSetting.LayIDKho() + "");
            sqlHangHoa.SelectParameters.Add("startIndex", TypeCode.Int64, (e.BeginIndex + 1).ToString());
            sqlHangHoa.SelectParameters.Add("endIndex", TypeCode.Int64, (e.EndIndex + 1).ToString());
            comboBox.DataSource = sqlHangHoa;
            comboBox.DataBind();
        }

        protected void cmbHangHoa_ItemRequestedByValue(object source, DevExpress.Web.ListEditItemRequestedByValueEventArgs e)
        {
            long value = 0;
            if (e.Value == null || !Int64.TryParse(e.Value.ToString(), out value))
                return;
            ASPxComboBox comboBox = (ASPxComboBox)source;
            sqlHangHoa.SelectCommand = @"SELECT GPM_HangHoa.ID, GPM_HangHoa.MaHang, GPM_HangHoa.TenHangHoa, GPM_HangHoa.GiaMua, GPM_DonViTinh.TenDonViTinh 
                                        FROM GPM_DonViTinh INNER JOIN GPM_HangHoa ON GPM_DonViTinh.ID = GPM_HangHoa.IDDonViTinh 
                                                           INNER JOIN GPM_HangHoaTonKho ON GPM_HangHoaTonKho.IDHangHoa = GPM_HangHoa.ID 
                                        WHERE (GPM_HangHoa.ID = @ID)";

            sqlHangHoa.SelectParameters.Clear();
            sqlHangHoa.SelectParameters.Add("ID", TypeCode.Int64, e.Value.ToString());
            comboBox.DataSource = sqlHangHoa;
            comboBox.DataBind();
        }

        protected void txtSoLuong_NumberChanged(object sender, EventArgs e)
        {
            if (txtSoLuong.Text != "")
            {
                int SoLuong = Int32.Parse(txtSoLuong.Value.ToString());
                int SLCon = Int32.Parse(txtTonKho.Text);
                if (dtSetting.KT_SoLuong() != 0)
                {
                    if (SLCon < SoLuong)
                    {
                        txtSoLuong.Text = SLCon.ToString();
                        Response.Write("<script language='JavaScript'> alert('Số hàng trong kho không đủ.'); </script>");
                    }
                }
            }
        }

    }
}