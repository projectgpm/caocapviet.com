﻿using BanHang.Data;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace BanHang
{
    public partial class DanhSachPhieuChuyenKho : System.Web.UI.Page
    {
        dtChuyenKho data = new dtChuyenKho();
        private int VisibleIndexHere;
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["KTDangNhap"] != "GPM")
            {
                Response.Redirect("DangNhap.aspx");
            }
            else
            {
                if (dtSetting.LayTrangThaiMenu_ChucNang(Session["IDNhom"].ToString(), 20) == 1)
                    btnThemPhieuXuatKhac.Enabled = false;
                if (dtSetting.LayTrangThaiMenu(Session["IDNhom"].ToString(), 20) == 1)
                {
                    dtChuyenKho da = new dtChuyenKho();
                    data.XoaPhieuChuyenKho_Null();
                    LoadGrid();
                }
                else
                {
                    Response.Redirect("Default.aspx");
                }
            }
        }

        private void LoadGrid()
        {
            DataTable da = data.LayDanhSachPhieuChuyenKho();
            DataTable da2 = new DataTable();
            da2.Columns.Add("ID", typeof(int));
            da2.Columns.Add("IDKhoXuat", typeof(int));
            da2.Columns.Add("IDKhoNhap", typeof(int));
            da2.Columns.Add("NgayLap", typeof(DateTime));
            da2.Columns.Add("GhiChu", typeof(string));
            da2.Columns.Add("KhoXuat", typeof(string));
            da2.Columns.Add("KhoNhap", typeof(string));
            da2.Columns.Add("KhoServer", typeof(string));
            if (da.Rows.Count != 0)
            {
                for (int i = 0; i < da.Rows.Count; i++)
                {
                    DataRow dr = da.Rows[i];
                    int TrangThai = Int32.Parse(dr["TrangThai"].ToString());
                    string KhoXuat = "Đang chờ duyệt";
                    string KhoNhap = "Đã duyệt";
                    string KhoServer = "Đang chờ duyệt";

                    if (TrangThai >= 1 && TrangThai < 3) KhoXuat = "Đã duyệt phiếu";
                    if (TrangThai >= 2) KhoServer = "Đã duyệt phiếu";
                    if (TrangThai >= 3) KhoXuat = "Đã Xuất Hàng";
                    if (TrangThai >= 4) KhoNhap = "Đã Nhận Hàng";

                    int ID = Int32.Parse(dr["ID"].ToString());
                    int IDKhoXuat = Int32.Parse(dr["IDKhoXuat"].ToString());
                    int IDKhoNhap = Int32.Parse(dr["IDKhoNhap"].ToString());
                    DateTime NgayLap = DateTime.Parse(dr["NgayLap"].ToString());
                    string GhiChu = dr["GhiChu"].ToString();
                    DataRow dr2 = da2.NewRow();

                    dr2["ID"] = ID;
                    dr2["IDKhoXuat"] = IDKhoXuat;
                    dr2["IDKhoNhap"] = IDKhoNhap;
                    dr2["NgayLap"] = NgayLap;
                    dr2["GhiChu"] = GhiChu;
                    dr2["KhoXuat"] = KhoXuat;
                    dr2["KhoNhap"] = KhoNhap;
                    dr2["KhoServer"] = KhoServer;
                    da2.Rows.Add(dr2);
                }
                gridPhieuChuyenKho.DataSource = da2;
                gridPhieuChuyenKho.DataBind();
            }
        }

        protected void gridPhieuChuyenKho_CustomButtonCallback(object sender, DevExpress.Web.ASPxGridViewCustomButtonCallbackEventArgs e)
        {
            if(e.ButtonID == "DuyetDonHang")
            {
                int ID = Int32.Parse(gridPhieuChuyenKho.GetRowValues(VisibleIndexHere, gridPhieuChuyenKho.KeyFieldName).ToString());
                dtChuyenKho dt = new dtChuyenKho();
                DataTable dataPhieuChuyen = dt.LayDanhSachPhieuChuyenKho_ID(ID);
                if (dataPhieuChuyen.Rows.Count != 0)
                {
                    DataRow dr = dataPhieuChuyen.Rows[0];
                    int IDKhoXuat = Int32.Parse(dr["IDKhoXuat"].ToString());
                    int IDKhoNhap = Int32.Parse(dr["IDKhoNhap"].ToString());
                    int TrangThai = Int32.Parse(dr["TrangThai"].ToString());

                    if (IDKhoXuat == dtSetting.LayIDKho())
                    {
                        if (TrangThai == 0)
                        {
                            dt.DuyetPhieuChuyen_DuyetHang(ID);
                        }
                        else if (TrangThai == 2)
                        {
                            dt.DuyetPhieuChuyen_DuyetHang(ID);
                            // Trừ tồn kho...
                            DataTable da = dt.LayDanhSachChiTietPhieuChuyenKho_ID(ID);
                            if (da.Rows.Count != 0)
                            {
                                for (int i = 0; i < da.Rows.Count; i++)
                                {
                                    DataRow drx = da.Rows[i];
                                    int IDHangHoa = Int32.Parse(drx["IDHangHoa"].ToString());
                                    int SoLuong = Int32.Parse(drx["SoLuong"].ToString());
                                    dtCapNhatTonKho tk = new dtCapNhatTonKho();
                                    tk.TruTonKho_IDHangHoa(IDHangHoa, SoLuong, dtSetting.LayIDKho());
                                }
                            }
                        }
                        else
                        {
                            
                        }
                    }
                    else if (IDKhoNhap == dtSetting.LayIDKho())
                    {
                        if (TrangThai == 3)
                        {
                            dt.DuyetPhieuChuyen_DuyetHang(ID);
                            // Cộng tồn kho...
                            DataTable da = dt.LayDanhSachChiTietPhieuChuyenKho_ID(ID);
                            if (da.Rows.Count != 0)
                            {
                                for (int i = 0; i < da.Rows.Count; i++)
                                {
                                    DataRow drx = da.Rows[i];
                                    int IDHangHoa = Int32.Parse(drx["IDHangHoa"].ToString());
                                    int SoLuong = Int32.Parse(drx["SoLuong"].ToString());
                                    dtCapNhatTonKho tk = new dtCapNhatTonKho();
                                    tk.CongTonKho_IDHangHoa(IDHangHoa, SoLuong, dtSetting.LayIDKho());
                                }
                            }
                        }
                        else
                        {
                            
                        }
                    }
                    else
                    {
                        if (TrangThai == 1)
                        {
                            dt.DuyetPhieuChuyen_DuyetHang(ID);
                        }
                        else
                        {
                            
                        }
                    }
                }
                
            }
            LoadGrid();
        }

        protected void btnThemPhieuXuatKhac_Click(object sender, EventArgs e)
        {
            Response.Redirect("PhieuChuyenKho.aspx");
        }
    }
}