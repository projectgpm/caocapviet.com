﻿using BanHang.Data;
using DevExpress.Web;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace BanHang
{
    public partial class KiemKho : System.Web.UI.Page
    {
        dtKiemKho data = new dtKiemKho();
        int IDKho = dtSetting.LayIDKho();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["KTDangNhap"] != "GPM")
            {
                Response.Redirect("DangNhap.aspx");
            }
            else
            {
                if (dtSetting.LayTrangThaiMenu_ChucNang(Session["IDNhom"].ToString(), 21) == 1)
                    Response.Redirect("Default.aspx");
                if (dtSetting.LayTrangThaiMenu(Session["IDNhom"].ToString(), 21) == 1)
                {
                    if (!IsPostBack)
                    {
                        data = new dtKiemKho();
                        data.XoaPhieuKiemKho_Null();
                        object IDPhieuKiemKho = data.ThemPhieuKiemKho();
                        IDPhieuKiemKho_Temp.Value = IDPhieuKiemKho.ToString();
                        txtNguoiTao.Text = Session["TenDangNhap"] == null ? "" : Session["TenDangNhap"].ToString();
                    }
                    LoadGrid(Int32.Parse(IDPhieuKiemKho_Temp.Value));
                }
                else
                {
                    Response.Redirect("Default.aspx");
                }
            }
        }

        protected void gridDanhSachHangHoa_Temp_RowDeleting(object sender, DevExpress.Web.Data.ASPxDataDeletingEventArgs e)
        {
            int ID = Int32.Parse(e.Keys[0].ToString());
            int IDPhieuKiemKho = Int32.Parse(IDPhieuKiemKho_Temp.Value);
            data = new dtKiemKho();
            data.XoaPhieuKiemKho_Temp_ID(ID);
            e.Cancel = true;
            gridDanhSachHangHoa_Temp.CancelEdit();
            LoadGrid(IDPhieuKiemKho);
        }
        protected void btnInsertHang_Click(object sender, EventArgs e)
        {
            try
            {
                if (txtBarcode.Text.Trim() != "")
                {
                    int IDPhieuKiemKho = Int32.Parse(IDPhieuKiemKho_Temp.Value);
                    int IDHangHoa = -1;
                    if (dtKiemKho.LayIDHangHoa_Barcode(txtBarcode.Text.ToString()) != -1)
                    {
                        IDHangHoa = dtKiemKho.LayIDHangHoa_Barcode(txtBarcode.Text.ToString());
                    }
                    else if (dtKiemKho.LayIDHangHoa_HangHoa(txtBarcode.Value.ToString()) != -1)
                    {
                        IDHangHoa = dtKiemKho.LayIDHangHoa_HangHoa(txtBarcode.Value.ToString());
                    }
                    if (IDHangHoa != -1)
                    {
                        int TonKho = dtCapNhatTonKho.SoLuongTonKho_Client(IDHangHoa, IDKho);
                        int ChechLech = -TonKho;
                        DataTable dt = data.KTChiTietPhieuKiemKho_Temp(IDHangHoa, IDPhieuKiemKho);
                        if (dt.Rows.Count == 0)
                        {
                            data = new dtKiemKho();
                            data.ThemPhieuKiemKho_Temp(IDPhieuKiemKho, IDHangHoa, TonKho, ChechLech);
                            LoadGrid(IDPhieuKiemKho);
                        }
                    }
                    else
                        ClientScript.RegisterStartupScript(this.GetType(), "alert", "alert('Mã hàng không tồn tại!!');", true);
                }
                txtBarcode.Focus();
                txtBarcode.Text = "";
                txtBarcode.Value = "";
            }
            catch (Exception ex)
            
            {
                txtBarcode.Focus();
                txtBarcode.Text = "";
                txtBarcode.Value = "";
                ClientScript.RegisterStartupScript(this.GetType(), "alert", "alert('Mã hàng không tồn tại!!');", true);
            }
        }
        protected void btnHoanThanh_Click(object sender, EventArgs e)
        {
            int IDPhieuKiemKho = Int32.Parse(IDPhieuKiemKho_Temp.Value);
            DataTable db = data.DanhSachKiemKhoTemp_IDPhieuKiemKho(IDPhieuKiemKho);
            if (db.Rows.Count != 0)
            {
                int IDNguoiDung = Int32.Parse(Session["IDNhanVien"].ToString());
                DateTime NgayCanBang = DateTime.Parse(dataNgayCanBang.Text.ToString());
                string GhiChu = txtGhiChu.Text.ToString();
                data = new dtKiemKho();
                data.CapNhatPhieuKiemKho(IDPhieuKiemKho, IDNguoiDung, NgayCanBang, IDKho, GhiChu);
                foreach (DataRow dr in db.Rows)
                {
                    int IDHangHoa = Int32.Parse(dr["IDHangHoa"].ToString());
                    int TonKho = Int32.Parse(dr["TonKho"].ToString());
                    int ChenhLech = Int32.Parse(dr["ChenhLech"].ToString());
                    int ThucTe = Int32.Parse(dr["ThucTe"].ToString());

                    //kiểm tra coog tồn kho, hay tạo bảng riêng chưa làm
                    data = new dtKiemKho();
                    data.ThemPhieuKiemKho(IDPhieuKiemKho, IDHangHoa, TonKho, ChenhLech, ThucTe);

                    dtCapNhatTonKho tk = new dtCapNhatTonKho();

                    dtLichSuKho.ThemLichSu(IDHangHoa, Int32.Parse(Session["IDNhanVien"].ToString()), (TonKho - ThucTe), "Kiểm kho. Số lượng thực tế và tồn kho.");
                    tk.TruTonKho_IDHangHoa(IDHangHoa, (TonKho - ThucTe), dtSetting.LayIDKho());
                }
                data = new dtKiemKho();
                data.XoaPhieuKiemKho_Temp_IDPhieuKiemKho(IDPhieuKiemKho);
                Response.Redirect("DanhSachKiemKho.aspx");

                dtLichSuTruyCap.ThemLichSu(Session["IDNhanVien"].ToString(), Session["IDNhom"].ToString(), "Kiểm Kho", dtSetting.LayIDKho(), "Nhập xuất tồn", "Thêm");  
            }
            else
            {
                txtBarcode.Focus();
                Response.Write("<script language='JavaScript'> alert('Danh sách hàng hóa kiểm kho rỗng.'); </script>");
                
            }
        }

        protected void btnHuy_Click(object sender, EventArgs e)
        {
            data = new dtKiemKho();
            int IDPhieuKiemKho = Int32.Parse(IDPhieuKiemKho_Temp.Value);
            data.XoaPhieuKiemKho_Temp_IDPhieuKiemKho(IDPhieuKiemKho);
            data.XoaPhieuKiemKho_Null();
            Response.Redirect("DanhSachKiemKho.aspx");
        }
        
        protected void cmbMaHang_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cmbMaHang.Text != "")
            {
                data = new dtKiemKho();
                DataTable db = data.LayDanhSachHangHoa_IDNhomHang(Int32.Parse(cmbMaHang.Value.ToString()));
                if (db.Rows.Count != 0)
                {
                    int IDPhieuKiemKho = Int32.Parse(IDPhieuKiemKho_Temp.Value);
                    foreach (DataRow dr in db.Rows)
                    {
                        int IDHangHoa = Int32.Parse(dr["ID"].ToString());
                        int TonKho = dtCapNhatTonKho.SoLuongTonKho_Client(IDHangHoa, IDKho);
                        int ChechLech = -TonKho;
                        DataTable dt = data.KTChiTietPhieuKiemKho_Temp(IDHangHoa, IDPhieuKiemKho);
                        if (dt.Rows.Count == 0)
                        {
                            data = new dtKiemKho();
                            data.ThemPhieuKiemKho_Temp(IDPhieuKiemKho, IDHangHoa, TonKho, ChechLech);
                        }
                    }
                    LoadGrid(IDPhieuKiemKho);
                    cmbMaHang.Text = "";
                }
                else
                {
                    cmbMaHang.Text = "";
                    Response.Write("<script language='JavaScript'> alert('Không có hàng hóa thuộc nhóm hàng này.'); </script>");
                }
            }
        }
        public void LoadGrid(int IDPhieuKiemKho)
        {
            data = new dtKiemKho();
            gridDanhSachHangHoa_Temp.DataSource = data.DanhSachKiemKhoTemp_IDPhieuKiemKho(IDPhieuKiemKho);
            gridDanhSachHangHoa_Temp.DataBind();
        }

        protected void dataNgayCanBang_Init(object sender, EventArgs e)
        {
            dataNgayCanBang.Date = DateTime.Today;
        }

        protected void gridDanhSachHangHoa_Temp_RowUpdated(object sender, DevExpress.Web.Data.ASPxDataUpdatedEventArgs e)
        {
            

        }

        protected void gridDanhSachHangHoa_Temp_RowUpdating(object sender, DevExpress.Web.Data.ASPxDataUpdatingEventArgs e)
        {
            int IDPhieuKiemKho = Int32.Parse(IDPhieuKiemKho_Temp.Value);
            int ID = Int32.Parse(e.Keys[0].ToString());
            int ThucTe = Int32.Parse(e.NewValues["ThucTe"].ToString());

            int IDHangHoa = Int32.Parse(e.NewValues["IDHangHoa"].ToString());
            int TonKho = dtCapNhatTonKho.SoLuongTonKho_Client(IDHangHoa, IDKho);
           
            data = new dtKiemKho();
            data.CapNhatPhieuKiemKho_Temp(ID, ThucTe, ThucTe - TonKho);
            e.Cancel = true;
            gridDanhSachHangHoa_Temp.CancelEdit();
            LoadGrid(IDPhieuKiemKho);
        }

        protected void txtBarcode_ItemRequestedByValue(object source, DevExpress.Web.ListEditItemRequestedByValueEventArgs e)
        {
            long value = 0;
            if (e.Value == null || !Int64.TryParse(e.Value.ToString(), out value))
                return;
            ASPxComboBox comboBox = (ASPxComboBox)source;
            dsHangHoa.SelectCommand = @"SELECT GPM_HangHoa.ID, GPM_HangHoa.MaHang, GPM_HangHoa.TenHangHoa, GPM_HangHoa.GiaMua, GPM_DonViTinh.TenDonViTinh 
                                        FROM GPM_DonViTinh INNER JOIN GPM_HangHoa ON GPM_DonViTinh.ID = GPM_HangHoa.IDDonViTinh 
                                                           INNER JOIN GPM_HangHoaTonKho ON GPM_HangHoaTonKho.IDHangHoa = GPM_HangHoa.ID 
                                        WHERE (GPM_HangHoa.ID = @ID)";

            dsHangHoa.SelectParameters.Clear();
            dsHangHoa.SelectParameters.Add("ID", TypeCode.Int64, e.Value.ToString());
            comboBox.DataSource = dsHangHoa;
            comboBox.DataBind();
        }

        protected void txtBarcode_ItemsRequestedByFilterCondition(object source, DevExpress.Web.ListEditItemsRequestedByFilterConditionEventArgs e)
        {
            ASPxComboBox comboBox = (ASPxComboBox)source;

            dsHangHoa.SelectCommand = @"SELECT [ID], [MaHang], [TenHangHoa], [GiaMua] , [TenDonViTinh]
                                        FROM (
	                                        select GPM_HangHoa.ID, GPM_HangHoa.MaHang, GPM_HangHoa.TenHangHoa, GPM_HangHoa.GiaMua, GPM_DonViTinh.TenDonViTinh, 
	                                        row_number()over(order by GPM_HangHoa.MaHang) as [rn] 
	                                        FROM GPM_DonViTinh INNER JOIN GPM_HangHoa ON GPM_DonViTinh.ID = GPM_HangHoa.IDDonViTinh 
                                                               INNER JOIN GPM_HangHoaTonKho ON GPM_HangHoaTonKho.IDHangHoa = GPM_HangHoa.ID
	                                        WHERE (GPM_HangHoa.MaHang LIKE @MaHang) AND (GPM_HangHoaTonKho.IDKho = @IDKho) AND (GPM_HangHoaTonKho.DaXoa = 0)	
	                                        ) as st 
                                        where st.[rn] between @startIndex and @endIndex";

            dsHangHoa.SelectParameters.Clear();
            dsHangHoa.SelectParameters.Add("MaHang", TypeCode.String, string.Format("%{0}%", e.Filter));
            dsHangHoa.SelectParameters.Add("IDKho", TypeCode.Int32, dtSetting.LayIDKho() + "");
            dsHangHoa.SelectParameters.Add("startIndex", TypeCode.Int64, (e.BeginIndex + 1).ToString());
            dsHangHoa.SelectParameters.Add("endIndex", TypeCode.Int64, (e.EndIndex + 1).ToString());
            comboBox.DataSource = dsHangHoa;
            comboBox.DataBind();
        }

        
    }
}