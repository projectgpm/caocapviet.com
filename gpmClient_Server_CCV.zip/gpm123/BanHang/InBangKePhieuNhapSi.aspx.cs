﻿using BanHang.Data;
using BanHang.Report;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace BanHang
{
    public partial class InBanKePhieuNhapSi : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            int IDKhoHang = Int32.Parse(Request.QueryString["khohang"]);
            int IDNhaCC = Int32.Parse(Request.QueryString["nhacc"]);
            string strNhaCC = "Tất cả nhà cung cấp", strKho = "Tất cả kho hàng";

            dtThongTinCuaHangKho dt = new dtThongTinCuaHangKho();
            DataTable da = dt.LayDanhSach_ID_2(dtSetting.LayIDKho());
            DataRow dr = da.Rows[0];
            string strCty = dr["TenCuaHang"].ToString();

            if (IDKhoHang != -1)
            {
                dtThongTinCuaHangKho d = new dtThongTinCuaHangKho();
                da = d.LayDanhSach_ID_2(IDKhoHang);
                if (da.Rows.Count != 0)
                {
                    dr = da.Rows[0];
                    strKho = dr["TenCuaHang"].ToString();
                }
            }
            if (IDNhaCC != -1)
            {
                dtNhaCungCap d1 = new dtNhaCungCap();
                da = d1.LayDanhSachNhaCungCap_ID(IDNhaCC);
                if (da.Rows.Count != 0)
                {
                    dr = da.Rows[0];
                    strNhaCC = dr["TenNhaCungCap"].ToString();
                }
            }

            rpBangKePhieuNhapSi rp = new rpBangKePhieuNhapSi();

            rp.Parameters["strCty"].Value = strCty;
            rp.Parameters["strNhaCC"].Value = strNhaCC;
            rp.Parameters["strKho"].Value = strKho;
            rp.Parameters["strCty"].Visible = false;
            rp.Parameters["strNhaCC"].Visible = false;
            rp.Parameters["strKho"].Visible = false;

            rp.Parameters["KhoHang"].Value = IDKhoHang;
            rp.Parameters["NhaCC"].Value = IDNhaCC;
            rp.Parameters["KhoHang"].Visible = false; 
            rp.Parameters["NhaCC"].Visible = false;

            rp.Parameters["NgayBD"].Value = Request.QueryString["ngaybd"] + " 00:00:00.000";
            rp.Parameters["NgayBD"].Visible = false;
            rp.Parameters["NgayKT"].Value = Request.QueryString["ngaykt"] + " 23:59:59.000";
            rp.Parameters["NgayKT"].Visible = false;
            DateTime d3= DateTime.Parse(Request.QueryString["ngaybd"]);
            string s = d3.Date.ToString("dd/MM/yyyy");
            DateTime d2 = DateTime.Parse(Request.QueryString["ngaykt"]);
            string s2 = d2.Date.ToString("dd/MM/yyyy");
            rp.Parameters["strNgay"].Value = s + " - " + s2;
            rp.Parameters["strNgay"].Visible = false;
            reportView.Report = rp;
        }
    }
}