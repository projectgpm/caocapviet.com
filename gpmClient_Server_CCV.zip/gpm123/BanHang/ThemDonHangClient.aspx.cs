﻿using BanHang.Data;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.OleDb;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace BanHang
{
    public partial class ThemDonHangClient : System.Web.UI.Page
    {
        dtThemDonHangClient data = new dtThemDonHangClient();
        protected void Page_Load(object sender, EventArgs e)
        {
            //if (dtSetting.LayTrangThaiMenu(Session["IDNhom"].ToString(), 24) == 1)
            //{
                if (!IsPostBack)
                {
                    data = new dtThemDonHangClient();
                    object IDPhieuDatHang = data.ThemPhieuDatHangClient();
                    IDPhieuDatHangClient_Temp.Value = IDPhieuDatHang.ToString();
                    cmbKho.Text = dtSetting.LayIDKho().ToString();
                }
                LoadGrid(Int32.Parse(IDPhieuDatHangClient_Temp.Value));
            //}
            //else
            //{
            //    Response.Redirect("Default.aspx");
            //}
        }

        private void LoadGrid(int IDPhieuDatHang)
        {

            gridHangHoa.DataSource = dtThemDonHangClient.DanhSachDonDatHangClient_Temp(IDPhieuDatHang);
            gridHangHoa.DataBind();
        }

        protected void dataNgayLapPhieu_Init(object sender, EventArgs e)
        {
            dataNgayLapPhieu.Date = DateTime.Today;
        }
        
       

        protected void txtSoLuong_NumberChanged(object sender, EventArgs e)
        {
            if (txtBarcode.Text != "")
            {
                int SL = Int32.Parse(txtSoLuong.Text);
                double DG = double.Parse(txtDonGia.Text);
                txtThanhTien.Text = (SL * DG).ToString();
            }
        }

        protected void btnThemTemp_Click(object sender, EventArgs e)
        {
            if (txtBarcode.Text != "")
            {
                int SL = Int32.Parse(txtSoLuong.Text);
                if (SL > 0)
                {
                    int IDPhieuDatHang = Int32.Parse(IDPhieuDatHangClient_Temp.Value);
                    int IDHangHoa = -1;
                    if (dtKiemKho.LayIDHangHoa_Barcode(txtBarcode.Text.ToString()) != -1)
                    {
                        IDHangHoa = dtKiemKho.LayIDHangHoa_Barcode(txtBarcode.Text.ToString());
                    }
                    else if (dtKiemKho.LayIDHangHoa_HangHoa(txtBarcode.Value.ToString()) != -1)
                    {
                        IDHangHoa = dtKiemKho.LayIDHangHoa_HangHoa(txtBarcode.Value.ToString());
                    }
                    if (IDHangHoa != -1)
                    {
                        float DG = float.Parse(txtDonGia.Text);

                        double ThanhTien = Double.Parse(txtThanhTien.Text);
                        string MaHang = dtSetting.LayMaHang(IDHangHoa);
                        DataTable db = dtThemDonHangClient.KTChiTietDonHang_Temp(IDHangHoa, IDPhieuDatHang);// kiểm tra hàng hóa
                        if (db.Rows.Count == 0)
                        {
                        
                            dtThemDonHangClient.ThemChiTietDonHang_Temp(IDPhieuDatHang, MaHang, IDHangHoa, SL, DG, float.Parse(ThanhTien + ""));
                            Clear();
                        }
                        else
                        {
                           
                            dtThemDonHangClient.UpdateChiTietDonHang_temp(IDPhieuDatHang, IDHangHoa, SL, DG, float.Parse(ThanhTien + ""));
                            Clear();
                        }
                        LoadGrid(IDPhieuDatHang);
                    }
                    else
                    {
                        
                        ClientScript.RegisterStartupScript(this.GetType(), "alert", "alert('Mã hàng không tồn tại!!');", true);
                    }
                }
                else
                {
                    Response.Write("<script language='JavaScript'> alert('Số lượng phải > 0.'); </script>");
                }
            }
            else
            {
                Response.Write("<script language='JavaScript'> alert('Bạn chưa chọn hàng hóa.'); </script>");
            }
        }
        public void Clear()
        {
            txtBarcode.Text = "";
            txtTonKho.Text = "";
            txtSoLuong.Text = "";
            txtDonGia.Text = "";
            txtThanhTien.Text = "";
        }
        protected void btnLoadFileExcel_Click(object sender, EventArgs e)
        {
            Import();
        }
        private void Import()
        {
            if (string.IsNullOrEmpty(UploadFileExcel.FileName))
            {
                Response.Write("<script language='JavaScript'> alert('Chưa chọn file.'); </script>");
                return;
            }

            UploadFile();
            string Excel = Server.MapPath("~/Uploads/") + strFileExcel;

            string excelConnectionString = string.Empty;
            excelConnectionString = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" + Excel + ";Extended Properties=Excel 8.0;";

            OleDbConnection excelConnection = new OleDbConnection(excelConnectionString);
            OleDbCommand cmd = new OleDbCommand("Select * from [Sheet$]", excelConnection);
            excelConnection.Open();
            OleDbDataReader dReader = default(OleDbDataReader);
            dReader = cmd.ExecuteReader();

            DataTable dataTable = new DataTable();
            dataTable.Load(dReader);
            int r = dataTable.Rows.Count;
            Import_Temp(dataTable);

        }
        private void UploadFile()
        {
            string folder = null;
            string filein = null;
            string ThangNam = null;

            ThangNam = string.Concat(System.DateTime.Now.Month.ToString(), System.DateTime.Now.Year.ToString());
            if (!Directory.Exists(Server.MapPath("~/Uploads/") + ThangNam))
            {
                Directory.CreateDirectory(Server.MapPath("~/Uploads/") + ThangNam);
            }
            folder = Server.MapPath("~/Uploads/" + ThangNam + "/");

            if (UploadFileExcel.HasFile)
            {
                strFileExcel = Guid.NewGuid().ToString();
                string theExtension = Path.GetExtension(UploadFileExcel.FileName);
                strFileExcel += theExtension;

                filein = folder + strFileExcel;
                UploadFileExcel.SaveAs(filein);
                strFileExcel = ThangNam + "/" + strFileExcel;
            }
        }
        private void Import_Temp(DataTable datatable)
        {
            int intRow = datatable.Rows.Count;
            if (intRow != 0)
            {
                for (int i = 0; i <= intRow - 1; i++)
                {
                    DataRow dr = datatable.Rows[i];
                    string MaHang = dr["MaHang"].ToString().Trim();
                    string TenHangHoa = dr["TenHangHoa"].ToString();
                    int SoLuong = Int32.Parse(dr["SoLuong"].ToString());
                    if (SoLuong > 0)
                    {
                        int IDPhieuDatHang = Int32.Parse(IDPhieuDatHangClient_Temp.Value);
                        int IDHangHoa = dtThemDonHangClient.LayIDHangHoa_MaHang_TenHangHoa(MaHang, TenHangHoa);
                        float GiaBan = dtCapNhatTonKho.GiaBan_Client(IDHangHoa);
                        float ThanhTien = SoLuong * GiaBan;
                        //data = new dtThemDonHangClient();
                        DataTable db = dtThemDonHangClient.KTChiTietDonHang_Temp(IDHangHoa, IDPhieuDatHang);// kiểm tra hàng hóa
                        if (db.Rows.Count == 0)
                        {
                            
                            dtThemDonHangClient.ThemChiTietDonHang_Temp(IDPhieuDatHang, MaHang, IDHangHoa, SoLuong, GiaBan, ThanhTien);

                        }
                        else
                        {
                           
                            dtThemDonHangClient.UpdateChiTietDonHang_temp(IDPhieuDatHang, IDHangHoa, SoLuong, GiaBan, ThanhTien);
                            
                        }
                        LoadGrid(IDPhieuDatHang);
                    }
                    else
                    {
                        Response.Write("<script language='JavaScript'> alert('Số lượng phải > 0.'); </script>");
                    }
                    
                }
            }

        }
        protected void gridHangHoa_RowDeleting(object sender, DevExpress.Web.Data.ASPxDataDeletingEventArgs e)
        {
            int IDPhieuDatHang = Int32.Parse(IDPhieuDatHangClient_Temp.Value);
            int ID = Int32.Parse(e.Keys[0].ToString());
            data = new dtThemDonHangClient();
            data.XoaChiTietDonHang_Temp_ID(ID);
            e.Cancel = true;
            gridHangHoa.CancelEdit();
            LoadGrid(IDPhieuDatHang);
        }

        protected void gridHangHoa_RowUpdating(object sender, DevExpress.Web.Data.ASPxDataUpdatingEventArgs e)
        {

        }

        protected void btnThem_Click(object sender, EventArgs e)
        {
            data = new dtThemDonHangClient();
            int IDPhieuDatHang = Int32.Parse(IDPhieuDatHangClient_Temp.Value);
            DataTable dt = dtThemDonHangClient.DanhSachDonDatHangClient_Temp(IDPhieuDatHang);
            if (dt.Rows.Count != 0)
            {
                DateTime NgayLapPhieu = DateTime.Parse(dataNgayLapPhieu.Text);
                string GhiChu = txtGhiChu.Text;
                float TongTien = 0;
                foreach (DataRow dr in dt.Rows)
                {
                    float ThanhTien = float.Parse(dr["ThanhTien"].ToString());
                    TongTien = TongTien + ThanhTien;
                }
                data = new dtThemDonHangClient();
                data.CapNhatDonDatHangClient(IDPhieuDatHang, dtSetting.LayIDKho(), NgayLapPhieu, TongTien, GhiChu, Session["IDNhanVien"].ToString());
                foreach (DataRow dr in dt.Rows)
                {
                    string MaHang = dr["MaHang"].ToString();
                    int IDHangHoa = Int32.Parse(dr["IDHangHoa"].ToString());
                    int IDDonDatHang = Int32.Parse(dr["IDDonDatHang"].ToString());
                    int SoLuong = Int32.Parse(dr["SoLuong"].ToString());
                    float DonGia = float.Parse(dr["DonGia"].ToString());
                    float ThanhTien = float.Parse(dr["ThanhTien"].ToString());
                    data = new dtThemDonHangClient();
                    data.ThemChiTietDonHangClient(IDPhieuDatHang, MaHang, IDHangHoa, SoLuong, DonGia, ThanhTien);
                }
                //data = new dtThemDonHangClient();
                dtThemDonHangClient.XoaChiTietDonHang_Temp();
                dtLichSuTruyCap.ThemLichSu(Session["IDNhanVien"].ToString(), Session["IDNhom"].ToString(), "Đơn Đặt Hàng", dtSetting.LayIDKho(), "Nhập xuất tồn", "Thêm");  
                Response.Write("<script language='JavaScript'> alert('Đơn đặt hàng đã được gửi vui lòng chờ duyệt.'); </script>");
                Response.Redirect("DanhSachDonHangChuaDuyet.aspx");

            }
            else
            {
                Response.Write("<script language='JavaScript'> alert('Danh sách hàng hóa rỗng.'); </script>");
            }
        }

        protected void btnHuy_Click(object sender, EventArgs e)
        {
  
            dtThemDonHangClient.XoaChiTietDonHang_Temp();
            Response.Redirect("DanhSachDonHang.aspx");
        }

        protected void txtBarcode_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (txtBarcode.Text.Trim() != "")
            {
                int IDPhieuDatHang = Int32.Parse(IDPhieuDatHangClient_Temp.Value);
                int IDHangHoa = -1;
                if (dtKiemKho.LayIDHangHoa_Barcode(txtBarcode.Text.ToString()) != -1)
                {
                    IDHangHoa = dtKiemKho.LayIDHangHoa_Barcode(txtBarcode.Text.ToString());
                }
                else if (dtKiemKho.LayIDHangHoa_HangHoa(txtBarcode.Value.ToString()) != -1)
                {
                    IDHangHoa = dtKiemKho.LayIDHangHoa_HangHoa(txtBarcode.Value.ToString());
                }
                if (IDHangHoa != -1)
                {
                    txtTonKho.Text = dtCapNhatTonKho.SoLuongTonKho_Client(IDHangHoa, dtSetting.LayIDKho()).ToString();
                    float GiaBan = dtCapNhatTonKho.GiaBan_Client(IDHangHoa);
                    txtDonGia.Text = GiaBan.ToString();
                    txtSoLuong.Text = "0";
                    txtThanhTien.Text = "0";
                }
                else
                {
                    Clear();
                    ClientScript.RegisterStartupScript(this.GetType(), "alert", "alert('Mã hàng không tồn tại!!');", true);
             
                }
            }
        }
    
public  string strFileExcel { get; set; }}
}