﻿using BanHang.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace BanHang
{
    public partial class ChiecKhauTheoNganhHang : System.Web.UI.Page
    {
        dtChietKhauTheoNganhHang data = new dtChietKhauTheoNganhHang();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (dtSetting.LayTrangThaiMenu_ChucNang(Session["IDNhom"].ToString(), 11) == 1)
                gridChietKhauTheoNganhHang.Columns["iconaction"].Visible = false;

            if (dtSetting.LayTrangThaiMenu(Session["IDNhom"].ToString(), 11) == 1)
            {
                LoadGrid();
            }
            else
            { Response.Redirect("Default.aspx"); }
        }

        private void LoadGrid()
        {
            data = new dtChietKhauTheoNganhHang();
            gridChietKhauTheoNganhHang.DataSource = data.LayDanhSach();
            gridChietKhauTheoNganhHang.DataBind();
        }

        protected void gridChietKhauTheoNganhHang_RowInserting(object sender, DevExpress.Web.Data.ASPxDataInsertingEventArgs e)
        {
            data = new dtChietKhauTheoNganhHang();
            int IDNganhHang = Int32.Parse(e.NewValues["IDNganhHang"].ToString());

            double GiaTri = double.Parse(e.NewValues["GiaTri"].ToString());
            double txtGiaTri = Math.Round((GiaTri / 100), 2);
            DateTime NgayBatDau = DateTime.Parse(e.NewValues["NgayBatDau"].ToString());
            DateTime NgayKetThuc = DateTime.Parse(e.NewValues["NgayKetThuc"].ToString());
            data.Them(IDNganhHang, float.Parse(txtGiaTri + ""), NgayBatDau, NgayKetThuc);
            e.Cancel = true;
            gridChietKhauTheoNganhHang.CancelEdit();
            LoadGrid();

            ActionServer.CapNhatServer();
            dtLichSuTruyCap.ThemLichSu(Session["IDNhanVien"].ToString(), Session["IDNhom"].ToString(), "Chiết khấu theo ngành hàng: " , dtSetting.LayIDKho(), "Danh Mục", "Thêm");
        }

        protected void gridChietKhauTheoNganhHang_RowUpdating(object sender, DevExpress.Web.Data.ASPxDataUpdatingEventArgs e)
        {
            int ID = Int32.Parse(e.Keys["ID"].ToString());
            int IDNganhHang = Int32.Parse(e.NewValues["IDNganhHang"].ToString());

            double GiaTri = double.Parse(e.NewValues["GiaTri"].ToString());
            double txtGiaTri = Math.Round((GiaTri / 100), 2);
            DateTime NgayBatDau = DateTime.Parse(e.NewValues["NgayBatDau"].ToString());
            DateTime NgayKetThuc = DateTime.Parse(e.NewValues["NgayKetThuc"].ToString());
            data.Sua(ID, IDNganhHang, float.Parse(txtGiaTri + ""), NgayBatDau, NgayKetThuc);

            e.Cancel = true;
            gridChietKhauTheoNganhHang.CancelEdit();
            LoadGrid();

            ActionServer.CapNhatServer();
            dtLichSuTruyCap.ThemLichSu(Session["IDNhanVien"].ToString(), Session["IDNhom"].ToString(), "Chiết khấu theo ngành hàng: ", dtSetting.LayIDKho(), "Danh Mục", "Cập Nhật");
        }

        protected void gridChietKhauTheoNganhHang_RowDeleting(object sender, DevExpress.Web.Data.ASPxDataDeletingEventArgs e)
        {
            int ID = Int32.Parse(e.Keys[0].ToString());
            data = new dtChietKhauTheoNganhHang();
            data.Xoa(ID);
            e.Cancel = true;
            gridChietKhauTheoNganhHang.CancelEdit();
            LoadGrid();

            ActionServer.CapNhatServer();
            dtLichSuTruyCap.ThemLichSu(Session["IDNhanVien"].ToString(), Session["IDNhom"].ToString(), "Chiết khấu theo ngành hàng: " , dtSetting.LayIDKho(), "Danh Mục", "Xóa");  
        }
    }
}