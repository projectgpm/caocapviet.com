﻿using BanHang.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace BanHang
{
    public partial class DanhSachPhieuXuatSi : System.Web.UI.Page
    {
        dtPhieuXuatSi data = new dtPhieuXuatSi();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["KTDangNhap"] != "GPM")
            {
                Response.Redirect("DangNhap.aspx");
            }
            else
            {
                if (dtSetting.LayTrangThaiMenu_ChucNang(Session["IDNhom"].ToString(), 17) == 1)
                    btnThemPhieuXuatKhac.Enabled = false;
                if (dtSetting.LayTrangThaiMenu(Session["IDNhom"].ToString(), 17) == 1)
                {
                    LoadGrid();
                }
                else
                {
                    Response.Redirect("Default.aspx");
                }
            }
        }

        private void LoadGrid()
        {
            data = new dtPhieuXuatSi();
            gridPhieuXuatSi.DataSource = data.DanhSachPhieuXuatSi();
            gridPhieuXuatSi.DataBind();
        }

        protected void gridPhieuXuatSi_RowDeleting(object sender, DevExpress.Web.Data.ASPxDataDeletingEventArgs e)
        {

        }
    }
}