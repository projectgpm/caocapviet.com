﻿using BanHang.Data;
using DevExpress.Web;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace BanHang
{
    public partial class PhieuXuatTra : System.Web.UI.Page
    {
        dtPhieuXuatTra data = new dtPhieuXuatTra();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["KTDangNhap"] != "GPM")
            {
                Response.Redirect("DangNhap.aspx");
            }
            else
            {
                if (dtSetting.LayTrangThaiMenu_ChucNang(Session["IDNhom"].ToString(), 18) == 1)
                    Response.Redirect("Default.aspx");
                if (dtSetting.LayTrangThaiMenu(Session["IDNhom"].ToString(), 18) == 1)
                {
                    if (!IsPostBack)
                    {
                        data = new dtPhieuXuatTra();
                        data.XoaPhieuXuatTra_Null();
                        object IDPhieuXuatTra = data.ThemPhieuXuatTra_Temp();
                        IDPhieuXuatTra_Temp.Value = IDPhieuXuatTra.ToString();
                        txtDonGia.Enabled = false;
                        cmbKho.Enabled = false;
                        cmbKho.Text = dtSetting.LayIDKho() + "";
                    }
                    LoadGrid(Int32.Parse(IDPhieuXuatTra_Temp.Value.ToString()));
                }
                else
                {
                    Response.Redirect("Default.aspx");
                }
            }
        }
       
        protected void cmbNgayLapPhieu_Init(object sender, EventArgs e)
        {
            cmbNgayLapPhieu.Date = DateTime.Today;
        }

        protected void cmbHangHoa_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cmbHangHoa.Text != "")
            {
                data = new dtPhieuXuatTra();
               
                int IDHangHoa = Int32.Parse(cmbHangHoa.Value.ToString());
                DataTable db = data.DanhSachHangHoa(IDHangHoa);
                if (db.Rows.Count != 0)
                {
                    DataRow dr = db.Rows[0];
                    txtTonKho.Text = dr["SoLuongCon"].ToString();
                    cmbDonViTinh.Value = dr["IDDonViTinh"].ToString();
                    txtSoLuong.Text = "0";                    
                    txtDonGia.Text = dr["GiaMua"].ToString();
                    txtThanhTien.Text = (Int32.Parse(txtSoLuong.Text.ToString()) * (Int32.Parse(txtDonGia.Text))) + "";
                    //LoadHangHoa_IDNhaCungCap();
                }
            }  
        }

        protected void txtSoLuong_NumberChanged(object sender, EventArgs e)
        {
            if (cmbHangHoa.Value != null)
            {
                if (dtSetting.KT_SoLuong() == 0)
                {
                    int SoLuong = Int32.Parse(txtSoLuong.Text.ToString());
                    double GiaMua = double.Parse(txtDonGia.Text.ToString());
                    txtThanhTien.Text = (SoLuong * GiaMua).ToString();
                    
                }
                else
                {
                    int SoLuong = Int32.Parse(txtSoLuong.Text.ToString());
                    int IDHangHoa = Int32.Parse(cmbHangHoa.Value.ToString());
                    int SLTOn = Int32.Parse(txtTonKho.Text);
                    if (SoLuong > SLTOn)
                    {
                        Response.Write("<script language='JavaScript'> alert('Số lượng vượt quá cho phép.'); </script>");
                        txtSoLuong.Text = SLTOn.ToString();
                        double GiaMua = double.Parse(txtDonGia.Text.ToString());
                        txtThanhTien.Text = (SLTOn * GiaMua).ToString();
       
                    }
                    else
                    {
                        double GiaMua = double.Parse(txtDonGia.Text.ToString());
                        txtThanhTien.Text = (SoLuong * GiaMua).ToString();
                    }
                    
                }
   
            }
        }

        protected void btnThem_Click(object sender, EventArgs e)
        {
            if(cmbHangHoa.Text != "" && txtSoLuong.Text !="")
            {
                int SoLuong = Int32.Parse(txtSoLuong.Value.ToString());
                if (SoLuong > 0)
                {
                    int IDHangHoa = Int32.Parse(cmbHangHoa.Value.ToString());
                    data = new dtPhieuXuatTra();

                    int IDPhieuXuatTra = Int32.Parse(IDPhieuXuatTra_Temp.Value.ToString());
                    int IDDonViTinh = Int32.Parse(cmbDonViTinh.Value.ToString());
                    float GiaMua = float.Parse(txtDonGia.Text.ToString());

                    DataTable db = data.KTChiTietPhieuXuatTra_Temp(IDHangHoa);// kiểm tra hàng hóa
                    if (db.Rows.Count == 0)
                    {
                        data = new dtPhieuXuatTra();
                        data.ThemPhieuXuatTra_Temp(IDPhieuXuatTra, IDHangHoa, IDDonViTinh, SoLuong, GiaMua, (SoLuong * GiaMua));
                        //LoadHangHoa_IDNhaCungCap();
                        Clear();
                    }
                    else
                    {
                        data = new dtPhieuXuatTra();
                        data.UpdatePhieuXuatTra_temp(IDPhieuXuatTra, IDHangHoa, IDDonViTinh, SoLuong, GiaMua, (SoLuong * GiaMua));
                        // LoadHangHoa_IDNhaCungCap();
                        Clear();
                    }
                    LoadGrid(IDPhieuXuatTra);
                }
                else
                {
                    Response.Write("<script language='JavaScript'> alert('Số Lượng > 0.'); </script>");
                }
            
            }
            else
            {
                Response.Write("<script language='JavaScript'> alert('Bạn chưa chọn hàng hóa.'); </script>");
            }
            
        }

        private void LoadGrid(int IDPhieuXuatTra)
        {
            data = new dtPhieuXuatTra();
            gridDanhSachHangHoa_Temp.DataSource = data.LayDanhSachPhieuXuatTra_Temp(IDPhieuXuatTra);
            gridDanhSachHangHoa_Temp.DataBind();
        }

        protected void gridDanhSachHangHoa_Temp_RowDeleting(object sender, DevExpress.Web.Data.ASPxDataDeletingEventArgs e)
        {
            int ID = Int32.Parse(e.Keys[0].ToString());
            data = new dtPhieuXuatTra();
            data.XoaChiTietPhieuXuatTra_Temp_ID(ID);
            e.Cancel = true;
            gridDanhSachHangHoa_Temp.CancelEdit();
            int IDPhieuXuatTra = Int32.Parse(IDPhieuXuatTra_Temp.Value.ToString());
            LoadGrid(IDPhieuXuatTra);
        }

        protected void btnThemPhieuXuat_Click(object sender, EventArgs e)
        {
            if (cmbNhaCungCap.Text != "")
            {
                int IDPhieuXuatTra = Int32.Parse(IDPhieuXuatTra_Temp.Value.ToString());
                data = new dtPhieuXuatTra();
                DataTable db = data.LayDanhSachPhieuXuatTra_Temp(IDPhieuXuatTra);
                if (db.Rows.Count != 0)
                {
                    int IDNhaCungCap = Int32.Parse(cmbNhaCungCap.Value.ToString());
                    DateTime NgayLapPhieu = DateTime.Parse(cmbNgayLapPhieu.Text.ToString());

                    int IDKho = dtSetting.LayIDKho();
                    string GhiChu = txtGhiChu.Text == null ? "" : txtGhiChu.Text.ToString();
                    
                    float TongTien = 0;
                    foreach (DataRow dr in db.Rows)
                    {
                        float ThanhTien = float.Parse(dr["ThanhTien"].ToString());
                        TongTien = TongTien + ThanhTien;
                    }
                    data = new dtPhieuXuatTra();
                    data.CapNhatPhieuXuatTra_ID(IDPhieuXuatTra, IDKho, IDNhaCungCap, TongTien, NgayLapPhieu, GhiChu);
                    foreach (DataRow dr in db.Rows)
                    {
                        int IDHangHoa = Int32.Parse(dr["IDHangHoa"].ToString());
                        int SoLuong = Int32.Parse(dr["SoLuong"].ToString());
                        float GiaMua = float.Parse(dr["GiaMua"].ToString());
                        int IDDonViTinh = Int32.Parse(dr["IDDonViTinh"].ToString());
                        float ThanhTien = float.Parse(dr["ThanhTien"].ToString());
                        data = new dtPhieuXuatTra();
                        data.ThemChiTietPhieuXuatTra(IDPhieuXuatTra, IDHangHoa, IDDonViTinh, SoLuong, GiaMua, ThanhTien);
                        
                        dtCapNhatTonKho tk = new dtCapNhatTonKho();

                        dtLichSuKho.ThemLichSu(IDHangHoa, Int32.Parse(Session["IDNhanVien"].ToString()), SoLuong, "Xuất trả");

                        tk.TruTonKho_IDHangHoa(IDHangHoa, SoLuong, IDKho);
                    }
                    dtLichSuTruyCap.ThemLichSu(Session["IDNhanVien"].ToString(), Session["IDNhom"].ToString(), "Phiếu Xuất Trả", dtSetting.LayIDKho(), "Nhập xuất tồn", "Thêm");    
                    data = new dtPhieuXuatTra();
                    data.XoaChiTietPhieuXuatTra_Temp(IDPhieuXuatTra);
                    Response.Redirect("DanhSachPhieuXuatTra.aspx");
                }
                else
                {
                    Response.Write("<script language='JavaScript'> alert('Danh sách hàng hóa rỗng.'); </script>");
                    //LoadHangHoa_IDNhaCungCap();
                }
            }
            else
            {
                Response.Write("<script language='JavaScript'> alert('Bạn chưa chọn Nhà cung cấp.'); </script>");
                //LoadHangHoa_IDNhaCungCap();
            }
        }

        protected void btnHuyPhieuXuat_Click(object sender, EventArgs e)
        {
            data = new dtPhieuXuatTra();
            int ID = Int32.Parse(IDPhieuXuatTra_Temp.Value.ToString());
            if (ID != null)
            {
                data.XoaPhieuXuatTra_Temp(ID);
                data.XoaPhieuXuatTra_Null();
                data.XoaChiTietPhieuXuatTra_Temp(ID);
                Response.Redirect("DanhSachPhieuXuatTra.aspx");
            }
        }
        public void Clear()
        {
            cmbHangHoa.Text = "";
            txtSoLuong.Text = "";
            txtTonKho.Text = "";
            cmbDonViTinh.Text = "";
            txtDonGia.Text = "";
            txtThanhTien.Text = "";
        }

        //protected void cmbNhaCungCap_SelectedIndexChanged(object sender, EventArgs e)
        //{
        //    data = new dtPhieuXuatTra();
        //    DataTable tb = data.DanhSachPhieuNhapSi(Int32.Parse(cmbNhaCungCap.Value.ToString()));
        //    if (tb.Rows.Count != 0)
        //    {
        //        LoadHangHoa_IDNhaCungCap();
        //        Clear();
        //    }
        //}
        //public void LoadHangHoa_IDNhaCungCap()
        //{
        //    if (cmbNhaCungCap.Value != null)
        //    {
        //        int ID = Int32.Parse(cmbNhaCungCap.Value.ToString());
        //        data = new dtPhieuXuatTra();
        //        cmbHangHoa.DataSource = data.DanhSachPhieuNhapSi_IDNhaCungCap(ID);
        //        cmbHangHoa.TextField = "TenHangHoa";
        //        cmbHangHoa.ValueField = "ID";
        //        cmbHangHoa.DataBind();
        //    }
        //}

        protected void cmbHangHoa_ItemsRequestedByFilterCondition(object source, DevExpress.Web.ListEditItemsRequestedByFilterConditionEventArgs e)
        {
            ASPxComboBox comboBox = (ASPxComboBox)source;

            sqlHangHoa.SelectCommand = @"SELECT [ID], [MaHang], [TenHangHoa], [GiaMua] , [TenDonViTinh]
                                        FROM (
	                                        select GPM_HangHoa.ID, GPM_HangHoa.MaHang, GPM_HangHoa.TenHangHoa, GPM_HangHoa.GiaMua, GPM_DonViTinh.TenDonViTinh, 
	                                        row_number()over(order by GPM_HangHoa.MaHang) as [rn] 
	                                        FROM GPM_DonViTinh INNER JOIN GPM_HangHoa ON GPM_DonViTinh.ID = GPM_HangHoa.IDDonViTinh 
                                                               INNER JOIN GPM_HangHoaTonKho ON GPM_HangHoaTonKho.IDHangHoa = GPM_HangHoa.ID
	                                        WHERE (GPM_HangHoa.MaHang LIKE @MaHang) AND (GPM_HangHoaTonKho.IDKho = @IDKho) AND (GPM_HangHoaTonKho.DaXoa = 0)	
	                                        ) as st 
                                        where st.[rn] between @startIndex and @endIndex";

            sqlHangHoa.SelectParameters.Clear();
            sqlHangHoa.SelectParameters.Add("MaHang", TypeCode.String, string.Format("%{0}%", e.Filter));
            sqlHangHoa.SelectParameters.Add("IDKho", TypeCode.Int32, dtSetting.LayIDKho() + "");
            sqlHangHoa.SelectParameters.Add("startIndex", TypeCode.Int64, (e.BeginIndex + 1).ToString());
            sqlHangHoa.SelectParameters.Add("endIndex", TypeCode.Int64, (e.EndIndex + 1).ToString());
            comboBox.DataSource = sqlHangHoa;
            comboBox.DataBind();
        }

        protected void cmbHangHoa_ItemRequestedByValue(object source, DevExpress.Web.ListEditItemRequestedByValueEventArgs e)
        {
            long value = 0;
            if (e.Value == null || !Int64.TryParse(e.Value.ToString(), out value))
                return;
            ASPxComboBox comboBox = (ASPxComboBox)source;
            sqlHangHoa.SelectCommand = @"SELECT GPM_HangHoa.ID, GPM_HangHoa.MaHang, GPM_HangHoa.TenHangHoa, GPM_HangHoa.GiaMua, GPM_DonViTinh.TenDonViTinh 
                                        FROM GPM_DonViTinh INNER JOIN GPM_HangHoa ON GPM_DonViTinh.ID = GPM_HangHoa.IDDonViTinh 
                                                           INNER JOIN GPM_HangHoaTonKho ON GPM_HangHoaTonKho.IDHangHoa = GPM_HangHoa.ID 
                                        WHERE (GPM_HangHoa.ID = @ID)";

            sqlHangHoa.SelectParameters.Clear();
            sqlHangHoa.SelectParameters.Add("ID", TypeCode.Int64, e.Value.ToString());
            comboBox.DataSource = sqlHangHoa;
            comboBox.DataBind();
        }
    }
}