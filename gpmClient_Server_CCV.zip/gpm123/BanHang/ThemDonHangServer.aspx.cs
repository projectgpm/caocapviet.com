﻿using BanHang.Data;
using DevExpress.Web;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.OleDb;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace BanHang
{
    public partial class ThemDonHangServer : System.Web.UI.Page
    {
        dtThemDonHangServer data = new dtThemDonHangServer();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["KTDangNhap"] != "GPM")
            {
                Response.Redirect("DangNhap.aspx");
            }
            else
            {
                if (dtSetting.LayTrangThaiMenu(Session["IDNhom"].ToString(), 15) == 1)
                {
                    if (!IsPostBack)
                    {
                        data = new dtThemDonHangServer();
                        txtSoHoaDon.Text = (dtSetting.LayIDKho() * 0.1).ToString().Replace(".", "") + "-" + (DateTime.Now.ToString("ddMMyyyy-hhmmss"));
                        object IDPhieuDatHang = data.ThemPhieuDatHangServer();
                        IDPhieuDatHangServer_Temp.Value = IDPhieuDatHang.ToString();
                        cmbKho.Text = dtSetting.LayIDKho().ToString();
                        txtNguoiLapPhieu.Text = Session["TenDangNhap"].ToString();
                        DanhSachNhaCungCap();
                    }
                    LoadGrid(Int32.Parse(IDPhieuDatHangServer_Temp.Value));
                }
                else
                {
                    Response.Redirect("Default.aspx");
                }
            }
        }

        private void LoadGrid(int IDPhieuDatHang)
        {
            gridHangHoa.DataSource = dtThemDonHangClient.DanhSachDonDatHangClient_Temp(IDPhieuDatHang);
            gridHangHoa.DataBind();
        }
        public void Clear()
        {
            cmbHangHoa.Text = "";
            txtTonKho.Text = "";
            txtSoLuong.Text = "";
            txtDonGia.Text = "";
            txtThanhTien.Text = "";
        }
        protected void btnHuy_Click(object sender, EventArgs e)
        {
           
            dtThemDonHangClient.XoaChiTietDonHang_Temp();
            dtThemDonHangServer dt = new dtThemDonHangServer();
            dt.XoaPhieuDatHangServer_Null();
            Response.Redirect("DanhSachDonDatHangServer.aspx");
        }

        protected void btnThem_Click(object sender, EventArgs e)
        {
            if (cmbNhaCungCap.Text != "" && txtSoHoaDon.Text !="")
            {
                int IDPhieuDatHang = Int32.Parse(IDPhieuDatHangServer_Temp.Value);
                DataTable dt = dtThemDonHangClient.DanhSachDonDatHangClient_Temp(IDPhieuDatHang);
                if (dt.Rows.Count != 0)
                {
                    string IDNhaCungCap = cmbNhaCungCap.Value.ToString();
                    DateTime NgayLapPhieu = DateTime.Parse(dateNgayLapPhieu.Text);
                    string GhiChu = txtGhiChu.Text;

                    string SoHoaDon = txtSoHoaDon.Text;
                    double TongTien = 0;
                    foreach (DataRow dr in dt.Rows)
                    {
                        double ThanhTien = float.Parse(dr["ThanhTien"].ToString());
                        TongTien = TongTien + ThanhTien;
                    }
                    data = new dtThemDonHangServer();
                    data.CapNhatDonDatHangServer(SoHoaDon, IDPhieuDatHang, dtSetting.LayIDKho(), NgayLapPhieu, TongTien, GhiChu, Session["IDNhanVien"].ToString(), IDNhaCungCap);
                    foreach (DataRow dr in dt.Rows)
                    {
                        string MaHang = dr["MaHang"].ToString();
                        int IDHangHoa = Int32.Parse(dr["IDHangHoa"].ToString());
                        int IDDonDatHang = Int32.Parse(dr["IDDonDatHang"].ToString());
                        int SoLuong = Int32.Parse(dr["SoLuong"].ToString());
                        float DonGia = float.Parse(dr["DonGia"].ToString());
                        float ThanhTien = float.Parse(dr["ThanhTien"].ToString());
                        data = new dtThemDonHangServer();
                        data.ThemChiTietDonHangServer(IDPhieuDatHang, MaHang, IDHangHoa, SoLuong, DonGia, ThanhTien);
                    }
                    dtThemDonHangClient.XoaChiTietDonHang_Temp();
                    dtLichSuTruyCap.ThemLichSu(Session["IDNhanVien"].ToString(), Session["IDNhom"].ToString(), "Đơn Đặt Hàng", dtSetting.LayIDKho(), "Nhập xuất tồn", "Thêm");
                    Response.Redirect("DanhSachDatHangNhaCungCap.aspx");
                }
                else
                {
                    Response.Write("<script language='JavaScript'> alert('Danh sách hàng hóa rỗng.'); </script>");
                }
            }
            else
            {
                Response.Write("<script language='JavaScript'> alert('Vui lòng chọn nhà cung cấp hàng. hay nhập số hóa đơn'); </script>");
            }
        }

        protected void gridHangHoa_RowDeleting(object sender, DevExpress.Web.Data.ASPxDataDeletingEventArgs e)
        {
            int IDPhieuDatHang = Int32.Parse(IDPhieuDatHangServer_Temp.Value);
            int ID = Int32.Parse(e.Keys[0].ToString());
            dtThemDonHangClient data = new dtThemDonHangClient();
            data.XoaChiTietDonHang_Temp_ID(ID);
            e.Cancel = true;
            gridHangHoa.CancelEdit();
            LoadGrid(IDPhieuDatHang);
        }

        protected void btnLoadFileExcel_Click(object sender, EventArgs e)
        {
            Import();
        }
        private void Import()
        {
            if (string.IsNullOrEmpty(UploadFileExcel.FileName))
            {
                Response.Write("<script language='JavaScript'> alert('Chưa chọn file.'); </script>");
                return;
            }

            UploadFile();
            string Excel = Server.MapPath("~/Uploads/") + strFileExcel;

            string excelConnectionString = string.Empty;
            excelConnectionString = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" + Excel + ";Extended Properties=Excel 8.0;";

            OleDbConnection excelConnection = new OleDbConnection(excelConnectionString);
            OleDbCommand cmd = new OleDbCommand("Select * from [Sheet$]", excelConnection);
            excelConnection.Open();
            OleDbDataReader dReader = default(OleDbDataReader);
            dReader = cmd.ExecuteReader();

            DataTable dataTable = new DataTable();
            dataTable.Load(dReader);
            int r = dataTable.Rows.Count;
            Import_Temp(dataTable);

        }
        private void UploadFile()
        {
            string folder = null;
            string filein = null;
            string ThangNam = null;

            ThangNam = string.Concat(System.DateTime.Now.Month.ToString(), System.DateTime.Now.Year.ToString());
            if (!Directory.Exists(Server.MapPath("~/Uploads/") + ThangNam))
            {
                Directory.CreateDirectory(Server.MapPath("~/Uploads/") + ThangNam);
            }
            folder = Server.MapPath("~/Uploads/" + ThangNam + "/");

            if (UploadFileExcel.HasFile)
            {
                strFileExcel = Guid.NewGuid().ToString();
                string theExtension = Path.GetExtension(UploadFileExcel.FileName);
                strFileExcel += theExtension;

                filein = folder + strFileExcel;
                UploadFileExcel.SaveAs(filein);
                strFileExcel = ThangNam + "/" + strFileExcel;
            }
        }
        private void Import_Temp(DataTable datatable)
        {
            int intRow = datatable.Rows.Count;
            if (intRow != 0)
            {
                for (int i = 0; i <= intRow - 1; i++)
                {
                    DataRow dr = datatable.Rows[i];
                    string MaHang = dr["MaHang"].ToString().Trim();
                    string TenHangHoa = dr["TenHangHoa"].ToString();
                    int SoLuong = Int32.Parse(dr["SoLuong"].ToString());
                    if (SoLuong > 0)
                    {
                        int IDPhieuDatHang = Int32.Parse(IDPhieuDatHangServer_Temp.Value);
                        int IDHangHoa = dtThemDonHangClient.LayIDHangHoa_MaHang_TenHangHoa(MaHang, TenHangHoa);
                        float GiaBan = dtCapNhatTonKho.GiaMua_Client(IDHangHoa);
                        float ThanhTien = SoLuong * GiaBan;

                        DataTable db = dtThemDonHangClient.KTChiTietDonHang_Temp(IDHangHoa, IDPhieuDatHang);// kiểm tra hàng hóa
                        if (db.Rows.Count == 0)
                        {
                            
                            dtThemDonHangClient.ThemChiTietDonHang_Temp(IDPhieuDatHang, MaHang, IDHangHoa, SoLuong, GiaBan, ThanhTien);

                        }
                        else
                        {
                            
                            dtThemDonHangClient.UpdateChiTietDonHang_temp(IDPhieuDatHang, IDHangHoa, SoLuong, GiaBan, ThanhTien);

                        }
                        LoadGrid(IDPhieuDatHang);
                    }
                    else
                    {
                        Response.Write("<script language='JavaScript'> alert('Số lượng phải > 0.'); </script>");
                    }

                }
            }

        }
        protected void btnThem_Temp_Click(object sender, EventArgs e)
        {
            if (cmbHangHoa.Text != "" && txtSoLuong.Text != "")
            {
                int SL = Int32.Parse(txtSoLuong.Text);
                if (SL > 0)
                {
                    int IDPhieuDatHang = Int32.Parse(IDPhieuDatHangServer_Temp.Value);
                    int IDHangHoa = -1;
                    if (dtKiemKho.LayIDHangHoa_Barcode(cmbHangHoa.Text.ToString()) != -1)
                    {
                        IDHangHoa = dtKiemKho.LayIDHangHoa_Barcode(cmbHangHoa.Text.ToString());
                    }
                    else if (dtKiemKho.LayIDHangHoa_HangHoa(cmbHangHoa.Value.ToString()) != -1)
                    {
                        IDHangHoa = dtKiemKho.LayIDHangHoa_HangHoa(cmbHangHoa.Value.ToString());
                    }
                    if (IDHangHoa != -1)
                    {
                        float DG = float.Parse(txtDonGia.Text);

                        double ThanhTien = Double.Parse(txtThanhTien.Text);
                        string MaHang = dtSetting.LayMaHang(IDHangHoa);
                        DataTable db = dtThemDonHangClient.KTChiTietDonHang_Temp(IDHangHoa, IDPhieuDatHang);// kiểm tra hàng hóa
                        if (db.Rows.Count == 0)
                        {

                            dtThemDonHangClient.ThemChiTietDonHang_Temp(IDPhieuDatHang, MaHang, IDHangHoa, SL, DG, float.Parse(ThanhTien + ""));
                            Clear();
                        }
                        else
                        {

                            dtThemDonHangClient.UpdateChiTietDonHang_temp(IDPhieuDatHang, IDHangHoa, SL, DG, float.Parse(ThanhTien + ""));
                            Clear();
                        }
                        LoadGrid(IDPhieuDatHang);
                    }
                    else
                    {

                        ClientScript.RegisterStartupScript(this.GetType(), "alert", "alert('Mã hàng không tồn tại!!');", true);
                    }
                }
                else
                {
                    Response.Write("<script language='JavaScript'> alert('Số lượng phải > 0.'); </script>");
                }
            }
            else
            {
                Response.Write("<script language='JavaScript'> alert('Bạn chưa chọn hàng hóa.'); </script>");
            }
        }

        protected void cmbHangHoa_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cmbHangHoa.Text.Trim() != "")
            {
                int IDPhieuDatHang = Int32.Parse(IDPhieuDatHangServer_Temp.Value);
                int IDHangHoa = -1;
                if (dtKiemKho.LayIDHangHoa_Barcode(cmbHangHoa.Text.ToString()) != -1)
                {
                    IDHangHoa = dtKiemKho.LayIDHangHoa_Barcode(cmbHangHoa.Text.ToString());
                }
                else if (dtKiemKho.LayIDHangHoa_HangHoa(cmbHangHoa.Value.ToString()) != -1)
                {
                    IDHangHoa = dtKiemKho.LayIDHangHoa_HangHoa(cmbHangHoa.Value.ToString());
                }
                if (IDHangHoa != -1)
                {
                    txtTonKho.Text = dtCapNhatTonKho.SoLuongTonKho_Client(IDHangHoa, dtSetting.LayIDKho()).ToString();
                    float GiaBan = dtCapNhatTonKho.GiaMua_Client(IDHangHoa);
                    txtDonGia.Text = GiaBan.ToString();
                    txtSoLuong.Text = "0";
                    txtThanhTien.Text = "0";
                }
                else
                {
                    Clear();
                    ClientScript.RegisterStartupScript(this.GetType(), "alert", "alert('Mã hàng không tồn tại!!');", true);
                    
                }
            }
        }

        protected void txtSoLuong_NumberChanged(object sender, EventArgs e)
        {
            if (cmbHangHoa.Text != "")
            {
                int SL = Int32.Parse(txtSoLuong.Text);
                double DG = double.Parse(txtDonGia.Text);
                txtThanhTien.Text = (SL * DG).ToString();
            }
        }

        protected void dateNgayLapPhieu_Init(object sender, EventArgs e)
        {
            dateNgayLapPhieu.Date = DateTime.Today;
        }

        public string strFileExcel { get; set; }

        protected void btnThemNCC_Click(object sender, EventArgs e)
        {
            popup.ShowOnPageLoad = true;
        }

        protected void btnHuyNCC_Click(object sender, EventArgs e)
        {
            popup.ShowOnPageLoad = false;
        }

        protected void btnThemNCC1_Click(object sender, EventArgs e)
        {
            string TenNhaCungCap = txtTenNCC.Text;
            if (txtTenNCC.Text != "")
            {
                string DienThoai = txtDienThoaiNCC.Text == null ? "" : txtDienThoaiNCC.Text;
                string Fax = txtFaxNCC.Text == null ? "" : txtFaxNCC.Text;
                string Email = txtEmailNCC.Text == null ? "" : txtEmailNCC.Text;
                string DiaChi = txtDiaChiNCC.Text == null ? "" : txtDiaChiNCC.Text;
                string NguoiLienHe = txtNguoiLienHeNCC.Text == null ? "" : txtNguoiLienHeNCC.Text;
                string MaSothue = txtMaSoThueNCC.Text == null ? "" : txtMaSoThueNCC.Text;
                string LinhVuc = txtLinhVucKinhDoanhNCC.Text == null ? "" : txtLinhVucKinhDoanhNCC.Text;
                string GhiChu = txtGhiChuNCC.Text == null ? "" : txtGhiChuNCC.Text;
                dtNhaCungCap ncc = new dtNhaCungCap();
                ncc.ThemNhaCungCap(TenNhaCungCap, DienThoai, Fax, Email, DiaChi, NguoiLienHe, MaSothue, LinhVuc, DateTime.Today, GhiChu);
                ClientScript.RegisterStartupScript(this.GetType(), "alert", "alert('Thêm thành công.');", true);
                ClearNCC();
                DanhSachNhaCungCap();
            }
            else
            {
                ClientScript.RegisterStartupScript(this.GetType(), "alert", "alert('Tên nhà cung cấp không được bỏ trống.');", true);
            }
        }

        public void ClearNCC()
        {
            txtDienThoaiNCC.Text = "";
            txtTenNCC.Text = "";
            txtFaxNCC.Text = "";
            txtEmailNCC.Text = "";
            txtDiaChiNCC.Text = "";
            txtNguoiLienHeNCC.Text = "";
            txtMaSoThueNCC.Text = "";
            txtLinhVucKinhDoanhNCC.Text = "";
            txtGhiChuNCC.Text = "";

        }

        public void DanhSachNhaCungCap()
        {
            dtNhaCungCap ncc = new dtNhaCungCap();
            cmbNhaCungCap.DataSource = ncc.LayDanhSachNhaCungCap();
            cmbNhaCungCap.ValueField = "ID";
            cmbNhaCungCap.TextField = "TenNhaCungCap";
            cmbNhaCungCap.DataBind();

        }

        protected void cmbHangHoa_ItemsRequestedByFilterCondition(object source, DevExpress.Web.ListEditItemsRequestedByFilterConditionEventArgs e)
        {
            ASPxComboBox comboBox = (ASPxComboBox)source;

            sqlHangHoa.SelectCommand = @"SELECT [ID], [MaHang], [TenHangHoa], [GiaMua] , [TenDonViTinh]
                                        FROM (
	                                        select GPM_HangHoa.ID, GPM_HangHoa.MaHang, GPM_HangHoa.TenHangHoa, GPM_HangHoa.GiaMua, GPM_DonViTinh.TenDonViTinh, 
	                                        row_number()over(order by GPM_HangHoa.MaHang) as [rn] 
	                                        FROM GPM_DonViTinh INNER JOIN GPM_HangHoa ON GPM_DonViTinh.ID = GPM_HangHoa.IDDonViTinh 
                                                               INNER JOIN GPM_HangHoaTonKho ON GPM_HangHoaTonKho.IDHangHoa = GPM_HangHoa.ID
	                                        WHERE (GPM_HangHoa.MaHang LIKE @MaHang) AND (GPM_HangHoaTonKho.IDKho = @IDKho) AND (GPM_HangHoaTonKho.DaXoa = 0)	
	                                        ) as st 
                                        where st.[rn] between @startIndex and @endIndex";

            sqlHangHoa.SelectParameters.Clear();
            sqlHangHoa.SelectParameters.Add("MaHang", TypeCode.String, string.Format("%{0}%", e.Filter));
            sqlHangHoa.SelectParameters.Add("IDKho", TypeCode.Int32, dtSetting.LayIDKho() + "");
            sqlHangHoa.SelectParameters.Add("startIndex", TypeCode.Int64, (e.BeginIndex + 1).ToString());
            sqlHangHoa.SelectParameters.Add("endIndex", TypeCode.Int64, (e.EndIndex + 1).ToString());
            comboBox.DataSource = sqlHangHoa;
            comboBox.DataBind();
        }

        protected void cmbHangHoa_ItemRequestedByValue(object source, DevExpress.Web.ListEditItemRequestedByValueEventArgs e)
        {
            long value = 0;
            if (e.Value == null || !Int64.TryParse(e.Value.ToString(), out value))
                return;
            ASPxComboBox comboBox = (ASPxComboBox)source;
            sqlHangHoa.SelectCommand = @"SELECT GPM_HangHoa.ID, GPM_HangHoa.MaHang, GPM_HangHoa.TenHangHoa, GPM_HangHoa.GiaMua, GPM_DonViTinh.TenDonViTinh 
                                        FROM GPM_DonViTinh INNER JOIN GPM_HangHoa ON GPM_DonViTinh.ID = GPM_HangHoa.IDDonViTinh 
                                                           INNER JOIN GPM_HangHoaTonKho ON GPM_HangHoaTonKho.IDHangHoa = GPM_HangHoa.ID 
                                        WHERE (GPM_HangHoa.ID = @ID)";

            sqlHangHoa.SelectParameters.Clear();
            sqlHangHoa.SelectParameters.Add("ID", TypeCode.Int64, e.Value.ToString());
            comboBox.DataSource = sqlHangHoa;
            comboBox.DataBind();
        }
    }
}