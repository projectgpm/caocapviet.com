﻿using BanHang.Data;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace BanHang
{
    public partial class PhieuChuyenKho : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["KTDangNhap"] != "GPM")
            {
                Response.Redirect("DangNhap.aspx");
            }
            else
            {
                if (dtSetting.LayTrangThaiMenu_ChucNang(Session["IDNhom"].ToString(), 19) == 1)
                    Response.Redirect("Default.aspx");
                if (dtSetting.LayTrangThaiMenu(Session["IDNhom"].ToString(), 19) == 1)
                {
                    if (!IsPostBack)
                    {
                        dtPhieuChuyenKho data = new dtPhieuChuyenKho();
                        object IDPhieuChuyenKho = data.ThemPhieuChuyenKho(Session["IDNhom"].ToString());
                        IDPhieuChuyenKho_Temp.Value = IDPhieuChuyenKho.ToString();
                        cmbNguoiLapPhieu.Text = Session["IDNhanVien"].ToString();
                        cmbTrangThaiPhieu.SelectedIndex = 0;
                    }
                    LoadGrid(IDPhieuChuyenKho_Temp.Value.ToString());
                }
                else
                {
                    Response.Redirect("Default.aspx");
                }
            }

            if (Session["IDKho"].ToString().CompareTo("1") != 0)
            {
                Response.Redirect("DanhSachPhieuChuyenKho.aspx");
            }
        }

        private void LoadGrid(string IDPhieuChuyenKho)
        {
            dtPhieuChuyenKho data = new dtPhieuChuyenKho();
            gridDanhSachHangHoa_Temp.DataSource = data.DanhSachChiTietPhieuChuyenKho_Temp(IDPhieuChuyenKho);
            gridDanhSachHangHoa_Temp.DataBind();

        }

        protected void btnThem_Click(object sender, EventArgs e)
        {
            dtPhieuChuyenKho dt = new dtPhieuChuyenKho();
            string IDHH = cmbHangHoa.Value.ToString();
            if (Int32.Parse(txtSoLuong.Value + "") <= Int32.Parse(txtTonKho.Value + ""))
            {
                DataTable dx = dt.KiemTraHangHoa_Temp(IDPhieuChuyenKho_Temp.Value.ToString(), IDHH);
                if (dx.Rows.Count == 0)
                {
                    dt.ThemChiTietPhieuChuyenKho_Temp(IDPhieuChuyenKho_Temp.Value.ToString(), IDHH, txtSoLuong.Value + "", txtHHTrongLuong.Value + "", txtGiaBan.Value + "", txtTongTienHH.Value + "");
                    DataTable da = dt.ChiTietTongSoLuongHangHoa(IDPhieuChuyenKho_Temp.Value.ToString());
                    if (da.Rows.Count != 0)
                    {
                        txtTrongLuong.Value = float.Parse(da.Rows[0]["TongTrongLuong"].ToString());
                        txtTongTien.Value = float.Parse(da.Rows[0]["TongTien"].ToString());
                        txtSoMatHang.Value = Int32.Parse(da.Rows[0]["TongSoLuong"].ToString());
                    }
                }
                else
                {
                    dt.CapNhatChiTietPhieuChuyenKho_Temp(IDPhieuChuyenKho_Temp.Value.ToString(), IDHH, (Int32.Parse(dx.Rows[0]["SoLuong"].ToString()) + Int32.Parse(txtSoLuong.Value + "")) + "", (float.Parse(dx.Rows[0]["TrongLuong"].ToString()) + float.Parse(txtHHTrongLuong.Value + "")) + "", txtGiaBan.Value + "", ((Int32.Parse(dx.Rows[0]["SoLuong"].ToString()) + Int32.Parse(txtSoLuong.Value + "")) * float.Parse(txtGiaBan.Value + "")) + "");
                    DataTable da = dt.ChiTietTongSoLuongHangHoa(IDPhieuChuyenKho_Temp.Value.ToString());
                    if (da.Rows.Count != 0)
                    {
                        txtTrongLuong.Value = float.Parse(da.Rows[0]["TongTrongLuong"].ToString());
                        txtTongTien.Value = float.Parse(da.Rows[0]["TongTien"].ToString());
                        txtSoMatHang.Value = Int32.Parse(da.Rows[0]["TongSoLuong"].ToString());
                    }
                }
                LoadGrid(IDPhieuChuyenKho_Temp.Value.ToString());
            }
            else
            {
                txtSoLuong.Value = txtTonKho.Value;
                Response.Write("<script language='JavaScript'> alert('Hàng hóa không đủ số lượng.'); </script>");
            }
        }

        protected void gridDanhSachHangHoa_Temp_RowDeleting(object sender, DevExpress.Web.Data.ASPxDataDeletingEventArgs e)
        {
            int ID = Int32.Parse(e.Keys[0].ToString());
            dtPhieuChuyenKho dt = new dtPhieuChuyenKho();
            dt.XoaChiTietPhieuChuyenKho_Temp(ID + "");
            e.Cancel = true;
            gridDanhSachHangHoa_Temp.CancelEdit();
            LoadGrid(IDPhieuChuyenKho_Temp.Value.ToString());

            DataTable da = dt.ChiTietTongSoLuongHangHoa(IDPhieuChuyenKho_Temp.Value.ToString());
            if (da.Rows.Count != 0)
            {
                txtTrongLuong.Value = float.Parse(da.Rows[0]["TongTrongLuong"].ToString());
                txtTongTien.Value = float.Parse(da.Rows[0]["TongTien"].ToString());
                txtSoMatHang.Value = Int32.Parse(da.Rows[0]["TongSoLuong"].ToString());
            }
        }

        protected void cmbHangHoa_SelectedIndexChanged(object sender, EventArgs e)
        {
            string IDHH = cmbHangHoa.Value.ToString();
            dataHangHoa data = new dataHangHoa();
            DataTable da = data.getDanhSachHangHoa_TonKho_ID(IDHH);
            if (da.Rows.Count != 0)
            {
                DataRow dr  = da.Rows[0];
                string SoLuongCon = dr["SoLuongCon"].ToString();
                string IDDọnViTinh = dr["IDDonViTinh"].ToString();
                string TrongLuong = dr["TrongLuong"].ToString();
                string giaBan = dr["GiaBan"].ToString();
                txtHHTrongLuong.Value = TrongLuong;
                cmbDonViTinh.Value = IDDọnViTinh;
                txtSoLuong.Value = 1; ;
                txtTonKho.Value = SoLuongCon;
                txtGiaBan.Value = giaBan;
                txtTongTienHH.Value = giaBan;
            }
        }

        protected void btnThemPhieuChuyenKho_Click(object sender, EventArgs e)
        {
            string ID = IDPhieuChuyenKho_Temp.Value.ToString();
            dtPhieuChuyenKho data = new dtPhieuChuyenKho();
            if (cmbKhoNhap.Value != null && cmbKhoXuat.Value != null)
            {
                DataTable da = data.DanhSachChiTietPhieuChuyenKho_Temp(ID);
                if (da.Rows.Count != 0)
                {
                    string IDKhoXuat = cmbKhoXuat.Value + "";
                    string IDKhoNhap = cmbKhoNhap.Value + "";
                    string IDNhanVienLap = Session["IDNhanVien"].ToString();
                    string IDNhanVienDuyet = -1 + "";
                    string SoMatHang = txtSoMatHang.Value + "";
                    string TrongLuong = txtTrongLuong.Value + "";
                    string tongTien = txtTongTien.Value + "";
                    data.CapNhatPhieuChuyenKho(ID, IDKhoXuat, IDKhoNhap, IDNhanVienLap, IDNhanVienDuyet, SoMatHang, TrongLuong, tongTien);

                    for (int i = 0; i < da.Rows.Count; i++)
                    {
                        DataRow dr = da.Rows[i];
                        string IDHangHoa = dr["IDHangHoa"].ToString();
                        string SoLuong = dr["SoLuong"].ToString();
                        string TrongLuongHH = dr["TrongLuong"].ToString();
                        string GiaBan = dr["GiaBan"].ToString();
                        string TongTien = dr["TongTien"].ToString();
                        data.ThemChiTietPhieuChuyenKho(ID, IDHangHoa, SoLuong, TrongLuongHH, GiaBan, TongTien);
                    }

                    dtLichSuTruyCap.ThemLichSu(Session["IDNhanVien"].ToString(), Session["IDNhom"].ToString(), "Phiếu chuyển kho", Session["IDKho"].ToString(), "Nhập xuất tồn", "Thêm");
                    Response.Redirect("DanhSachPhieuChuyenKho.aspx");
                }
                else
                {
                    Response.Write("<script language='JavaScript'> alert('Danh sách hàng hóa không được rỗng.'); </script>");
                }
            }
            else
            {
                Response.Write("<script language='JavaScript'> alert('Chọn kho nhận.'); </script>");
            }
        }

        protected void cmbNgayLapPhieu_Init(object sender, EventArgs e)
        {
            cmbNgayLapPhieu.Date = DateTime.Today;
        }

        protected void btnHuyPhieuChuyenKho_Click(object sender, EventArgs e)
        {
            dtPhieuChuyenKho data = new dtPhieuChuyenKho();
            data.XoaPhieuChuyenKho_Temp(IDPhieuChuyenKho_Temp.Value.ToString());
            Response.Redirect("DanhSachPhieuChuyenKho.aspx");
        }

        protected void txtSoLuong_NumberChanged(object sender, EventArgs e)
        {
            string IDHH = cmbHangHoa.Value.ToString();
            dataHangHoa data = new dataHangHoa();
            DataTable da = data.getDanhSachHangHoa_TonKho_ID(IDHH);
            if (da.Rows.Count != 0)
            {
                DataRow dr = da.Rows[0];
                float TrongLuong = float.Parse(dr["TrongLuong"].ToString());
                float giaban = float.Parse(dr["GiaBan"].ToString());
                int soLuongMoi = Int32.Parse(txtSoLuong.Value + "");
                txtHHTrongLuong.Value = (soLuongMoi * TrongLuong);
                txtTongTienHH.Value = (soLuongMoi * giaban);
            }
        }
    }
}